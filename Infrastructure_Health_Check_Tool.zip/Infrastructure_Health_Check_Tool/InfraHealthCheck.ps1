#Requires -Version 5.1
<#
.SYNOPSIS
    NourNet Infrastructure Health Check Tool - v1.1 Professional

.DESCRIPTION
    Professional MSP infrastructure health monitoring tool.
    Covers: AD, Exchange, DFS, ADFS/SSL - 14 health checks.
    Exports professional HTML + CSV reports.
    READ-ONLY - zero modifications to infrastructure.

.NOTES
    Version : 1.1 Professional
    Author  : Hisham Nasur

    FIXES in v1.1 vs v1.0:
    [F01] GUI panel dock order corrected  - header was rendering at bottom
    [F02] $flushTable scriptblock scope   - used GetNewClosure() to capture parent vars
    [F03] No progress bar                 - added ProgressPanel with animated steps
    [F04] No Disconnect button            - added Disconnect with session/credential clear
    [F05] Non-professional design         - full Microsoft-Fluent-inspired redesign
    [F06] Export path mismatch            - confirmed consistent HealthCheck_$ts naming
    [F07] Unicode chars in PS strings     - replaced all em-dashes with hyphens
    [F08] Add-Type -TypeDefinition        - zero C# compilation used anywhere
#>

Set-StrictMode -Version 2.0   # 2.0 catches typos/unset vars without over-strict null enforcement
$ErrorActionPreference = 'Continue'

# ============================================================
# GLOBALS
# ============================================================
$Script:AppVersion      = '1.1 Professional'
$Script:Credential      = $null
$Script:ServerInventory = [System.Collections.ArrayList]@()
$Script:ConnectedUser   = ''
$Script:CustomerName    = ''
$Script:LogPath         = Join-Path $PSScriptRoot 'Logs'
$Script:ReportPath      = Join-Path $PSScriptRoot 'Reports'
$Script:CustomersFile   = Join-Path $PSScriptRoot 'customers.json'
$Script:SettingsFile    = Join-Path $PSScriptRoot 'settings.json'
$Script:ActiveCustomer  = $null
$Script:LastCustomerID  = ''   # Persists selected customer across runs
$Script:LogFile         = $null
$Script:LastResults     = $null
$Script:LastHTMLPath    = ''
$Script:LastCSVPath     = ''
$Script:IsRunning       = $false
$Script:CompanyLogo     = ''   # Base64-encoded company logo for HTML reports
# GUI controls - initialized here so they can be safely tested before GUI builds
$Script:LogTextBox      = $null
$Script:ServersLabel    = $null
$Script:ScoreValue      = $null
$Script:HealthyCount    = $null
$Script:WarningCount    = $null
$Script:CriticalCount   = $null
$Script:InfoCount       = $null
$Script:OverallLabel    = $null
$Script:StatusLabel     = $null
$Script:TechLabel       = $null
$Script:CustomerCombo   = $null
$Script:ProgressBar     = $null
$Script:ProgressLabel   = $null
$Script:StatusBarLabel  = $null
$Script:ResultsGrid     = $null
$Script:WinRMGrid       = $null
$Script:CustomerTextBox = $null

foreach ($dir in @($Script:LogPath, $Script:ReportPath)) {
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ============================================================
# MODULE-LEVEL HELPERS
# ============================================================
function ConvertTo-HtmlEscaped {
    param([string]$Text)
    if (-not $Text) { return '' }
    # Also escape $ and backtick to prevent PowerShell re-expansion when
    # the result is used in double-quoted strings or here-strings
    $Text -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;' -replace '"','&quot;' `
          -replace '\$','&#36;' -replace '``','&#96;'
}

function ConvertTo-DBSizeGB {
    param([object]$SizeObject)
    $str = [string]$SizeObject
    if ($str -match '\(([0-9,]+)\s*bytes\)')  { return [math]::Round(([long]($Matches[1] -replace ',','')) / 1GB, 2) }
    if ($str -match '([\d\.]+)\s*GB')          { return [math]::Round([double]$Matches[1], 2) }
    if ($str -match '([\d\.]+)\s*MB')          { return [math]::Round([double]$Matches[1] / 1024, 2) }
    if ($str -match '([\d\.]+)\s*KB')          { return [math]::Round([double]$Matches[1] / (1024*1024), 2) }
    return -1
}

# ============================================================
# LOGGING
# ============================================================
function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR','SUCCESS','SECTION')]
        [string]$Level = 'INFO'
    )
    $ts  = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $pad = $Level.PadRight(7)
    $line= "[$ts] [$pad] $Message"
    $col = switch ($Level) { 'INFO'{'Cyan'} 'WARN'{'Yellow'} 'ERROR'{'Red'} 'SUCCESS'{'Green'} 'SECTION'{'White'} default{'Gray'} }
    Write-Host $line -ForegroundColor $col
    if ($Script:LogFile) { try { Add-Content -Path $Script:LogFile -Value $line -Encoding UTF8 -EA Stop } catch {} }
}

function Start-LogSession {
    $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
    $Script:LogFile = Join-Path $Script:LogPath "HealthCheck_$ts.log"
    Write-Log ('=' * 70) -Level SECTION
    Write-Log "  INFRASTRUCTURE HEALTH CHECK  v$($Script:AppVersion)  |  $ts" -Level SECTION
    Write-Log ('=' * 70) -Level SECTION
}

# ============================================================
# SERVER INVENTORY
# ============================================================
# ============================================================
# CUSTOMER PROFILE DATABASE  (replaces servers.txt)
# Stored as: customers.json  next to the script
# ============================================================
function Get-CustomersDB {
    if (Test-Path $Script:CustomersFile) {
        try {
            $raw = Get-Content $Script:CustomersFile -Raw -Encoding UTF8
            $db  = $raw | ConvertFrom-Json
            # CRITICAL: ConvertFrom-Json returns a single PSObject (not array) when there is 1 customer.
            # Force Customers to always be a proper array using @() wrapper.
            if ($null -eq $db.Customers) {
                $db | Add-Member -MemberType NoteProperty -Name 'Customers' -Value @() -Force
            } else {
                # @() forces array even for a single PSObject returned by ConvertFrom-Json
                $db.Customers = [array]@($db.Customers)
            }
            return $db
        } catch {}
    }
    return [PSCustomObject]@{ Customers = [array]@() }
}

function Save-CustomersDB {
    param($DB)
    try {
        # Convert Customers to plain PS array (not ArrayList) before JSON serialization
        # ArrayList may not serialize correctly in all PS5.1 builds
        $plainDB = [PSCustomObject]@{
            Customers = @($DB.Customers | ForEach-Object {
                [PSCustomObject]@{
                    ID          = [string]$_.ID
                    Name        = [string]$_.Name
                    Site        = [string]$_.Site
                    Contact     = [string]$_.Contact
                    Notes       = [string]$_.Notes
                    ReportPath  = [string]$_.ReportPath
                    LastCheck   = [string]$_.LastCheck
                    LastStatus  = [string]$_.LastStatus
                    Servers     = @($_.Servers | ForEach-Object { [PSCustomObject]@{ Name=[string]$_.Name; Role=[string]$_.Role } })
                }
            })
        }
        $plainDB | ConvertTo-Json -Depth 10 | Set-Content $Script:CustomersFile -Encoding UTF8 -Force
        return $true
    }
    catch { return $false }
}

function New-CustomerID { return [System.Guid]::NewGuid().ToString('N').Substring(0,12).ToUpper() }

function Update-CustomerLastCheck {
    param([string]$CustomerID, [string]$Status)
    $db = Get-CustomersDB
    $c  = @($db.Customers) | Where-Object { $_.ID -eq $CustomerID } | Select-Object -First 1
    if ($c) {
        $c.LastCheck  = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss')
        $c.LastStatus = $Status
        Save-CustomersDB $db | Out-Null
    }
}

function Import-ServerInventory {
    param([string]$FilePath = '', [object]$CustomerProfile = $null)
    $inv = [System.Collections.ArrayList]@()

    # Priority 1: load from customer profile servers list
    if ($CustomerProfile -and $CustomerProfile.Servers) {
        foreach ($s in $CustomerProfile.Servers) {
            [void]$inv.Add([PSCustomObject]@{
                Name = [string]$s.Name
                Role = if ($s.Role) { [string]$s.Role } else { 'Unknown' }
            })
        }
        Write-Log "Loaded $($inv.Count) server(s) from customer profile: $($CustomerProfile.Name)" -Level INFO
        return $inv
    }

    # Priority 2: explicit file path
    if (-not $FilePath) {
        foreach ($p in @((Join-Path $PSScriptRoot 'servers.txt'),(Join-Path (Get-Location) 'servers.txt'))) {
            if (Test-Path $p) { $FilePath = $p; break }
        }
    }
    if ($FilePath -and (Test-Path $FilePath)) {
        Get-Content $FilePath | Where-Object { $_.Trim() -and -not $_.TrimStart().StartsWith('#') } | ForEach-Object {
            $parts = $_ -split ',', 2
            [void]$inv.Add([PSCustomObject]@{
                Name = $parts[0].Trim()
                Role = if ($parts.Count -ge 2) { $parts[1].Trim() } else { 'Unknown' }
            })
        }
        Write-Log "Loaded $($inv.Count) server(s) from: $FilePath" -Level INFO
        return $inv
    }

    Write-Log 'No customer profile selected and servers.txt not found.' -Level WARN
    return $inv
}

# ============================================================
# REMOTE COMMAND
# ============================================================
function Invoke-SafeRemoteCommand {
    param(
        [string]$ServerName,
        [scriptblock]$ScriptBlock,
        [System.Management.Automation.PSCredential]$Credential,
        [int]$TimeoutSeconds = 60,
        [object[]]$ArgumentList = $null
    )
    if (-not $Credential) { return @{ Success=$false; Data=$null; Error='No credentials' } }
    try {
        $IdleMs = [math]::Max(60000, $TimeoutSeconds * 1000)
        $so = New-PSSessionOption -OperationTimeout ($TimeoutSeconds*1000) -IdleTimeout $IdleMs -CancelTimeout 30000 -OpenTimeout 30000
        $ic = @{ ComputerName=$ServerName; ScriptBlock=$ScriptBlock; Credential=$Credential; SessionOption=$so; ErrorAction='Stop' }
        if ($null -ne $ArgumentList -and $ArgumentList.Count -gt 0) { $ic.ArgumentList = $ArgumentList }
        $data = Invoke-Command @ic
        return @{ Success=$true; Data=$data; Error=$null }
    } catch {
        Write-Log "  [!!] $ServerName - $($_.Exception.Message)" -Level WARN
        return @{ Success=$false; Data=$null; Error=$_.Exception.Message }
    }
}

# ============================================================
# EXCHANGE PS SESSION
# ============================================================
function Connect-ExchangePS {
    param([string]$Server, [System.Management.Automation.PSCredential]$Cred)
    $so = New-PSSessionOption -SkipCACheck -SkipCNCheck -SkipRevocationCheck -OpenTimeout 20000 -OperationTimeout 90000
    foreach ($auth in @('Kerberos','Basic')) {
        try {
            $s = New-PSSession -ConfigurationName Microsoft.Exchange `
                     -ConnectionUri "http://$Server/PowerShell/" `
                     -Credential $Cred -Authentication $auth -SessionOption $so -ErrorAction Stop
            Write-Log "  Exchange PS: $Server ($auth)" -Level INFO
            return @{ Success=$true; Session=$s; Error='' }
        } catch { Write-Log "  Exchange PS $auth failed: $Server" -Level WARN }
    }
    return @{ Success=$false; Session=$null; Error="Cannot connect Exchange PS on $Server" }
}

function New-HC {
    param([string]$Status,[string]$Category,[string]$Server,[string]$Comment,[string]$Details='')
    [PSCustomObject]@{ Status=$Status; Category=$Category; Server=$Server; Comment=$Comment; Details=$Details }
}

# ============================================================
# SHARED SCRIPTBLOCKS
# ============================================================
$DiskSB = {
    param([int]$WarnPct)
    $rows = [System.Collections.ArrayList]@(); $warn = [System.Collections.ArrayList]@()
    try { $disks = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' -EA Stop) }
    catch { try { $disks = @(Get-WmiObject Win32_LogicalDisk -Filter 'DriveType=3' -EA Stop) } catch { $disks = @() } }
    foreach ($d in $disks) {
        if (-not $d.Size -or $d.Size -le 0) { continue }
        $sz   = [math]::Round($d.Size/1GB, 1)
        $free = [math]::Round($d.FreeSpace/1GB, 1)
        $used = [math]::Round(($d.Size-$d.FreeSpace)/$d.Size*100, 1)
        [void]$rows.Add("$($d.DeviceID -replace ':','')|$used|$sz|$free")
        if ($used -ge $WarnPct) { [void]$warn.Add("Drive $($d.DeviceID): ${used}% used  (Free: $free GB | Total: $sz GB)") }
    }
    return @{ Rows=@($rows); Warnings=@($warn) }
}

$TimeSB = {
    $r = @{ Source=''; Offset=''; Stratum=''; OffsetSec=0.0 }
    try {
        foreach ($line in @(& w32tm /query /status 2>&1 | ForEach-Object { [string]$_ })) {
            if ($line -match 'Source\s*:\s*(.+)')       { $r.Source  = $Matches[1].Trim() }
            if ($line -match 'Phase Offset\s*:\s*(.+)') { $r.Offset  = $Matches[1].Trim() }
            if ($line -match 'Stratum\s*:\s*(\d+)')     { $r.Stratum = $Matches[1].Trim() }
        }
        if     ($r.Offset -match '([-\d\.]+)s$')  { $r.OffsetSec = [math]::Abs([double]$Matches[1]) }
        elseif ($r.Offset -match '([-\d\.]+)ns$') { $r.OffsetSec = [math]::Abs([double]$Matches[1]) / 1e9 }
        elseif ($r.Offset -match '([-\d\.]+)ms$') { $r.OffsetSec = [math]::Abs([double]$Matches[1]) / 1000 }
    } catch { $r.Source = 'Error' }
    return $r
}

# ============================================================
# HEALTH CHECKS
# ============================================================
function Invoke-HealthCheckAll {
    param([System.Management.Automation.PSCredential]$Credential)

    $DCServers   = @($Script:ServerInventory | Where-Object { $_.Role -match '\bDC\b|Domain.Controller' -and $_.Role -notmatch 'Federation' })
    $ExchServers = @($Script:ServerInventory | Where-Object { $_.Role -match 'Exchange' })
    $DFSServers  = @($Script:ServerInventory | Where-Object { $_.Role -match '\bDFS\b|Distributed.File' -and $_.Role -notmatch 'ADFS|Federation' })
    $ADFSServers = @($Script:ServerInventory | Where-Object { $_.Role -match 'ADFS|AD\.?FS|Federation' })

    $AllDCNames   = @($DCServers   | ForEach-Object { $_.Name })
    $AllExchNames = @($ExchServers | ForEach-Object { $_.Name })
    $AllDFSNames  = @($DFSServers  | ForEach-Object { $_.Name })
    $AllADFSNames = @($ADFSServers | ForEach-Object { $_.Name })
    $PrimaryDC    = if ($AllDCNames.Count  -gt 0) { $AllDCNames[0]  } else { $null }

    Write-Log "DC:$($AllDCNames.Count) Exchange:$($AllExchNames.Count) DFS:$($AllDFSNames.Count) ADFS:$($AllADFSNames.Count)" -Level INFO

    $R = [ordered]@{}

    # ================================================================
    # DC REACHABILITY PRE-CHECK
    # Probe each DC ONCE with short timeout before any AD checks run.
    # All AD checks share this cached list - no repeated timeouts.
    # ================================================================
    $ReachableDCs   = [System.Collections.ArrayList]@()
    $UnreachableDCs = [System.Collections.ArrayList]@()
    if ($AllDCNames.Count -gt 0) {
        Write-Log '--- DC Reachability Pre-Check' -Level SECTION
        $ProbeSB = { return $true }
        foreach ($dc in $AllDCNames) {
            Write-Log "  Probing $dc..." -Level INFO
            $probe = Invoke-SafeRemoteCommand -ServerName $dc -ScriptBlock $ProbeSB `
                         -Credential $Credential -TimeoutSeconds 10
            if ($probe.Success) {
                [void]$ReachableDCs.Add($dc)
                Write-Log "  $dc - REACHABLE" -Level SUCCESS
            } else {
                [void]$UnreachableDCs.Add($dc)
                Write-Log "  $dc - UNREACHABLE: $($probe.Error)" -Level WARN
            }
        }
        if ($ReachableDCs.Count -eq 0) {
            Write-Log "CRITICAL: No DC is reachable. Skipping all AD checks." -Level ERROR
        } else {
            Write-Log "Reachable DCs: $($ReachableDCs -join ', ')" -Level INFO
            if ($UnreachableDCs.Count -gt 0) {
                Write-Log "Unreachable DCs: $($UnreachableDCs -join ', ')" -Level WARN
            }
        }
    }

    # -- AD-1: Replication -------------------------------------------------------
    Write-Log '--- AD Replication' -Level SECTION
    $R['AD_Replication'] = & {
        if (-not $PrimaryDC) { return New-HC 'N/A' 'Active Directory' 'N/A' 'No DC servers in servers.txt' }
        # Script block: runs repadmin /showrepl /csv for detailed partner info
        # AND repadmin /replsummary for summary with failure counts
        $RepSB = {
            $out = @{ Lines=@(); PartnerFails=@(); SummaryFails=@(); OK=$false; Err=''; Time='' }
            try {
                # Summary - shows which DCs have failures
                $sumRaw = @(& repadmin /replsummary 2>&1 | ForEach-Object { [string]$_ })
                $out.Lines = $sumRaw
                foreach ($l in $sumRaw) {
                    if ($l -match 'Start Time:\s+(.+)') { $out.Time = $Matches[1].Trim() }
                    # Lines with failure count > 0: "  servername  partner  fails/total  ..."
                    if ($l -match '^\s+(\S+)\s+\S+\s+(\d+)\s*/\s*\d+' -and [int]$Matches[2] -gt 0) {
                        $out.SummaryFails += $Matches[1].Trim()
                    }
                }
                # Detailed partner failures using /showrepl
                $detRaw = @(& repadmin /showrepl /errorsonly 2>&1 | ForEach-Object { [string]$_ })
                $curSrc = ''; $curDst = ''
                foreach ($l in $detRaw) {
                    if ($l -match '^\s*(\S+)\s+via RPC$') { $curSrc = $Matches[1].Trim() }
                    if ($l -match '^\s+DC object GUID:') { }
                    if ($l -match '^\s+Last attempt.*FAILED' -or $l -match 'error') {
                        if ($curSrc) { $out.PartnerFails += $curSrc }
                    }
                }
                $out.OK = $true
            } catch { $out.Err = $_.Exception.Message }
            return $out
        }
        $srvList = $AllDCNames -join ', '
        # Use pre-checked reachable DCs only (no repeated timeouts)
        $dcList = if ($ReachableDCs.Count -gt 0) { $ReachableDCs } else { $AllDCNames }
        $res = $null; $usedDC = ''
        foreach ($tryDC in $dcList) {
            $res = Invoke-SafeRemoteCommand -ServerName $tryDC -ScriptBlock $RepSB -Credential $Credential -TimeoutSeconds 120
            if ($res.Success) { $usedDC = $tryDC; break }
        }
        if (-not $res -or -not $res.Success) {
            $unreachMsg = if ($UnreachableDCs.Count -gt 0) { " | Unreachable: $($UnreachableDCs -join ', ')" } else { '' }
            return New-HC 'Warning' 'Active Directory' $srvList "Cannot reach any DC to run repadmin$unreachMsg" ($AllDCNames -join "`n")
        }
        $d = $res.Data
        if (-not $d.OK) { return New-HC 'Warning' 'Active Directory' $srvList "repadmin failed on $usedDC" $d.Err }
        $dp = [System.Collections.ArrayList]@()
        [void]$dp.Add("Replication checked via: $usedDC")
        if ($d.Time) { [void]$dp.Add("Collected: $($d.Time)") }
        [void]$dp.Add("DCs: $($AllDCNames -join ', ')")
        foreach ($l in $d.Lines) { [void]$dp.Add($l) }
        $fails = @(($d.SummaryFails + $d.PartnerFails) | Sort-Object -Unique)
        if (@($fails).Count -gt 0) {
            $failMsg = "$(@($fails).Count) DC(s) with replication failures: $($fails -join ', ')"
            return New-HC 'Warning' 'Active Directory' $srvList $failMsg ($dp -join "`n")
        }
        New-HC 'Healthy' 'Active Directory' $srvList "Replication healthy on $($AllDCNames.Count) DC(s) (checked via $usedDC)" ($dp -join "`n")
    }

    # -- AD-2: Time Sync ---------------------------------------------------------
    Write-Log '--- AD Time Sync' -Level SECTION
    $R['AD_TimeSync'] = & {
        if ($AllDCNames.Count -eq 0) { return New-HC 'N/A' 'Active Directory' 'N/A' 'No DC servers in servers.txt' }
        $warns = [System.Collections.ArrayList]@(); $det = [System.Collections.ArrayList]@()
        # Add unreachable DCs directly from pre-check (no re-timeout)
        foreach ($udc in $UnreachableDCs) {
            [void]$det.Add("TIMEROW:${udc}:Unreachable:N/A:N/A:FAIL")
            [void]$warns.Add("[$udc] Cannot connect - server unreachable")
        }
        # Only query reachable DCs
        $dcList2 = if ($ReachableDCs.Count -gt 0) { $ReachableDCs } else { $AllDCNames }
        foreach ($dc in $dcList2) {
            $res = Invoke-SafeRemoteCommand -ServerName $dc -ScriptBlock $TimeSB -Credential $Credential -TimeoutSeconds 30
            if (-not $res.Success) { [void]$warns.Add("[$dc] Connection failed"); [void]$det.Add("TIMEROW:${dc}:Error:N/A:N/A:FAIL"); continue }
            $d = $res.Data
            $src = if ($d.Source) { $d.Source } else { 'Unknown' }
            $off = if ($d.Offset) { $d.Offset } else { 'N/A' }
            $str = if ($d.Stratum) { $d.Stratum } else { 'N/A' }
            $flag = if ($d.OffsetSec -gt 5 -or $src -match 'Local CMOS|Free-running|unspecified|^none') { 'WARN' } else { 'OK' }
            [void]$det.Add("TIMEROW:${dc}:${src}:${off}:${str}:${flag}")
            if ($flag -eq 'WARN') { [void]$warns.Add("[$dc] NTP issue - Source: $src Offset: $off") }
        }
        $srvList = $AllDCNames -join ', '
        if ($warns.Count -gt 0) { return New-HC 'Warning' 'Active Directory' $srvList ($warns -join ' | ') ($det -join "`n") }
        New-HC 'Healthy' 'Active Directory' $srvList "Time sync healthy on $($AllDCNames.Count) DC(s)" ($det -join "`n")
    }

    # -- AD-3: Disk Space --------------------------------------------------------
    Write-Log '--- AD Disk Space' -Level SECTION
    $R['AD_DiskStatus'] = & {
        if ($AllDCNames.Count -eq 0) { return New-HC 'N/A' 'Active Directory' 'N/A' 'No DC servers in servers.txt' }
        $warnPct=75; $allWarn=[System.Collections.ArrayList]@(); $det=[System.Collections.ArrayList]@()
        $connOK = 0; $connFail = [System.Collections.ArrayList]@($UnreachableDCs)
        # Pre-fill unreachable DCs from pre-check (no re-timeout)
        foreach ($udc in $UnreachableDCs) {
            [void]$det.Add("DISKROW:${udc}:Unreachable:0:N/A:N/A:ERROR")
        }
        # Only query reachable DCs
        $dcList3 = if ($ReachableDCs.Count -gt 0) { $ReachableDCs } else { $AllDCNames }
        foreach ($dc in $dcList3) {
            $res = Invoke-SafeRemoteCommand -ServerName $dc -ScriptBlock $DiskSB -Credential $Credential -TimeoutSeconds 30 -ArgumentList @($warnPct)
            if (-not $res.Success) { [void]$det.Add("DISKROW:${dc}:Error:0:N/A:N/A:ERROR"); [void]$connFail.Add($dc); continue }
            $connOK++
            foreach ($row in @($res.Data.Rows)) {
                $p = $row -split '\|',4
                if ($p.Count -lt 4) { continue }
                $flag = if ([double]$p[1] -ge $warnPct) {'CRITICAL'} elseif ([double]$p[1] -ge 60) {'WARN'} else {'OK'}
                [void]$det.Add("DISKROW:${dc}:$($p[0]):$($p[1]):$($p[2]):$($p[3]):${flag}")
            }
            foreach ($w in @($res.Data.Warnings)) { [void]$allWarn.Add("[$dc] $w") }
        }
        $srvList = $AllDCNames -join ', '
        if ($connOK -eq 0) { return New-HC 'Warning' 'Active Directory' $srvList "Cannot connect to any DC. Check WinRM and credentials. Tried: $($connFail -join ', ')" ($det -join "`n") }
        if ($allWarn.Count -gt 0) { return New-HC 'Critical' 'Active Directory' $srvList "ACTION REQUIRED: $($allWarn.Count) drive(s) >= $warnPct% on DC(s)" ($det -join "`n") }
        $skipMsg = if ($connFail.Count -gt 0) { " (could not reach: $($connFail -join ', '))" } else { '' }
        New-HC 'Healthy' 'Active Directory' $srvList "All DC drives below $warnPct%$skipMsg" ($det -join "`n")
    }

    # -- AD-4: Admin Groups ------------------------------------------------------
    Write-Log '--- AD Admin Groups' -Level SECTION
    $R['Admin_Groups'] = & {
        if (-not $PrimaryDC) { return New-HC 'N/A' 'Active Directory' 'N/A' 'No DC servers in servers.txt' }
        $GrpSB = {
            $out = @{ DA=@(); EA=@(); DAEnabled=0; EAEnabled=0; Error='' }
            try {
                Import-Module ActiveDirectory -EA Stop
                $daAll = @(Get-ADGroupMember 'Domain Admins' -Recursive -EA Stop | Where-Object { $_.objectClass -eq 'user' })
                $out.DA = @($daAll | Select-Object -ExpandProperty SamAccountName | Sort-Object)
                $out.DAEnabled = @($daAll | ForEach-Object { try{(Get-ADUser $_.SamAccountName -Properties Enabled -EA SilentlyContinue).Enabled}catch{$false} } | Where-Object {$_}).Count
                $eaAll = @()
                try { $eaAll = @(Get-ADGroupMember 'Enterprise Admins' -Recursive -EA Stop | Where-Object { $_.objectClass -eq 'user' }) } catch {}
                $out.EA = @($eaAll | Select-Object -ExpandProperty SamAccountName | Sort-Object)
                $out.EAEnabled = @($eaAll | ForEach-Object { try{(Get-ADUser $_.SamAccountName -Properties Enabled -EA SilentlyContinue).Enabled}catch{$false} } | Where-Object {$_}).Count
            } catch { $out.Error = $_.Exception.Message }
            return $out
        }
        # Use pre-checked reachable DCs only (no repeated timeouts)
        $dcList4 = if ($ReachableDCs.Count -gt 0) { $ReachableDCs } else { $AllDCNames }
        $res = $null; $usedDC2 = ''
        foreach ($tryDC2 in $dcList4) {
            $res = Invoke-SafeRemoteCommand -ServerName $tryDC2 -ScriptBlock $GrpSB -Credential $Credential -TimeoutSeconds 90
            if ($res.Success -and -not $res.Data.Error) { $usedDC2 = $tryDC2; break }
            Write-Log "Admin_Groups: $tryDC2 failed, trying next DC..." -Level WARN
        }
        if (-not $res -or -not $res.Success) {
            $unreachMsg2 = if ($UnreachableDCs.Count -gt 0) { " | Unreachable: $($UnreachableDCs -join ', ')" } else { '' }
            return New-HC 'Warning' 'Active Directory' ($AllDCNames -join ', ') "Cannot connect to any DC$unreachMsg2" ''
        }
        $d = $res.Data
        if ($d.Error) { return New-HC 'Warning' 'Active Directory' $usedDC2 "AD group query failed on $usedDC2" $d.Error }
        $daJ = if (@($d.DA).Count -gt 0) { @($d.DA) -join '~~' } else { '(none)' }
        $eaJ = if (@($d.EA).Count -gt 0) { @($d.EA) -join '~~' } else { '(none)' }
        $det = "GRPROW:Domain Admins:$(@($d.DA).Count):$($d.DAEnabled):$daJ`nGRPROW:Enterprise Admins:$(@($d.EA).Count):$($d.EAEnabled):$eaJ"
        New-HC 'Healthy' 'Active Directory' $PrimaryDC "Domain Admins: $(@($d.DA).Count) | Enterprise Admins: $(@($d.EA).Count)" $det
    }

    # -- EXCH-1: DAG Replication -------------------------------------------------
    Write-Log '--- Exchange Replication' -Level SECTION
    $R['Exch_Replication'] = & {
        if ($AllExchNames.Count -eq 0) { return New-HC 'N/A' 'Exchange Server' 'N/A' 'No Exchange servers in servers.txt' }
        $det=[System.Collections.ArrayList]@(); $issues=[System.Collections.ArrayList]@(); $dagName=''
        foreach ($exSrv in $AllExchNames) {
            $conn = Connect-ExchangePS -Server $exSrv -Cred $Credential
            if (-not $conn.Success) { [void]$issues.Add("[$exSrv] Cannot connect: $($conn.Error)"); continue }
            try {
                $null = Import-PSSession $conn.Session -AllowClobber -DisableNameChecking -CommandName @('Get-DatabaseAvailabilityGroup','Get-MailboxDatabaseCopyStatus','Get-MailboxDatabase','Get-ExchangeServer') -EA SilentlyContinue 3>$null 4>$null
                try { $dag=Get-DatabaseAvailabilityGroup -Status -EA SilentlyContinue | Select-Object -First 1; if($dag -and -not $dagName){$dagName=[string]$dag.Name} } catch {}
                try {
                    $copies = @(Get-MailboxDatabaseCopyStatus -Server $exSrv -EA Stop)
                    if ($copies.Count -eq 0) { [void]$det.Add("DAGROW:${exSrv}:No copies:Standalone:N/A:N/A:N/A:$(if($dagName){$dagName}else{'N/A'}):OK") }
                    else {
                        foreach ($c in ($copies | Sort-Object DatabaseName)) {
                            $st=[string]$c.Status; $cq=[string]$c.CopyQueueLength; $rq=[string]$c.ReplayQueueLength; $ci=[string]$c.ContentIndexState
                            $health = if ($st -in @('Mounted','Healthy','SeedingSource')) {'OK'} else {'ISSUE'}
                            $dagLabel = if ($dagName) {$dagName} else {'N/A'}
                            [void]$det.Add("DAGROW:${exSrv}:$($c.DatabaseName):${st}:${cq}:${rq}:${ci}:${dagLabel}:${health}")
                            if ($health -eq 'ISSUE') { [void]$issues.Add("[$exSrv] DB ISSUE: $($c.DatabaseName) | $st | CQ:$cq RQ:$rq") }
                        }
                    }
                } catch {
                    $em = $_.Exception.Message
                    if ($em -match 'DAG|not.*member|applicable') { [void]$det.Add("DAGROW:${exSrv}:N/A:Standalone:N/A:N/A:N/A:N/A:OK") }
                    else { [void]$issues.Add("[$exSrv] Query error: $em") }
                }
            } catch { [void]$issues.Add("[$exSrv] Session error: $($_.Exception.Message)") }
            finally { try { Remove-PSSession $conn.Session -EA SilentlyContinue } catch {} }
        }
        $srvList = $AllExchNames -join ', '
        $dagTxt  = if ($dagName) { " (DAG: $dagName)" } else { ' (No DAG)' }
        if ($issues.Count -gt 0 -and $det.Count -eq 0) { return New-HC 'Warning' 'Exchange Server' $srvList 'Cannot retrieve replication status' ($issues -join "`n") }
        if ($issues.Count -gt 0) { return New-HC 'Critical' 'Exchange Server' $srvList "$($issues.Count) DB copy issue(s)$dagTxt" (($issues -join "`n")+"`n"+($det -join "`n")) }
        New-HC 'Healthy' 'Exchange Server' $srvList "All DB copies healthy$dagTxt" ($det -join "`n")
    }

    # -- EXCH-2: Health Checkup --------------------------------------------------
    Write-Log '--- Exchange Health' -Level SECTION
    $R['Exch_Health'] = & {
        if ($AllExchNames.Count -eq 0) { return New-HC 'N/A' 'Exchange Server' 'N/A' 'No Exchange servers in servers.txt' }
        $det=[System.Collections.ArrayList]@(); $issues=[System.Collections.ArrayList]@(); $total=0
        $SvcList = @(
            @{N='MSExchangeTransport';            D='Transport';              Cat='Transport'}
            @{N='MSExchangeFrontendTransport';    D='Frontend Transport';     Cat='Transport'}
            @{N='MSExchangeDelivery';             D='Mailbox Delivery';       Cat='Transport'}
            @{N='MSExchangeSubmission';           D='Mailbox Submission';     Cat='Transport'}
            @{N='MSExchangeIS';                   D='Information Store';      Cat='Mailbox'}
            @{N='MSExchangeMailboxAssistants';    D='Mailbox Assistants';     Cat='Mailbox'}
            @{N='MSExchangeMailboxReplication';   D='Mailbox Replication';    Cat='Mailbox'}
            @{N='MSExchangeRepl';                 D='Replication (DAG)';      Cat='Mailbox'}
            @{N='MSExchangeRPC';                  D='RPC Client Access';      Cat='Client Access'}
            @{N='MSExchangeServiceHost';          D='Service Host';           Cat='Client Access'}
            @{N='MSExchangeADTopology';           D='AD Topology';            Cat='Infrastructure'}
            @{N='MSExchangeHM';                   D='Health Manager';         Cat='Infrastructure'}
            @{N='MSExchangeDiagnostics';          D='Diagnostics';            Cat='Infrastructure'}
            @{N='MSExchangeDagMgmt';              D='DAG Management';         Cat='Infrastructure'}
            @{N='W3SVC';                          D='IIS (World Wide Web)';   Cat='Web'}
            @{N='WAS';                            D='IIS Windows Activation'; Cat='Web'}
        )
        $crits = @('MSExchangeTransport','MSExchangeIS','MSExchangeRPC','MSExchangeADTopology','W3SVC','MSExchangeHM')
        foreach ($exSrv in $AllExchNames) {
            $conn = Connect-ExchangePS -Server $exSrv -Cred $Credential
            if (-not $conn.Success) { [void]$issues.Add("[$exSrv] Cannot connect: $($conn.Error)"); continue }
            try {
                $null = Import-PSSession $conn.Session -AllowClobber -DisableNameChecking -CommandName @('Get-DatabaseAvailabilityGroup','Get-MailboxDatabaseCopyStatus','Get-MailboxDatabase','Get-ExchangeServer') -EA SilentlyContinue 3>$null 4>$null
                [void]$det.Add("SERVER:$exSrv")
                [void]$det.Add('SECTION:DATABASES')
                try {
                    $dbs = @(Get-MailboxDatabase -Server $exSrv -Status -EA Stop | Sort-Object Name)
                    if ($dbs.Count -eq 0) { [void]$det.Add('DBROW:No databases found:N/A:N/A:N/A') }
                    else {
                        foreach ($db in $dbs) {
                            $szGB = ConvertTo-DBSizeGB -SizeObject $db.DatabaseSize
                            $sz   = if ($szGB -ge 0) {"$szGB GB"} else {'N/A'}
                            $mnt  = if ($db.Mounted) {'Mounted'} else {'DISMOUNTED'}
                            [void]$det.Add("DBROW:$($db.Name):${sz}:${mnt}:$([string]$db.EdbFilePath)")
                            if (-not $db.Mounted) { [void]$issues.Add("[$exSrv] DISMOUNTED: $($db.Name)"); $total++ }
                        }
                    }
                } catch { [void]$det.Add("DBROW:Error - $($_.Exception.Message):N/A:N/A:N/A") }
                [void]$det.Add('SECTION:DATABASE COPY STATUS')
                try {
                    $copies = @(Get-MailboxDatabaseCopyStatus -Server $exSrv -EA Stop | Sort-Object DatabaseName)
                    if ($copies.Count -eq 0) { [void]$det.Add('COPYROW:No copies (standalone):N/A:N/A:N/A:N/A:N/A:N/A:N/A') }
                    else {
                        foreach ($c in $copies) {
                            # Use PSObject.Properties to safely access DAG-only properties
                            # (HealthyCopies/HealthyQueues/UnhealthyQueues only exist in DAG environments)
                            $props = $c.PSObject.Properties
                            $hc = if ($props['HealthyCopies']   -and $null -ne $c.HealthyCopies)   { [string]$c.HealthyCopies }   else { 'N/A' }
                            $hq = if ($props['HealthyQueues']   -and $null -ne $c.HealthyQueues)   { [string]$c.HealthyQueues }   else { 'N/A' }
                            $uq = if ($props['UnhealthyQueues'] -and $null -ne $c.UnhealthyQueues) { [string]$c.UnhealthyQueues } else { 'N/A' }
                            $ci = if ($props['ContentIndexState'] -and $c.ContentIndexState)       { [string]$c.ContentIndexState } else { 'N/A' }
                            $st = if ($props['Status'])           { [string]$c.Status }           else { 'Unknown' }
                            $cq = if ($props['CopyQueueLength'])  { [string]$c.CopyQueueLength }  else { 'N/A' }
                            $rq = if ($props['ReplayQueueLength']){ [string]$c.ReplayQueueLength } else { 'N/A' }
                            [void]$det.Add("COPYROW:$($c.DatabaseName):${st}:${hc}:${hq}:${uq}:${cq}:${rq}:${ci}")
                            if ($st -notin @('Mounted','Healthy','SeedingSource')) { [void]$issues.Add("[$exSrv] COPY ISSUE: $($c.DatabaseName) | $st"); $total++ }
                        }
                    }
                } catch { [void]$det.Add("COPYROW:Error - $($_.Exception.Message):N/A:N/A:N/A:N/A:N/A:N/A:N/A") }
                [void]$det.Add('SECTION:EXCHANGE SERVICES')
                $sl2=$SvcList; $cr2=$crits
                $SvcSB = { param($defs,$crts)
                    $out=@()
                    foreach ($svc in $defs) {
                        $s=Get-Service -Name $svc.N -EA SilentlyContinue
                        if ($s) { $out+=@{N=$svc.N;D=$svc.D;Cat=$svc.Cat;Status=[string]$s.Status;Start=[string]$s.StartType} }
                        elseif ($svc.N -in $crts) { $out+=@{N=$svc.N;D=$svc.D;Cat=$svc.Cat;Status='NotFound';Start='N/A'} }
                    }
                    return $out
                }
                $svcRes = Invoke-SafeRemoteCommand -ServerName $exSrv -ScriptBlock $SvcSB -Credential $Credential -TimeoutSeconds 45 -ArgumentList @($sl2,$cr2)
                if ($svcRes.Success) {
                    foreach ($sv in @($svcRes.Data)) {
                        [void]$det.Add("SVCROW:$($sv.D):$($sv.Status):$($sv.Start):$($sv.Cat)")
                        if ($sv.Status -ne 'Running') { [void]$issues.Add("[$exSrv] SVC NOT RUNNING: $($sv.D)"); $total++ }
                    }
                } else { [void]$det.Add('SVCROW:Cannot retrieve services:Error:N/A:Infrastructure') }
                [void]$det.Add('ENDSRV:')
            } catch { [void]$issues.Add("[$exSrv] Session error: $($_.Exception.Message)") }
            finally { try { Remove-PSSession $conn.Session -EA SilentlyContinue } catch {} }
        }
        $srvList = $AllExchNames -join ', '
        $connFailed = @($issues | Where-Object { $_ -match 'Cannot connect' })
        $realIssues = @($issues | Where-Object { $_ -notmatch 'Cannot connect' })
        if (([array]@($connFailed)).Count -eq $AllExchNames.Count) {
            return New-HC 'Warning' 'Exchange Server' $srvList "Cannot connect to any Exchange server. Check WinRM/credentials. Tried: $($AllExchNames -join ', ')" ($det -join "`n")
        }
        $sev = if ($realIssues | Where-Object { $_ -match 'DISMOUNTED' }) {'Critical'} else {'Warning'}
        if ($issues.Count -gt 0) { return New-HC $sev 'Exchange Server' $srvList "$total issue(s) found on Exchange server(s)" ($det -join "`n") }
        New-HC 'Healthy' 'Exchange Server' $srvList "Exchange healthy - $($AllExchNames.Count) server(s) checked" ($det -join "`n")
    }

    # -- EXCH-3: Disk Space ------------------------------------------------------
    Write-Log '--- Exchange Disk' -Level SECTION
    $R['Exch_DiskStatus'] = & {
        if ($AllExchNames.Count -eq 0) { return New-HC 'N/A' 'Exchange Server' 'N/A' 'No Exchange servers in servers.txt' }
        $warnPct=75; $allWarn=[System.Collections.ArrayList]@(); $det=[System.Collections.ArrayList]@()
        $connOK3=0; $connFail3=[System.Collections.ArrayList]@()
        foreach ($exSrv in $AllExchNames) {
            $res = Invoke-SafeRemoteCommand -ServerName $exSrv -ScriptBlock $DiskSB -Credential $Credential -TimeoutSeconds 30 -ArgumentList @($warnPct)
            if (-not $res.Success) { [void]$det.Add("DISKROW:${exSrv}:Error:0:N/A:N/A:ERROR"); [void]$connFail3.Add($exSrv); continue }
            $connOK3++
            foreach ($row in @($res.Data.Rows)) {
                $p=$row -split '\|',4
                if ($p.Count -lt 4) { continue }
                $flag=if([double]$p[1] -ge $warnPct){'CRITICAL'}elseif([double]$p[1] -ge 60){'WARN'}else{'OK'}
                [void]$det.Add("DISKROW:${exSrv}:$($p[0]):$($p[1]):$($p[2]):$($p[3]):${flag}")
            }
            foreach ($w in @($res.Data.Warnings)) { [void]$allWarn.Add("[$exSrv] $w") }
        }
        $srvList = $AllExchNames -join ', '
        if ($connOK3 -eq 0) { return New-HC 'Warning' 'Exchange Server' $srvList "Cannot connect to any Exchange server. Check WinRM/credentials. Tried: $($connFail3 -join ', ')" ($det -join "`n") }
        if ($allWarn.Count -gt 0) { return New-HC 'Critical' 'Exchange Server' $srvList "ACTION REQUIRED: $($allWarn.Count) drive(s) >= $warnPct% on Exchange" ($det -join "`n") }
        $skipMsg3 = if ($connFail3.Count -gt 0) { " (could not reach: $($connFail3 -join ', '))" } else { '' }
        New-HC 'Healthy' 'Exchange Server' $srvList "All Exchange drives below $warnPct%$skipMsg3" ($det -join "`n")
    }

    # -- EXCH-4: DB Size Limits --------------------------------------------------
    Write-Log '--- Exchange DB Size Limits' -Level SECTION
    $R['Exch_DBSizeLimit'] = & {
        if ($AllExchNames.Count -eq 0) { return New-HC 'N/A' 'Exchange Server' 'N/A' 'No Exchange servers in servers.txt' }
        $det=[System.Collections.ArrayList]@(); $critical=[System.Collections.ArrayList]@(); $warnings=[System.Collections.ArrayList]@()
        # Exchange Standard Edition: hard dismount limit is 1 TB (1024 GB).
        # Warning threshold at 900 GB (90% of limit).
        # Registry key "Database Size Limit in GB" = 2048 removes the 1 TB cap entirely.
        # Any other registry value sets a custom limit.
        # Enterprise Edition: no hard limit (2 TB performance advisory).
        # HKLM:\SYSTEM\CurrentControlSet\Services\MSExchangeIS\<Srv>\Private-<GUID>
        $STD_LIMIT=1024; $STD_WARN=900; $ENT_LIMIT=2048; $ENT_WARN=1900
        $REG_UNLIMITED=2048   # Registry value that removes limit (matches Enterprise)
        $REG_BASE = 'HKLM:\SYSTEM\CurrentControlSet\Services\MSExchangeIS'
        foreach ($exSrv in $AllExchNames) {
            $conn = Connect-ExchangePS -Server $exSrv -Cred $Credential
            if (-not $conn.Success) { [void]$det.Add("DBLIMROW:${exSrv}:Unknown:Unknown:N/A:0:Unknown:N/A:NoReg:ERROR"); continue }
            try {
                $null = Import-PSSession $conn.Session -AllowClobber -DisableNameChecking -CommandName @('Get-DatabaseAvailabilityGroup','Get-MailboxDatabaseCopyStatus','Get-MailboxDatabase','Get-ExchangeServer') -EA SilentlyContinue 3>$null 4>$null
                $srvObj  = Get-ExchangeServer -Identity $exSrv -EA SilentlyContinue
                $edition = if ($srvObj) {[string]$srvObj.Edition} else {'Unknown'}
                $isStd   = $edition -match 'Standard'
                $isEnt   = $edition -match 'Enterprise'
                $dbs = @(Get-MailboxDatabase -Server $exSrv -Status -EA Stop | Sort-Object Name)
                foreach ($db in $dbs) {
                    $szGB = ConvertTo-DBSizeGB -SizeObject $db.DatabaseSize
                    $szStr = if ($szGB -ge 0) {"$szGB GB"} else {'N/A'}

                    # Check registry for per-database size limit override (Standard edition unlock)
                    $regLimitGB = 0
                    $hasRegOverride = $false
                    $regNote = 'No Registry Override'
                    if ($isStd) {
                        try {
                            # Get the database GUID to build the registry path
                            $dbGuid = [string]$db.Guid
                            $regPath = "$REG_BASE\$exSrv\Private-$dbGuid"
                            $RegSB = {
                                param($regPath)
                                $result = @{ Value=0; Exists=$false; Error='' }
                                try {
                                    if (Test-Path $regPath) {
                                        $prop = Get-ItemProperty -Path $regPath -Name 'Database Size Limit in GB' -EA Stop
                                        $result.Value  = [int]$prop.'Database Size Limit in GB'
                                        $result.Exists = $true
                                    }
                                } catch { $result.Error = $_.Exception.Message }
                                return $result
                            }
                            $regRes = Invoke-SafeRemoteCommand -ServerName $exSrv -ScriptBlock $RegSB `
                                          -Credential $Credential -TimeoutSeconds 15 -ArgumentList @($regPath)
                            if ($regRes.Success -and $regRes.Data.Exists) {
                                $regLimitGB     = [int]$regRes.Data.Value
                                $hasRegOverride = $true
                                # Value 2048 = removes 1 TB cap completely (unlimited / Enterprise-like)
                                # Any other value = custom limit in GB
                                if ($regLimitGB -le 0) { $regLimitGB = 1024 }
                                $regNote = if ($regLimitGB -ge $REG_UNLIMITED) {
                                    "Registry Override: Unlimited (2048 GB)"
                                } else {
                                    "Registry Override: $regLimitGB GB"
                                }
                            }
                        } catch { $regNote = "Registry Check Error" }
                    }

                    # Determine effective limit
                    if ($isEnt) {
                        $effectiveLimit = $ENT_LIMIT
                        $warnGB         = $ENT_WARN
                        $licLabel       = 'Enterprise (Advisory - 2 TB, no hard limit)'
                    } elseif ($isStd -and $hasRegOverride -and $regLimitGB -ge $REG_UNLIMITED) {
                        # Registry = 2048: limit removed, database will not be dismounted
                        $effectiveLimit = $ENT_LIMIT
                        $warnGB         = $ENT_WARN
                        $licLabel       = 'Standard + Registry Override (Limit Removed - 2 TB advisory)'
                    } elseif ($isStd -and $hasRegOverride -and $regLimitGB -gt 0) {
                        # Registry = custom value: use it as the limit
                        $effectiveLimit = $regLimitGB
                        $warnGB         = [math]::Round($regLimitGB * 0.90)
                        $licLabel       = "Standard + Registry Override ($regLimitGB GB limit)"
                    } else {
                        # Standard with no registry key: 1 TB hard dismount limit
                        $effectiveLimit = $STD_LIMIT
                        $warnGB         = $STD_WARN
                        $licLabel       = 'Standard (1 TB hard limit - dismounts at 1024 GB)'
                    }

                    $pctUsed = if ($szGB -ge 0 -and $effectiveLimit -gt 0) {[math]::Round(($szGB/$effectiveLimit)*100,1)} else {0}
                    $flag    = if ($szGB -ge $effectiveLimit) {'EXCEEDED'} elseif ($szGB -ge $warnGB) {'WARN'} else {'OK'}

                    [void]$det.Add("DBLIMROW:${exSrv}:$($db.Name):${edition}:${szStr}:${pctUsed}:${licLabel}:${effectiveLimit}:${regNote}:${flag}")
                    if ($flag -eq 'EXCEEDED') { [void]$critical.Add("[$exSrv] $($db.Name): $szStr EXCEEDS $effectiveLimit GB ($licLabel)") }
                    elseif ($flag -eq 'WARN')  { [void]$warnings.Add("[$exSrv] $($db.Name): $szStr approaching $effectiveLimit GB ($licLabel)") }
                }
            } catch { [void]$det.Add("DBLIMROW:${exSrv}:Error:Unknown:N/A:0:Query Error:N/A:NoReg:ERROR") }
            finally { try { Remove-PSSession $conn.Session -EA SilentlyContinue } catch {} }
        }
        $srvList = $AllExchNames -join ', '
        if ($critical.Count -gt 0) { return New-HC 'Critical' 'Exchange Server' $srvList "DB SIZE EXCEEDED on $($critical.Count) database(s)" ($det -join "`n") }
        if ($warnings.Count -gt 0) { return New-HC 'Warning'  'Exchange Server' $srvList "DB approaching size limit on $($warnings.Count) database(s)" ($det -join "`n") }
        New-HC 'Healthy' 'Exchange Server' $srvList "All Exchange databases within size limits" ($det -join "`n")
    }

    # -- EXCH-5: Edition ---------------------------------------------------------
    Write-Log '--- Exchange Edition' -Level SECTION
    $R['Exch_Edition'] = & {
        if ($AllExchNames.Count -eq 0) { return New-HC 'N/A' 'Exchange Server' 'N/A' 'No Exchange servers in servers.txt' }
        $det=[System.Collections.ArrayList]@(); $trial=[System.Collections.ArrayList]@(); $ent=[System.Collections.ArrayList]@(); $std=[System.Collections.ArrayList]@()
        foreach ($exSrv in $AllExchNames) {
            $conn = Connect-ExchangePS -Server $exSrv -Cred $Credential
            if (-not $conn.Success) { [void]$det.Add("EDROW:${exSrv}:Unknown:Cannot connect:N/A:N/A:N/A"); continue }
            try {
                $null = Import-PSSession $conn.Session -AllowClobber -DisableNameChecking -CommandName @('Get-DatabaseAvailabilityGroup','Get-MailboxDatabaseCopyStatus','Get-MailboxDatabase','Get-ExchangeServer') -EA SilentlyContinue 3>$null 4>$null
                $obj     = Get-ExchangeServer -Identity $exSrv -EA Stop
                $edition = [string]$obj.Edition; $ver=[string]$obj.AdminDisplayVersion
                $roles   = (@($obj.ServerRole) -join ', '); $site=([string]$obj.Site) -replace '^.*/',''
                $BSB = { $k='HKLM:\SOFTWARE\Microsoft\ExchangeServer\v15\Setup'
                    if (Test-Path $k) { $p=Get-ItemProperty $k -EA SilentlyContinue; return "$($p.MsiProductMajor).$($p.MsiProductMinor).$($p.MsiBuildMajor).$($p.MsiBuildMinor)" }; return 'N/A' }
                $br    = Invoke-SafeRemoteCommand -ServerName $exSrv -ScriptBlock $BSB -Credential $Credential -TimeoutSeconds 20
                $build = if ($br.Success -and $br.Data) {[string]$br.Data} else {'N/A'}
                switch -Wildcard ($edition) { '*Enterprise*'{[void]$ent.Add($exSrv)} '*Standard*'{[void]$std.Add($exSrv)} '*Trial*'{[void]$trial.Add($exSrv)} }
                [void]$det.Add("EDROW:${exSrv}:${edition}:${ver}:${build}:${site}:${roles}")
            } catch { [void]$det.Add("EDROW:${exSrv}:Error:$($_.Exception.Message):N/A:N/A:N/A") }
            finally { try { Remove-PSSession $conn.Session -EA SilentlyContinue } catch {} }
        }
        $srvList = $AllExchNames -join ', '
        if ($trial.Count -gt 0) { return New-HC 'Warning' 'Exchange Server' $srvList "UNLICENSED: $($trial.Count) server(s) on Trial edition" ($det -join "`n") }
        $sp=@(); if($ent.Count-gt 0){$sp+="$($ent.Count) Enterprise"}; if($std.Count-gt 0){$sp+="$($std.Count) Standard"}
        if ($sp.Count -eq 0 -and $AllExchNames.Count -gt 0) { 
            return New-HC 'Warning' 'Exchange Server' $srvList "Cannot connect to any Exchange server to check Edition. Tried: $($AllExchNames -join ', ')" ($det -join "`n") 
        }
        New-HC 'Healthy' 'Exchange Server' $srvList "Edition: $($sp -join ', ')" ($det -join "`n")
    }

    # -- EXCH-6: Time Sync -------------------------------------------------------
    Write-Log '--- Exchange Time Sync' -Level SECTION
    $R['Exch_TimeSync'] = & {
        if ($AllExchNames.Count -eq 0) { return New-HC 'N/A' 'Exchange Server' 'N/A' 'No Exchange servers in servers.txt' }
        $warns=[System.Collections.ArrayList]@(); $det=[System.Collections.ArrayList]@()
        foreach ($exSrv in $AllExchNames) {
            $res = Invoke-SafeRemoteCommand -ServerName $exSrv -ScriptBlock $TimeSB -Credential $Credential -TimeoutSeconds 30
            if (-not $res.Success) { [void]$warns.Add("[$exSrv] Connection failed"); [void]$det.Add("TIMEROW:${exSrv}:Error:N/A:N/A:FAIL"); continue }
            $d=$res.Data
            $src=if($d.Source){$d.Source}else{'Unknown'}; $off=if($d.Offset){$d.Offset}else{'N/A'}; $str=if($d.Stratum){$d.Stratum}else{'N/A'}
            $flag=if($d.OffsetSec -gt 5 -or $src -match 'Local CMOS|Free-running|unspecified|^none'){'WARN'}else{'OK'}
            [void]$det.Add("TIMEROW:${exSrv}:${src}:${off}:${str}:${flag}")
            if ($flag -eq 'WARN') { [void]$warns.Add("[$exSrv] NTP issue - Source: $src Offset: $off") }
        }
        $srvList = $AllExchNames -join ', '
        if ($warns.Count -gt 0) { return New-HC 'Warning' 'Exchange Server' $srvList ($warns -join ' | ') ($det -join "`n") }
        if ((@($warns | Where-Object { $_ -match 'Connection failed' })).Count -eq $AllExchNames.Count -and $AllExchNames.Count -gt 0) {
            return New-HC 'Warning' 'Exchange Server' $srvList "Cannot connect to any Exchange server for Time Sync check. Tried: $($AllExchNames -join ', ')" ($det -join "`n")
        }
        New-HC 'Healthy' 'Exchange Server' $srvList "Time sync healthy on $($AllExchNames.Count) Exchange server(s)" ($det -join "`n")
    }

    # -- DFS Checks --------------------------------------------------------------
    if ($AllDFSNames.Count -gt 0) {
        Write-Log '--- DFS Certificate' -Level SECTION
        $R['DFS_Certificate'] = & {
            $DFSCertSB = { param([int]$WD)
                $now=Get-Date; $all=@(Get-ChildItem Cert:\LocalMachine\My -EA SilentlyContinue | Where-Object {$_.Subject -notmatch 'CN=WMSvc'})
                $rows=@($all | Sort-Object NotAfter | ForEach-Object {
                    $days=[int]($_.NotAfter-$now).TotalDays
                    $st=if($_.NotAfter -le $now){'EXPIRED'}elseif($days -lt $WD){'Expiring Soon'}else{'Valid'}
                    $sans=try{$e=$_.Extensions|Where-Object{$_.Oid.FriendlyName -eq 'Subject Alternative Name'};if($e){($e.Format($false) -replace 'DNS Name=','' -replace ', ',',').Trim()}else{''}}catch{''}
                    [PSCustomObject]@{Subj=($_.Subject -replace 'CN=','') -replace ',.*','';Iss=($_.Issuer -replace 'CN=','') -replace ',.*','';NotBefore=$_.NotBefore.ToString('yyyy-MM-dd');NotAfter=$_.NotAfter.ToString('yyyy-MM-dd');Days=$days;Status=$st;HasPK=[bool]$_.HasPrivateKey;SAN=$sans}
                })
                return @{Certs=@($rows);Total=$all.Count}
            }
            $allExp=[System.Collections.ArrayList]@(); $allNear=[System.Collections.ArrayList]@(); $det=[System.Collections.ArrayList]@()
            foreach ($dfs in $AllDFSNames) {
                $res=Invoke-SafeRemoteCommand -ServerName $dfs -ScriptBlock $DFSCertSB -Credential $Credential -TimeoutSeconds 30 -ArgumentList @(30)
                if (-not $res.Success) { [void]$det.Add("SSLSRV:${dfs}:DFS:error"); [void]$det.Add("SSLERR:$($res.Error)"); continue }
                $d=$res.Data; [void]$det.Add("SSLSRV:${dfs}:DFS:$($d.Total)")
                foreach ($c in @($d.Certs)) {
                    [void]$det.Add("SSLROW:$($c.Subj):$($c.Iss):$($c.NotBefore):$($c.NotAfter):$($c.Days):$($c.Status):$($c.HasPK):$($c.SAN):N/A")
                    if ($c.Status -eq 'EXPIRED') { [void]$allExp.Add("[$dfs] EXPIRED: $($c.Subj)") }
                    elseif ($c.Status -eq 'Expiring Soon') { [void]$allNear.Add("[$dfs] Expiring $($c.Days) days: $($c.Subj)") }
                }
            }
            $srvList=$AllDFSNames -join ', '
            if ($allExp.Count  -gt 0) { return New-HC 'Critical' 'DFS' $srvList "$($allExp.Count) EXPIRED cert(s) on DFS"  ($det -join "`n") }
            if ($allNear.Count -gt 0) { return New-HC 'Warning'  'DFS' $srvList "$($allNear.Count) cert(s) expiring within 30 days" ($det -join "`n") }
            New-HC 'Healthy' 'DFS' $srvList "All certs valid on $($AllDFSNames.Count) DFS server(s)" ($det -join "`n")
        }

        Write-Log '--- DFS Replication' -Level SECTION
        $R['DFS_Replication'] = & {
            $DFSRepSB = {
                $issues=[System.Collections.ArrayList]@(); $det=[System.Collections.ArrayList]@()
                try { $svc=Get-Service DFSR -EA Stop; [void]$det.Add("SVC|$([string]$svc.Status)|$([string]$svc.StartType)"); if($svc.Status -ne 'Running'){[void]$issues.Add("DFSR service: $($svc.Status)")} }
                catch { [void]$det.Add('SVC|NotInstalled|N/A'); [void]$issues.Add('DFSR not installed') }
                try {
                    $sm=@{0='Uninitialized';1='Initialized';2='Initial Sync';3='Auto Recovery';4='Normal';5='In Error'}
                    $folders=@(Get-WmiObject -Namespace 'root\microsoftdfs' -Class DfsrReplicatedFolderInfo -EA Stop)
                    if ($folders.Count -eq 0) { [void]$det.Add('FOLDER|No replicated folders|N/A|N/A') }
                    else {
                        foreach ($f in $folders) {
                            $sn=if($sm.ContainsKey([int]$f.State)){$sm[[int]$f.State]}else{"State:$($f.State)"}
                            [void]$det.Add("FOLDER|$($f.ReplicatedFolderName)|$($f.ReplicationGroupName)|$sn")
                            if ($f.State -ne 4) { [void]$issues.Add("Folder '$($f.ReplicatedFolderName)': $sn") }
                        }
                    }
                } catch { [void]$det.Add("FOLDER|WMI Error|N/A|$($_.Exception.Message.Substring(0,[math]::Min(60,$_.Exception.Message.Length)))") }
                return @{Issues=@($issues);Det=@($det)}
            }
            $allIssues=[System.Collections.ArrayList]@(); $allDet=[System.Collections.ArrayList]@()
            foreach ($dfs in $AllDFSNames) {
                $res=Invoke-SafeRemoteCommand -ServerName $dfs -ScriptBlock $DFSRepSB -Credential $Credential -TimeoutSeconds 60
                if (-not $res.Success) { [void]$allDet.Add("DFSROW:${dfs}:Connection Failed:N/A:Cannot connect:ERROR"); continue }
                $d=$res.Data
                $svcLine=@($d.Det)|Where-Object{$_.StartsWith('SVC|')}|Select-Object -First 1
                $sp=if($svcLine){$svcLine -split '\|'}else{@('SVC','N/A','N/A')}
                $svcSt=if($sp.Count -ge 2){$sp[1]}else{'N/A'}
                $svcST=if($sp.Count -ge 3){$sp[2]}else{'N/A'}
                $svcHealth=if($svcSt -eq 'Running'){'OK'}else{'ISSUE'}
                [void]$allDet.Add("DFSROW:${dfs}:DFSR Service:${svcSt}:${svcST}:${svcHealth}")
                foreach ($fl in (@($d.Det)|Where-Object{$_.StartsWith('FOLDER|')})) {
                    $fp=$fl -split '\|',4
                    $fn=if($fp.Count -gt 1){$fp[1]}else{'N/A'}
                    $fg=if($fp.Count -gt 2){$fp[2]}else{'N/A'}
                    $fs=if($fp.Count -gt 3){$fp[3]}else{'N/A'}
                    $fh=if($fs -eq 'Normal'){'OK'}else{'ISSUE'}
                    [void]$allDet.Add("DFSROW:${dfs}:${fn}:${fg}:${fs}:${fh}")
                }
                foreach ($i in @($d.Issues)) { [void]$allIssues.Add("[$dfs] $i") }
            }
            $srvList=$AllDFSNames -join ', '
            if ($allIssues.Count -gt 0) { return New-HC 'Warning' 'DFS' $srvList "$($allIssues.Count) DFS issue(s)" ($allDet -join "`n") }
            New-HC 'Healthy' 'DFS' $srvList "DFS replication healthy on $($AllDFSNames.Count) server(s)" ($allDet -join "`n")
        }
    }

    # -- SSL: ADFS ---------------------------------------------------------------
    if ($AllADFSNames.Count -gt 0) {
        Write-Log '--- ADFS SSL Certificates' -Level SECTION
        $R['SSL_ADFS'] = & {
            $WarnDays=30
            $ADFSCertSB = { param([int]$WD)
                $now=Get-Date; $all=@(Get-ChildItem Cert:\LocalMachine\My -EA SilentlyContinue|Where-Object{$_.Subject -notmatch 'CN=WMSvc'})
                $rows=@($all|Sort-Object NotAfter|ForEach-Object{
                    $days=[int]($_.NotAfter-$now).TotalDays
                    $st=if($_.NotAfter -le $now){'EXPIRED'}elseif($days -lt $WD){'Expiring Soon'}else{'Valid'}
                    $sans=try{$e=$_.Extensions|Where-Object{$_.Oid.FriendlyName -eq 'Subject Alternative Name'};if($e){($e.Format($false) -replace 'DNS Name=','' -replace ', ',',').Trim()}else{''}}catch{''}
                    $bound=try{$t=$_.Thumbprint;$r=@(& netsh http show sslcert 2>&1|Select-String $t);$r.Count -gt 0}catch{$false}
                    [PSCustomObject]@{Subj=($_.Subject -replace 'CN=','') -replace ',.*','';Iss=($_.Issuer -replace 'CN=','') -replace ',.*','';NotBefore=$_.NotBefore.ToString('yyyy-MM-dd');NotAfter=$_.NotAfter.ToString('yyyy-MM-dd');Days=$days;Status=$st;HasPK=[bool]$_.HasPrivateKey;SAN=$sans;AdfsBound=$bound}
                })
                return @{Certs=@($rows);Total=$all.Count}
            }
            $det=[System.Collections.ArrayList]@(); $expired=[System.Collections.ArrayList]@(); $expiring=[System.Collections.ArrayList]@()
            foreach ($srv in $AllADFSNames) {
                $res=Invoke-SafeRemoteCommand -ServerName $srv -ScriptBlock $ADFSCertSB -Credential $Credential -TimeoutSeconds 30 -ArgumentList @($WarnDays)
                if (-not $res.Success) { [void]$det.Add("SSLSRV:${srv}:ADFS:error"); [void]$det.Add("SSLERR:$($res.Error)"); continue }
                $d=$res.Data; [void]$det.Add("SSLSRV:${srv}:ADFS:$($d.Total)")
                foreach ($c in @($d.Certs)) {
                    $bound=if($c.AdfsBound){'ADFS-Bound'}else{'N/A'}
                    [void]$det.Add("SSLROW:$($c.Subj):$($c.Iss):$($c.NotBefore):$($c.NotAfter):$($c.Days):$($c.Status):$($c.HasPK):$($c.SAN):${bound}")
                    if ($c.Status -eq 'EXPIRED') { [void]$expired.Add("[$srv] EXPIRED: $($c.Subj)") }
                    elseif ($c.Status -eq 'Expiring Soon') { [void]$expiring.Add("[$srv] Expiring $($c.Days) days: $($c.Subj)") }
                }
            }
            $srvList=$AllADFSNames -join ', '
            if ($expired.Count  -gt 0) { return New-HC 'Critical' 'Security' $srvList "$($expired.Count) EXPIRED ADFS cert(s) - IMMEDIATE ACTION" ($det -join "`n") }
            if ($expiring.Count -gt 0) { return New-HC 'Warning'  'Security' $srvList "$($expiring.Count) ADFS cert(s) expiring within $WarnDays days" ($det -join "`n") }
            New-HC 'Healthy' 'Security' $srvList "All ADFS certificates valid on $($AllADFSNames.Count) server(s)" ($det -join "`n")
        }
    }

    # -- SSL: Exchange -----------------------------------------------------------
    if ($AllExchNames.Count -gt 0) {
        Write-Log '--- Exchange SSL Certificates' -Level SECTION
        $R['SSL_Exchange'] = & {
            $WarnDays=30
            $ExchCertSB = { param([int]$WD)
                $now=Get-Date; $all=@(Get-ChildItem Cert:\LocalMachine\My -EA SilentlyContinue|Where-Object{$_.Subject -notmatch 'CN=WMSvc'})
                $rows=@($all|Sort-Object NotAfter|ForEach-Object{
                    $days=[int]($_.NotAfter-$now).TotalDays
                    $st=if($_.NotAfter -le $now){'EXPIRED'}elseif($days -lt $WD){'Expiring Soon'}else{'Valid'}
                    $sans=try{$e=$_.Extensions|Where-Object{$_.Oid.FriendlyName -eq 'Subject Alternative Name'};if($e){($e.Format($false) -replace 'DNS Name=','' -replace ', ',',').Trim()}else{''}}catch{''}
                    [PSCustomObject]@{Subj=($_.Subject -replace 'CN=','') -replace ',.*','';Iss=($_.Issuer -replace 'CN=','') -replace ',.*','';NotBefore=$_.NotBefore.ToString('yyyy-MM-dd');NotAfter=$_.NotAfter.ToString('yyyy-MM-dd');Days=$days;Status=$st;HasPK=[bool]$_.HasPrivateKey;SAN=$sans}
                })
                return @{Certs=@($rows);Total=$all.Count}
            }
            $det=[System.Collections.ArrayList]@(); $expired=[System.Collections.ArrayList]@(); $expiring=[System.Collections.ArrayList]@()
            foreach ($srv in $AllExchNames) {
                $res=Invoke-SafeRemoteCommand -ServerName $srv -ScriptBlock $ExchCertSB -Credential $Credential -TimeoutSeconds 30 -ArgumentList @($WarnDays)
                if (-not $res.Success) { [void]$det.Add("SSLSRV:${srv}:Exchange:error"); [void]$det.Add("SSLERR:$($res.Error)"); continue }
                $d=$res.Data; [void]$det.Add("SSLSRV:${srv}:Exchange:$($d.Total)")
                foreach ($c in @($d.Certs)) {
                    [void]$det.Add("SSLROW:$($c.Subj):$($c.Iss):$($c.NotBefore):$($c.NotAfter):$($c.Days):$($c.Status):$($c.HasPK):$($c.SAN):N/A")
                    if ($c.Status -eq 'EXPIRED') { [void]$expired.Add("[$srv] EXPIRED: $($c.Subj)") }
                    elseif ($c.Status -eq 'Expiring Soon') { [void]$expiring.Add("[$srv] Expiring $($c.Days) days: $($c.Subj)") }
                }
            }
            $srvList=$AllExchNames -join ', '
            if ($expired.Count  -gt 0) { return New-HC 'Critical' 'Security' $srvList "$($expired.Count) EXPIRED Exchange cert(s)" ($det -join "`n") }
            if ($expiring.Count -gt 0) { return New-HC 'Warning'  'Security' $srvList "$($expiring.Count) Exchange cert(s) expiring within $WarnDays days" ($det -join "`n") }
            New-HC 'Healthy' 'Security' $srvList "All Exchange SSL certificates valid on $($AllExchNames.Count) server(s)" ($det -join "`n")
        }
    }

Write-Log "All checks complete - $($R.Count) executed" -Level SUCCESS
    # Safety cleanup: remove any orphaned Exchange/WinRM sessions
    try { Get-PSSession | Where-Object { $_.State -ne 'Opened' } | Remove-PSSession -EA SilentlyContinue } catch {}
    return $R
}

# ============================================================
# HTML DETAIL RENDERER
# [F02] FIX: All parent-scope captures done via explicit parameters, no & $scriptblock
# ============================================================
function Render-DetailHtml {
    param([string]$Det, [string]$Key)
    if (-not $Det -or $Det.Trim().Length -eq 0) {
        return '<span style="color:#888;font-style:italic">No details available</span>'
    }
    $lines = $Det -split "`n"
    $sb    = [System.Text.StringBuilder]::new()

    # -- AD Replication (repadmin table) ----------------------------------------
    if ($Key -eq 'AD_Replication') {
        $curTitle = ''; $curRows = [System.Collections.ArrayList]@()
        # [F02] FIX: inline flush instead of & $scriptblock
        $needFlush = $false
        foreach ($ln in ($lines | ForEach-Object { $_.TrimEnd() })) {
            if ($ln -match 'Replication Summary|Collected:|DCs:') {
                [void]$sb.Append('<div class="det-info">' + (ConvertTo-HtmlEscaped $ln.Trim()) + '</div>')
                continue
            }
            if ($ln -match '(Source\s+DSA|Destination\s+DSA)') {
                # flush previous
                if ($needFlush -and $curRows.Count -gt 0) {
                    [void]$sb.Append("<div class='det-stitle'>$curTitle</div>")
                    [void]$sb.Append("<div class='tw'><table class='dt'><thead><tr><th>Server (DSA)</th><th>Largest Delta</th><th>Failures</th><th>Total</th><th>Fail%</th><th>Error</th></tr></thead><tbody>")
                    foreach ($pr in $curRows) {
                        $bg  = if ($pr.Fails -gt 0) {"#fff0f0"} else {""}
                        $fCl = if ($pr.Fails -gt 0) {"color:#c0392b;font-weight:700"} else {"color:#27ae60"}
                        $eV  = if ($pr.Err) {"<span style='color:#c0392b;font-size:10px'>$(ConvertTo-HtmlEscaped $pr.Err)</span>"} else {"<span style='color:#27ae60'>OK</span>"}
                        [void]$sb.Append('<tr style="background:' + $bg + '"><td>' + (ConvertTo-HtmlEscaped $pr.Srv) + '</td><td>' + (ConvertTo-HtmlEscaped $pr.Dlt) + '</td><td style="' + $fCl + ';text-align:center">' + $pr.Fails + '</td><td style="text-align:center">' + $pr.Total + '</td><td style="' + $fCl + ';text-align:center">' + $pr.Pct + '%</td><td>' + $eV + '</td></tr>')
                    }
                    [void]$sb.Append("</tbody></table></div>")
                    $curRows.Clear()
                }
                $curTitle = $Matches[1] -replace '\s+',' '; $needFlush = $true
                continue
            }
            if ($ln -match '^\s*largest\s+delta|^\s*[-=]+\s*$|^\s*$|Beginning data|this may take') { continue }
            if ($ln -match '^\s+(\S+)\s+(\S+)\s+(\d+)\s*/\s*(\d+)\s+(\d+)\s*(.*)$') {
                $errTxt = ($Matches[6].Trim() -replace '^\(\d+\)\s*','')
                [void]$curRows.Add([PSCustomObject]@{ Srv=$Matches[1];Dlt=$Matches[2];Fails=[int]$Matches[3];Total=[int]$Matches[4];Pct=[int]$Matches[5];Err=$errTxt })
            }
        }
        # final flush
        if ($needFlush -and $curRows.Count -gt 0) {
            [void]$sb.Append("<div class='det-stitle'>$curTitle</div>")
            [void]$sb.Append("<div class='tw'><table class='dt'><thead><tr><th>Server (DSA)</th><th>Largest Delta</th><th>Failures</th><th>Total</th><th>Fail%</th><th>Error</th></tr></thead><tbody>")
            foreach ($pr in $curRows) {
                $bg  = if ($pr.Fails -gt 0) {"#fff0f0"} else {""}
                $fCl = if ($pr.Fails -gt 0) {"color:#c0392b;font-weight:700"} else {"color:#27ae60"}
                $eV  = if ($pr.Err) {"<span style='color:#c0392b;font-size:10px'>$(ConvertTo-HtmlEscaped $pr.Err)</span>"} else {"<span style='color:#27ae60'>OK</span>"}
                [void]$sb.Append('<tr style="background:' + $bg + '"><td>' + (ConvertTo-HtmlEscaped $pr.Srv) + '</td><td>' + (ConvertTo-HtmlEscaped $pr.Dlt) + '</td><td style="' + $fCl + ';text-align:center">' + $pr.Fails + '</td><td style="text-align:center">' + $pr.Total + '</td><td style="' + $fCl + ';text-align:center">' + $pr.Pct + '%</td><td>' + $eV + '</td></tr>')
            }
            [void]$sb.Append("</tbody></table></div>")
        }
        return $sb.ToString()
    }

    # -- SSL Certs (ADFS / Exchange / DFS) ----------------------------------------
    if ($Key -in @('SSL_ADFS','SSL_Exchange','DFS_Certificate')) {
        $inTable=$false; $certCnt=0
        foreach ($ln in ($lines | ForEach-Object { $_.TrimEnd() })) {
            if ($ln -match '^SSLSRV:([^:]+):([^:]+):(.+)$') {
                if ($inTable) { [void]$sb.Append('</tbody></table></div></div>'); $inTable=$false }
                $srv=ConvertTo-HtmlEscaped $Matches[1]; $srvType=$Matches[2]; $total=$Matches[3]; $certCnt=0
                $badge=switch($srvType){'ADFS'{"<span class='b-adfs'>ADFS</span>"}'DFS'{"<span class='b-dfs'>DFS</span>"}default{"<span class='b-exch'>Exchange</span>"}}
                [void]$sb.Append("<div class='scard'><div class='shdr'>$srv $badge <span class='smeta'>$total cert(s)</span></div>")
                [void]$sb.Append("<div class='tw'><table class='dt'><thead><tr><th>Status</th><th>Subject</th><th>Issuer</th><th>Valid From</th><th>Expires</th><th>Days</th><th>SAN</th></tr></thead><tbody>")
                $inTable=$true; continue
            }
            if ($ln -match '^SSLERR:(.+)$') { [void]$sb.Append('<tr><td colspan="7" style="color:#c0392b;font-style:italic">' + (ConvertTo-HtmlEscaped $Matches[1]) + '</td></tr>'); continue }
            if ($ln -match '^SSLROW:') {
                $p=$ln.Substring(7) -split ':',9; if ($p.Count -lt 6) { continue }
                $certCnt++
                $subj=ConvertTo-HtmlEscaped $p[0]; $iss=ConvertTo-HtmlEscaped $p[1]; $nbef=$p[2]; $naft=$p[3]; $days=$p[4]; $st=$p[5]
                $sanRaw = if($p.Count -gt 7){$p[7]}else{''}

                $san = ConvertTo-HtmlEscaped $sanRaw
                $sanS=if($san.Length -gt 55){$san.Substring(0,52)+'...'}else{$san}
                $rowBg=switch($st){'EXPIRED'{'#fff0f0'}'Expiring Soon'{'#fffbf0'}default{''}}
                $stBadge=switch($st){'EXPIRED'{"<span class='bexp'>EXPIRED</span>"}'Expiring Soon'{"<span class='bnear'>Expiring</span>"}default{"<span class='bok'>Valid</span>"}}
                $dC=if([int]$days -lt 0){'color:#c0392b;font-weight:700'}elseif([int]$days -lt 30){'color:#d4a000;font-weight:700'}else{'color:#27ae60'}
                [void]$sb.Append("<tr style='background:$rowBg'><td style='text-align:center'>$stBadge</td><td><strong>$subj</strong></td><td style='color:#607080;font-size:10px'>$iss</td><td style='text-align:center;font-size:10px'>$nbef</td><td style='text-align:center;font-size:10px'>$naft</td><td style='text-align:center;$dC'>$days</td><td style='font-size:10px;color:#607080'>$sanS</td></tr>")
            }
        }
        if ($inTable) { [void]$sb.Append('</tbody></table></div></div>') }
        return $sb.ToString()
    }

    # -- Exchange Edition ---------------------------------------------------------
    if ($Key -eq 'Exch_Edition') {
        [void]$sb.Append("<div class='tw'><table class='dt'><thead><tr><th>Server</th><th>Edition</th><th>Version</th><th>Build</th><th>AD Site</th><th>Roles</th></tr></thead><tbody>")
        $ri=0
        foreach ($ln in ($lines | ForEach-Object { $_.TrimEnd() })) {
            if (-not $ln.StartsWith('EDROW:')) { continue }
            $p=$ln.Substring(6) -split ':',6
            $sN=ConvertTo-HtmlEscaped $p[0]; $ed=ConvertTo-HtmlEscaped $p[1]; $ver=ConvertTo-HtmlEscaped $p[2]
            $bld=ConvertTo-HtmlEscaped $p[3]; $site=ConvertTo-HtmlEscaped $p[4]; $roles=ConvertTo-HtmlEscaped $p[5]
            $bg=if($ri%2){'#f8fbff'}else{''}
            $edBg=switch -Wildcard($ed){'*Enterprise*'{'#1a3a6b'}'*Standard*'{'#1a5a2b'}'*Trial*'{'#8b0000'}default{'#444'}}
            [void]$sb.Append("<tr style='background:$bg'><td><strong>$sN</strong></td><td style='text-align:center'><span style='background:$edBg;color:#fff;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:700'>$ed</span></td><td style='font-size:11px'>$ver</td><td style='font-family:Consolas,monospace;font-size:11px;text-align:center'>$bld</td><td style='color:#607080;font-size:11px'>$site</td><td style='color:#607080;font-size:11px'>$roles</td></tr>")
            $ri++
        }
        [void]$sb.Append("</tbody></table></div>")
        return $sb.ToString()
    }

    # -- Exchange DB Size Limits --------------------------------------------------
    if ($Key -eq 'Exch_DBSizeLimit') {
        [void]$sb.Append('<div class="det-info" style="margin-bottom:8px;padding:10px 14px;background:#f0f6ff;border-left:4px solid #0078d4;border-radius:0 6px 6px 0;font-size:11px;line-height:1.6">')
        [void]$sb.Append('<strong style="color:#0078d4">&#8505; Exchange Database Size Limits</strong><br>')
        [void]$sb.Append('<strong>Standard Edition</strong>: Hard dismount limit is <strong>1 TB (1024 GB)</strong> per database. ')
        [void]$sb.Append('Database will be automatically dismounted when it reaches 1024 GB unless a registry key is set.<br>')
        [void]$sb.Append('<strong>Registry Key to remove limit</strong>: Set ')
        [void]$sb.Append('<code style="background:#e8f0fe;padding:1px 5px;border-radius:3px;color:#1a237e">Database Size Limit in GB</code> = ')
        [void]$sb.Append('<code style="background:#e8f0fe;padding:1px 5px;border-radius:3px;color:#c0392b">2048</code> (DWORD) at:<br>')
        [void]$sb.Append('<code style="background:#e8f0fe;padding:1px 5px;border-radius:3px;color:#1a237e;font-size:10px">HKLM\SYSTEM\CurrentControlSet\Services\MSExchangeIS\&lt;Server&gt;\Private-&lt;DB-GUID&gt;</code><br>')
        [void]$sb.Append('Setting value to 2048 removes the 1 TB cap entirely (equivalent to Enterprise). Other values set a custom limit.<br>')
        [void]$sb.Append('<strong>Enterprise Edition</strong>: No hard limit enforced (2 TB performance advisory only).</div>')
        [void]$sb.Append('<table class="dt" style="width:100%;border-collapse:collapse"><thead><tr>')
        [void]$sb.Append('<th style="width:130px">Server</th><th>Database</th><th style="width:110px">Edition</th>')
        [void]$sb.Append('<th style="width:80px;text-align:right">DB Size</th><th style="width:180px">% of Limit</th>')
        [void]$sb.Append('<th>License / Limit</th><th style="width:120px">Registry Override</th><th style="width:90px;text-align:center">Health</th>')
        [void]$sb.Append('</tr></thead><tbody>')
        $ri=0
        foreach ($ln in ($lines | ForEach-Object { $_.TrimEnd() })) {
            if (-not $ln.StartsWith('DBLIMROW:')) { continue }
            # Format: DBLIMROW:srv:db:edition:size:pct:lic:limitGB:regNote:flag  (10 fields after prefix)
            $p = $ln.Substring(9) -split ':',10
            if ($p.Count -lt 9) { continue }
            $srv     = ConvertTo-HtmlEscaped $p[0]
            $dbn     = ConvertTo-HtmlEscaped $p[1]
            $ed      = ConvertTo-HtmlEscaped $p[2]
            $sz      = ConvertTo-HtmlEscaped $p[3]
            $pct     = $p[4]
            $lic     = ConvertTo-HtmlEscaped $p[5]
            $regNote = ConvertTo-HtmlEscaped $p[7]
            $flag    = if ($p.Count -ge 10) {$p[9]} else {$p[8]}
            $bg      = switch($flag){'EXCEEDED'{'#fff0f0'}'WARN'{'#fffbf0'}default{if($ri%2){'#f8fbff'}else{''}}}
            $hBadge  = switch($flag){
                'EXCEEDED' {'<span class="bexp">EXCEEDED</span>'}
                'WARN'     {'<span class="bnear">WARNING</span>'}
                'ERROR'    {'<span class="bnear">ERROR</span>'}
                default    {'<span class="bok">OK</span>'}
            }
            $pctN = [double]($pct -replace '[^0-9\.]','0')
            $barW = [math]::Min(100,[math]::Round($pctN))
            $barC = if($pctN -ge 100){'#c0392b'}elseif($pctN -ge 94){'#d4a000'}else{'#27ae60'}
            $barHtml  = '<div style="background:#dde2ec;border-radius:4px;height:10px;width:130px;display:inline-block;vertical-align:middle;overflow:hidden">'
            $barHtml += '<div style="background:' + $barC + ';width:' + $barW + '%;height:10px"></div></div>'
            $barHtml += ' <span style="font-size:11px;color:' + $barC + ';font-weight:700">' + $pct + '%</span>'
            # Registry note styling
            # Standard edition: green checkmark if override exists, red X if not
            # Enterprise edition: grey (registry key not required)
            $hasReg    = ($regNote -match 'Registry Override') -and ($regNote -notmatch '^No')
            $isStdEd   = $ed -match 'Standard'
            $regStyle  = if ($hasReg)                        { 'color:#107c41;font-weight:700' } `
                         elseif ($regNote -match 'Error')    { 'color:#c0392b;font-weight:700' } `
                         elseif ($isStdEd)                   { 'color:#c0392b;font-weight:700' } `
                         else                                { 'color:#888;font-style:italic' }
            $regIcon   = if ($hasReg)                        { '&#10003; ' } `
                         elseif ($isStdEd -and -not $hasReg -and $regNote -notmatch 'Error') { '&#10007; ' } `
                         else                                { '' }
            [void]$sb.Append('<tr style="background:' + $bg + '">')
            [void]$sb.Append('<td><strong>' + $srv + '</strong></td>')
            [void]$sb.Append('<td style="font-weight:600">' + $dbn + '</td>')
            [void]$sb.Append('<td style="font-size:11px;color:#607080">' + $ed + '</td>')
            [void]$sb.Append('<td style="text-align:right;font-weight:700">' + $sz + '</td>')
            [void]$sb.Append('<td>' + $barHtml + '</td>')
            [void]$sb.Append('<td style="font-size:11px">' + $lic + '</td>')
            [void]$sb.Append('<td style="font-size:11px;' + $regStyle + '">' + $regIcon + $regNote + '</td>')
            [void]$sb.Append('<td style="text-align:center">' + $hBadge + '</td>')
            [void]$sb.Append('</tr>')
            $ri++
        }
        [void]$sb.Append('</tbody></table>')
        return $sb.ToString()
    }

    # -- Exchange Health (multi-section) ------------------------------------------
    if ($Key -eq 'Exch_Health') {
        $inTable=$false; $freeBuf=[System.Collections.ArrayList]@(); $openCard=$false
        foreach ($ln in ($lines | ForEach-Object { $_.TrimEnd() })) {
            if ($ln -match '^SERVER:(.+)$') {
                if ($freeBuf.Count -gt 0) { [void]$sb.Append("<pre class='dpre'>"); foreach ($fl in $freeBuf) { [void]$sb.Append((ConvertTo-HtmlEscaped $fl) + "`n") }; [void]$sb.Append("</pre>"); $freeBuf.Clear() }
                if ($inTable) { [void]$sb.Append("</tbody></table></div>"); $inTable=$false }
                if ($openCard) { [void]$sb.Append("</div>") }
                [void]$sb.Append('<div class="scard"><div class="shdr">Exchange: ' + (ConvertTo-HtmlEscaped $Matches[1].Trim()) + '</div>'); $openCard=$true; continue
            }
            if ($ln -match '^ENDSRV:') {
                if ($freeBuf.Count -gt 0) { [void]$sb.Append("<pre class='dpre'>"); foreach ($fl in $freeBuf) { [void]$sb.Append((ConvertTo-HtmlEscaped $fl) + "`n") }; [void]$sb.Append("</pre>"); $freeBuf.Clear() }
                if ($inTable) { [void]$sb.Append("</tbody></table></div>"); $inTable=$false }
                if ($openCard) { [void]$sb.Append("</div>"); $openCard=$false }; continue
            }
            if ($ln -match '^SECTION:(.+)$') {
                if ($freeBuf.Count -gt 0) { [void]$sb.Append("<pre class='dpre'>"); foreach ($fl in $freeBuf) { [void]$sb.Append((ConvertTo-HtmlEscaped $fl) + "`n") }; [void]$sb.Append("</pre>"); $freeBuf.Clear() }
                if ($inTable) { [void]$sb.Append("</tbody></table></div>"); $inTable=$false }
                [void]$sb.Append('<div class="det-stitle">' + (ConvertTo-HtmlEscaped $Matches[1].Trim()) + '</div>')
                switch ($Matches[1].Trim()) {
                    'DATABASES'            { [void]$sb.Append("<div class='tw'><table class='dt'><thead><tr><th>Database</th><th>Size</th><th>Status</th><th>EDB Path</th></tr></thead><tbody>"); $inTable=$true }
                    'DATABASE COPY STATUS' { [void]$sb.Append("<div class='tw'><table class='dt'><thead><tr><th>Database</th><th>Status</th><th>Hlthy Copies</th><th>Hlthy Q</th><th>Unhlthy Q</th><th>Copy Q</th><th>Replay Q</th><th>Content Index</th></tr></thead><tbody>"); $inTable=$true }
                    'EXCHANGE SERVICES'    { [void]$sb.Append("<div class='tw'><table class='dt'><thead><tr><th></th><th>Service</th><th>Status</th><th>Start Type</th><th>Category</th></tr></thead><tbody>"); $inTable=$true }
                }; continue
            }
            if ($ln -match '^DBROW:') {
                $p=$ln.Substring(6) -split ':',4
                $dN=ConvertTo-HtmlEscaped $p[0]; $sz=ConvertTo-HtmlEscaped $p[1]; $mnt=ConvertTo-HtmlEscaped $p[2]; $pth=ConvertTo-HtmlEscaped $p[3]
                $mS=if($mnt -eq 'DISMOUNTED'){'color:#c0392b;font-weight:700'}else{'color:#27ae60;font-weight:600'}
                $bg=if($mnt -eq 'DISMOUNTED'){'#fff0f0'}else{''}
                [void]$sb.Append("<tr style='background:$bg'><td><strong>$dN</strong></td><td style='text-align:center'>$sz</td><td style='text-align:center;$mS'>$mnt</td><td style='font-size:10px;color:#607080;word-break:break-all'>$pth</td></tr>"); continue
            }
            if ($ln -match '^COPYROW:') {
                $p=$ln.Substring(8) -split ':',8
                $dN=ConvertTo-HtmlEscaped $p[0]; $st=ConvertTo-HtmlEscaped $p[1]; $hc=$p[2]; $hq=$p[3]; $uq=$p[4]; $cq=$p[5]; $rq=$p[6]; $ci=ConvertTo-HtmlEscaped $p[7]
                $stOK=$st -in @('Mounted','Healthy','SeedingSource')
                $stS=if($stOK){'color:#27ae60;font-weight:700'}else{'color:#c0392b;font-weight:700'}
                $bg=if(-not $stOK){'#fff0f0'}else{''}
                [void]$sb.Append("<tr style='background:$bg'><td><strong>$dN</strong></td><td style='text-align:center;$stS'>$st</td><td style='text-align:center'>$hc</td><td style='text-align:center'>$hq</td><td style='text-align:center'>$uq</td><td style='text-align:center'>$cq</td><td style='text-align:center'>$rq</td><td style='font-size:10px'>$ci</td></tr>"); continue
            }
            if ($ln -match '^SVCROW:') {
                $p=$ln.Substring(7) -split ':',4
                $sN=ConvertTo-HtmlEscaped $p[0]; $st=ConvertTo-HtmlEscaped $p[1]; $sp2=ConvertTo-HtmlEscaped $p[2]; $cat=ConvertTo-HtmlEscaped $p[3]
                $isOK=($st -eq 'Running')
                $icon=if($isOK){"<span style='color:#27ae60;font-size:14px;font-weight:700'>&#10003;</span>"}else{"<span style='color:#c0392b;font-size:14px;font-weight:700'>&#10007;</span>"}
                $stS=if($isOK){'color:#27ae60;font-weight:600'}else{'color:#c0392b;font-weight:700'}
                $bg=if(-not $isOK){'#fff0f0'}else{''}
                [void]$sb.Append("<tr style='background:$bg'><td style='text-align:center'>$icon</td><td><strong>$sN</strong></td><td style='text-align:center;$stS'>$st</td><td style='text-align:center;color:#607080'>$sp2</td><td><span style='font-size:9px;background:#eef2f6;color:#607080;padding:1px 5px;border-radius:3px'>$cat</span></td></tr>"); continue
            }
            $esc=ConvertTo-HtmlEscaped $ln
            if ($ln.Trim().Length -eq 0) { if($freeBuf.Count -gt 0){[void]$freeBuf.Add('')}; continue }
            [void]$freeBuf.Add($esc)
        }
        if ($freeBuf.Count -gt 0) { [void]$sb.Append("<pre class='dpre'>"); foreach ($fl in $freeBuf) { [void]$sb.Append((ConvertTo-HtmlEscaped $fl) + "`n") }; [void]$sb.Append("</pre>") }
        if ($inTable) { [void]$sb.Append("</tbody></table></div>") }
        if ($openCard) { [void]$sb.Append("</div>") }
        return $sb.ToString()
    }

    # -- Time Sync ----------------------------------------------------------------
    if ($Key -in @('AD_TimeSync','Exch_TimeSync')) {
        $hasRows=$false
        [void]$sb.Append("<div class='tw'><table class='dt'><thead><tr><th>Server</th><th>NTP Source</th><th>Phase Offset</th><th>Stratum</th><th>Health</th></tr></thead><tbody>")
        foreach ($ln in ($lines | ForEach-Object { $_.TrimEnd() })) {
            if (-not $ln.StartsWith('TIMEROW:')) { continue }
            $p=$ln.Substring(8) -split ':',5; if ($p.Count -lt 5) { continue }
            $srv=ConvertTo-HtmlEscaped $p[0]; $src=ConvertTo-HtmlEscaped $p[1]; $off=ConvertTo-HtmlEscaped $p[2]; $str=ConvertTo-HtmlEscaped $p[3]; $flag=$p[4]
            $isW=($flag -eq 'WARN' -or $flag -eq 'FAIL')
            $hBdg=if($flag -eq 'FAIL'){"<span class='bexp'>FAIL</span>"}elseif($isW){"<span class='bnear'>WARN</span>"}else{"<span class='bok'>OK</span>"}
            $bg=if($isW){'#fffbf0'}else{''}
            [void]$sb.Append("<tr style='background:$bg'><td><strong>$srv</strong></td><td>$src</td><td style='text-align:center'>$off</td><td style='text-align:center'>$str</td><td style='text-align:center'>$hBdg</td></tr>")
            $hasRows=$true
        }
        [void]$sb.Append("</tbody></table></div>")
        if ($hasRows) { return $sb.ToString() }
        return "<pre class='dpre'>$(ConvertTo-HtmlEscaped $Det)</pre>"
    }

    # -- Disk Space ---------------------------------------------------------------
    if ($Key -in @('AD_DiskStatus','Exch_DiskStatus')) {
        $hasRows=$false
        [void]$sb.Append('<table class="dt" style="width:100%;border-collapse:collapse"><thead><tr>')
        [void]$sb.Append('<th style="width:160px">Server</th><th style="width:60px">Drive</th>')
        [void]$sb.Append('<th style="width:200px">Used %</th><th style="width:90px;text-align:right">Free (GB)</th>')
        [void]$sb.Append('<th style="width:90px;text-align:right">Total (GB)</th><th style="width:90px;text-align:center">Health</th>')
        [void]$sb.Append('</tr></thead><tbody>')
        foreach ($ln in ($lines | ForEach-Object { $_.TrimEnd() })) {
            if (-not $ln.StartsWith('DISKROW:')) { continue }
            $p=$ln.Substring(8) -split ':',6; if ($p.Count -lt 6) { continue }
            $srv  = ConvertTo-HtmlEscaped $p[0]
            $drv  = ConvertTo-HtmlEscaped $p[1]
            $used = $p[2]; $tot = $p[3]; $free = $p[4]; $flag = $p[5]
            $usedD = [double]($used -replace '[^0-9\.]','0')
            $barW  = [math]::Min(100,[math]::Round($usedD))
            $barC  = if($usedD -ge 75){'#c0392b'}elseif($usedD -ge 60){'#d4a000'}else{'#27ae60'}
            $bg    = switch($flag){'CRITICAL'{'#fff0f0'}'WARN'{'#fffbf0'}default{''}}
            $hBdg  = switch($flag){
                'CRITICAL' {'<span class="bexp">CRITICAL</span>'}
                'WARN'     {'<span class="bnear">WARN</span>'}
                'ERROR'    {'<span class="bexp">ERROR</span>'}
                default    {'<span class="bok">OK</span>'}
            }
            $barHtml  = '<div style="background:#dde2ec;border-radius:4px;height:10px;width:140px;display:inline-block;vertical-align:middle;overflow:hidden">'
            $barHtml += '<div style="background:' + $barC + ';width:' + $barW + '%;height:10px"></div></div>'
            $barHtml += ' <span style="font-size:11px;color:' + $barC + ';font-weight:700">' + $used + '%</span>'
            [void]$sb.Append('<tr style="background:' + $bg + '">')
            [void]$sb.Append('<td><strong>' + $srv + '</strong></td>')
            [void]$sb.Append('<td style="font-family:Consolas,monospace;font-weight:700;text-align:center">' + $drv + ':</td>')
            [void]$sb.Append('<td>' + $barHtml + '</td>')
            [void]$sb.Append('<td style="text-align:right;font-weight:600">' + $free + '</td>')
            [void]$sb.Append('<td style="text-align:right;font-weight:600">' + $tot + '</td>')
            [void]$sb.Append('<td style="text-align:center">' + $hBdg + '</td>')
            [void]$sb.Append('</tr>')
            $hasRows=$true
        }
        [void]$sb.Append('</tbody></table>')
        if ($hasRows) { return $sb.ToString() }
        return '<pre class="dpre">' + (ConvertTo-HtmlEscaped $Det) + '</pre>'
    }

    # -- Admin Groups -------------------------------------------------------------
    if ($Key -eq 'Admin_Groups') {
        [void]$sb.Append("<div class='tw'><table class='dt'><thead><tr><th>Group</th><th>Total</th><th>Enabled</th><th>Members</th></tr></thead><tbody>")
        foreach ($ln in ($lines | ForEach-Object { $_.TrimEnd() })) {
            if (-not $ln.StartsWith('GRPROW:')) { continue }
            $p=$ln.Substring(7) -split ':',4
            $grp=ConvertTo-HtmlEscaped $p[0]; $tot=$p[1]; $en=$p[2]
            $members=if($p.Count -gt 3 -and $p[3] -and $p[3] -ne '(none)') {
                ($p[3] -split '~~' | ForEach-Object { "<span style='background:#e8f4fd;color:#1a5276;padding:1px 6px;border-radius:3px;margin:1px;display:inline-block;font-size:11px'>$(ConvertTo-HtmlEscaped $_)</span>" }) -join ' '
            } else { '<span style="color:#888;font-style:italic">(none)</span>' }
            [void]$sb.Append("<tr><td><strong>$grp</strong></td><td style='text-align:center'>$tot</td><td style='text-align:center'>$en</td><td>$members</td></tr>")
        }
        [void]$sb.Append("</tbody></table></div>")
        return $sb.ToString()
    }

    # -- DAG Replication ----------------------------------------------------------
    if ($Key -eq 'Exch_Replication') {
        $hasRows=$false
        [void]$sb.Append("<div class='tw'><table class='dt'><thead><tr><th>Server</th><th>Database</th><th>Status</th><th>Copy Q</th><th>Replay Q</th><th>Content Index</th><th>DAG</th><th>Health</th></tr></thead><tbody>")
        foreach ($ln in ($lines | ForEach-Object { $_.TrimEnd() })) {
            if (-not $ln.StartsWith('DAGROW:')) { continue }
            $p=$ln.Substring(7) -split ':',8
            $srv=ConvertTo-HtmlEscaped $p[0]; $db=ConvertTo-HtmlEscaped $p[1]; $st=ConvertTo-HtmlEscaped $p[2]
            $cq=$p[3]; $rq=$p[4]; $ci=ConvertTo-HtmlEscaped $p[5]; $dag=ConvertTo-HtmlEscaped $p[6]; $health=$p[7]
            $isOK=($health -eq 'OK'); $stS=if($isOK){'color:#27ae60;font-weight:700'}else{'color:#c0392b;font-weight:700'}
            $bg=if(-not $isOK){'#fff0f0'}else{''}
            $hBdg=if($isOK){"<span class='bok'>OK</span>"}else{"<span class='bexp'>ISSUE</span>"}
            [void]$sb.Append("<tr style='background:$bg'><td><strong>$srv</strong></td><td>$db</td><td style='text-align:center;$stS'>$st</td><td style='text-align:center'>$cq</td><td style='text-align:center'>$rq</td><td style='font-size:10px'>$ci</td><td style='color:#607080;font-size:11px'>$dag</td><td style='text-align:center'>$hBdg</td></tr>")
            $hasRows=$true
        }
        [void]$sb.Append("</tbody></table></div>")
        if ($hasRows) { return $sb.ToString() }
        return "<pre class='dpre'>$(ConvertTo-HtmlEscaped $Det)</pre>"
    }

    # -- DFS Replication ----------------------------------------------------------
    if ($Key -eq 'DFS_Replication') {
        $hasRows=$false
        [void]$sb.Append("<div class='tw'><table class='dt'><thead><tr><th>Server</th><th>Component</th><th>Value</th><th>Detail</th><th>Health</th></tr></thead><tbody>")
        foreach ($ln in ($lines | ForEach-Object { $_.TrimEnd() })) {
            if (-not $ln.StartsWith('DFSROW:')) { continue }
            $p=$ln.Substring(7) -split ':',5
            $srv=ConvertTo-HtmlEscaped $p[0]; $item=ConvertTo-HtmlEscaped $p[1]; $val=ConvertTo-HtmlEscaped $p[2]; $detail=ConvertTo-HtmlEscaped $p[3]; $flag=$p[4]
            $isOK=($flag -eq 'OK'); $bg=if(-not $isOK){'#fff0f0'}else{''}
            $hBdg=if($isOK){"<span class='bok'>OK</span>"}else{"<span class='bexp'>ISSUE</span>"}
            [void]$sb.Append("<tr style='background:$bg'><td><strong>$srv</strong></td><td>$item</td><td>$val</td><td style='color:#607080;font-size:11px'>$detail</td><td style='text-align:center'>$hBdg</td></tr>")
            $hasRows=$true
        }
        [void]$sb.Append("</tbody></table></div>")
        if ($hasRows) { return $sb.ToString() }
        return "<pre class='dpre'>$(ConvertTo-HtmlEscaped $Det)</pre>"
    }

    return "<pre class='dpre'>$(ConvertTo-HtmlEscaped $Det)</pre>"
}

# ============================================================
# REPORT GENERATION
# ============================================================
function Build-Reports {
    param([hashtable]$Results, [string]$Timestamp)

    $CheckDefs = [ordered]@{
        AD_Replication   = @{ Label='AD Replication Status';                            Cat='Active Directory' }
        AD_TimeSync      = @{ Label='AD Time Sync Status';                              Cat='Active Directory' }
        AD_DiskStatus    = @{ Label='DC Disk Space (Alert >= 75%)';                     Cat='Active Directory' }
        Admin_Groups     = @{ Label='Domain Admin and Enterprise Admin Members';         Cat='Active Directory' }
        Exch_Replication = @{ Label='Exchange DAG / Replication Status';                Cat='Exchange Server'  }
        Exch_Health      = @{ Label='Exchange Health Checkup (Services, DBs)';          Cat='Exchange Server'  }
        Exch_DiskStatus  = @{ Label='Exchange Disk Space (Alert >= 75%)';               Cat='Exchange Server'  }
        Exch_DBSizeLimit = @{ Label='Exchange DB Size Limits (Std 1TB / Ent 2TB)';    Cat='Exchange Server'  }
        Exch_Edition     = @{ Label='Exchange Server Edition and Version';              Cat='Exchange Server'  }
        Exch_TimeSync    = @{ Label='Exchange Server Time Sync Status';                 Cat='Exchange Server'  }
        DFS_Certificate  = @{ Label='DFS Certificate Validation';                       Cat='DFS'              }
        DFS_Replication  = @{ Label='DFS Replication Status';                           Cat='DFS'              }
        SSL_ADFS         = @{ Label='ADFS SSL Certificate Validation';                  Cat='Security'         }
        SSL_Exchange     = @{ Label='Exchange SSL Certificate Validation';              Cat='Security'         }
    }

    $Rows=[System.Collections.ArrayList]@(); $num=1; $cH=0; $cW=0; $cC=0; $cN=0
    foreach ($key in $CheckDefs.Keys) {
        $def=$CheckDefs[$key]
        if (-not $Results.Contains($key)) {
            [void]$Rows.Add([PSCustomObject]@{Num=$num;Key=$key;Cat=$def.Cat;Label=$def.Label;Status='N/A';Servers='N/A';Summary='Not applicable for this environment';Details=''})
            $cN++; $num++; continue
        }
        $r=$Results[$key]
        [void]$Rows.Add([PSCustomObject]@{Num=$num;Key=$key;Cat=$def.Cat;Label=$def.Label;Status=$r.Status;Servers=$r.Server;Summary=$r.Comment;Details=$r.Details})
        switch ($r.Status) {'Healthy'{$cH++}'Warning'{$cW++}'Critical'{$cC++}default{$cN++}}
        $num++
    }

    $ts       = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $srvCount = $Script:ServerInventory.Count
    $user     = if ($Script:ConnectedUser) {$Script:ConnectedUser} else {[System.Security.Principal.WindowsIdentity]::GetCurrent().Name}
    $customer = if ($Script:CustomerName)  {$Script:CustomerName}  else {'N/A'}

    # CSV
    $csvPath = Join-Path $Script:ReportPath "HealthCheck_$(if($Script:CustomerName){($Script:CustomerName -replace '[^A-Za-z0-9_-]','_') + '_'}else{''})$Timestamp.csv"
    $Rows | Select-Object @{N='#';E={$_.Num}},@{N='Category';E={$_.Cat}},@{N='Check Name';E={$_.Label}},Status,Servers,Summary,@{N='Generated';E={$ts}},@{N='Customer';E={$customer}} |
        Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
    Write-Log "CSV: $csvPath" -Level SUCCESS

    # --- Build HTML sections ---
    $totalChecks  = $Rows.Count
    # Score uses only checks that actually ran (same formula as the GUI dashboard)
    # N/A checks (not applicable to this environment) are excluded from denominator
    $ranChecks    = $cH + $cW + $cC   # Only Healthy + Warning + Critical = actually ran
    $scorePct     = if ($ranChecks -gt 0) {[math]::Round(($cH / $ranChecks) * 100)} else {0}
    $scoreColor   = if ($cC -gt 0) {'#c0392b'} elseif ($cW -gt 0) {'#d4a000'} else {'#27ae60'}
    $scoreLabel   = if ($cC -gt 0) {'CRITICAL ISSUES DETECTED'} elseif ($cW -gt 0) {'WARNINGS PRESENT'} else {'ALL SYSTEMS HEALTHY'}

    # Build category blocks - NO $() if expressions inside here-strings
    $catBlock = [System.Text.StringBuilder]::new()

    $catMeta = [ordered]@{
        'Active Directory' = @{Icon='&#9670;'; Accent='#0078d4'; BG='#f0f6ff'}
        'Exchange Server'  = @{Icon='&#9993;';  Accent='#107c41'; BG='#f0fff4'}
        'DFS'              = @{Icon='&#128193;'; Accent='#7719aa'; BG='#f8f0ff'}
        'Security'         = @{Icon='&#128274;'; Accent='#c0392b'; BG='#fff0f0'}
    }
    $statusCfg = @{
        'Healthy'  = @{BG='#f0fff4'; Border='#107c41'; Color='#107c41'; BadgeBG='#107c41'}
        'Warning'  = @{BG='#fffbf0'; Border='#d4a000'; Color='#9a6c00'; BadgeBG='#d4a000'}
        'Critical' = @{BG='#fff0f0'; Border='#c0392b'; Color='#c0392b'; BadgeBG='#c0392b'}
        'N/A'      = @{BG='#f8f8f8'; Border='#bbb';    Color='#888';    BadgeBG='#888'}
    }

    foreach ($cat in $catMeta.Keys) {
        $catRows = @($Rows | Where-Object {$_.Cat -eq $cat})
        if ($catRows.Count -eq 0) {continue}
        $cm   = $catMeta[$cat]
        $catH = @(@($catRows | Where-Object {$_.Status -eq 'Healthy'})).Count
        $catW = @(@($catRows | Where-Object {$_.Status -eq 'Warning'})).Count
        $catC = @(@($catRows | Where-Object {$_.Status -eq 'Critical'})).Count

        [void]$catBlock.Append("<div class='cat-block'>")
        [void]$catBlock.Append("<div class='cat-hdr' style='background:$($cm.BG);border-left:4px solid $($cm.Accent)'>")
        [void]$catBlock.Append("<span class='cat-icon' style='color:$($cm.Accent)'>$($cm.Icon)</span>")
        [void]$catBlock.Append("<span class='cat-name' style='color:$($cm.Accent)'>$cat</span>")
        [void]$catBlock.Append("<div class='cat-pills'>")
        [void]$catBlock.Append("<span class='pill pill-ok'>$catH Healthy</span>")
        if ($catW -gt 0) { [void]$catBlock.Append("<span class='pill pill-warn'>$catW Warning</span>") }
        if ($catC -gt 0) { [void]$catBlock.Append("<span class='pill pill-crit'>$catC Critical</span>") }
        [void]$catBlock.Append("</div></div>")

        foreach ($row in $catRows) {
            $sc = if ($statusCfg.ContainsKey($row.Status)) {$statusCfg[$row.Status]} else {$statusCfg['N/A']}
            $detHtml = Render-DetailHtml -Det $row.Details -Key $row.Key
            $detId   = "d$($row.Num)"
            $statusIcon = switch ($row.Status) {'Healthy'{'&#10003;'}'Warning'{'&#9888;'}'Critical'{'&#10007;'}default{'--'}}
            [void]$catBlock.Append("<div class='check-row' style='border-left:3px solid $($sc.Border);background:$($sc.BG)'>")
            [void]$catBlock.Append("<div class='check-main' onclick=""toggle('$detId')"">")
            [void]$catBlock.Append("<div class='check-num'>$($row.Num)</div>")
            [void]$catBlock.Append("<div class='check-lbl'>$($row.Label)</div>")
            [void]$catBlock.Append("<div class='check-badge' style='background:$($sc.BadgeBG)'>$statusIcon $($row.Status)</div>")
            [void]$catBlock.Append('<div class="check-srv">' + (ConvertTo-HtmlEscaped $row.Servers) + '</div>')
            [void]$catBlock.Append('<div class="check-sum" style="color:' + $sc.Color + '">' + (ConvertTo-HtmlEscaped $row.Summary) + '</div>')
            [void]$catBlock.Append("<div class='check-toggle' id='arr$($row.Num)'>&#9660;</div>")
            [void]$catBlock.Append("</div>")
            [void]$catBlock.Append('<div class="check-detail" id="' + $detId + '" style="display:none">' + $detHtml + '</div>')
            [void]$catBlock.Append("</div>")
        }
        [void]$catBlock.Append("</div>")
    }

    # Action items
    $actionBlock = [System.Text.StringBuilder]::new()
    $actionItems = @($Rows | Where-Object {$_.Status -in @('Critical','Warning')})
    if ($actionItems.Count -gt 0) {
        [void]$actionBlock.Append("<div class='action-box'>")
        [void]$actionBlock.Append("<div class='action-hdr'>&#9888; ACTION REQUIRED - $($actionItems.Count) item(s) need attention</div>")
        foreach ($ai in $actionItems) {
            $aColor = if ($ai.Status -eq 'Critical') {'#c0392b'} else {'#d4a000'}
            [void]$actionBlock.Append("<div class='action-item' style='border-left-color:$aColor'>")
            [void]$actionBlock.Append("<div class='action-title'><strong>$($ai.Label)</strong> <span style='color:#888;font-weight:400;font-size:11px'>[$($ai.Cat)]</span></div>")
            [void]$actionBlock.Append('<div class="action-body" style="color:' + $aColor + '">' + (ConvertTo-HtmlEscaped $ai.Summary) + '</div>')
            [void]$actionBlock.Append("</div>")
        }
        [void]$actionBlock.Append("</div>")
    }

    # SVG ring dash calculation - done before here-string
    $ringDash = [math]::Round($scorePct * 2.387, 1)

    # Build the complete HTML using here-string
    # ALL dynamic values computed above as variables - zero $() if() inside here-string
    $catBlockHtml    = $catBlock.ToString()
    $actionBlockHtml = $actionBlock.ToString()
    $appVersion      = $Script:AppVersion

    # Logo HTML - use uploaded company logo or default NourNet circle
    if ($Script:CompanyLogo -and $Script:CompanyLogo -ne '') {
        $logoHtml = "<img class='rpt-logo-img' src='data:image/png;base64,$Script:CompanyLogo' alt='Company Logo' />"
    } else {
        $logoHtml = "<div class='rpt-logo-circle'>N</div>"
    }

    # Score class for CSS badge color
    $scoreClass = if ($cC -gt 0) { 'crit' } elseif ($cW -gt 0) { 'warn' } elseif ($cH -gt 0) { 'ok' } else { 'na' }

$htmlReport = @"
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Infrastructure Health Report - $customer</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Calibri,sans-serif;background:#f3f4f8;color:#1e1e2e;font-size:13px}
.wrap{max-width:1400px;margin:0 auto;padding:20px}
/* HEADER */
.rpt-hdr{background:linear-gradient(135deg,#002855 0%,#003f88 40%,#005bb5 100%);border-radius:12px;padding:0;margin-bottom:20px;display:flex;justify-content:space-between;align-items:stretch;overflow:hidden;box-shadow:0 8px 32px rgba(0,60,140,.3),0 2px 8px rgba(0,0,0,.15)}
.rpt-hdr-left{display:flex;align-items:center;gap:22px;padding:28px 32px;flex:1}
.rpt-hdr-right{display:flex;flex-direction:column;align-items:flex-end;justify-content:space-between;padding:24px 32px;background:rgba(0,0,0,.15);border-left:1px solid rgba(255,255,255,.1);min-width:280px}
.rpt-logo-img{width:72px;height:72px;border-radius:10px;object-fit:contain;background:rgba(255,255,255,.1);border:2px solid rgba(255,255,255,.2);flex-shrink:0}
.rpt-logo-circle{width:72px;height:72px;background:rgba(255,255,255,.15);border:2px solid rgba(255,255,255,.3);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:30px;font-weight:900;color:#fff;flex-shrink:0;letter-spacing:-1px}
.rpt-hdr-text{display:flex;flex-direction:column;gap:6px}
.rpt-badge{font-size:9px;font-weight:800;color:rgba(255,255,255,.6);letter-spacing:3px;text-transform:uppercase;margin-bottom:2px}
.rpt-title{font-size:28px;font-weight:900;color:#fff;letter-spacing:-.5px;line-height:1.1}
.rpt-sub{font-size:11.5px;color:rgba(255,255,255,.55);margin-top:4px;letter-spacing:.3px}
.rpt-meta-grid{display:flex;flex-direction:column;gap:5px;text-align:right}
.rpt-meta-item{display:flex;flex-direction:column;gap:1px}
.rpt-meta-cap{font-size:9px;font-weight:700;color:rgba(255,255,255,.45);text-transform:uppercase;letter-spacing:1.5px}
.rpt-meta-val{font-size:12px;font-weight:700;color:#fff}
.rpt-status-badge{margin-top:14px;padding:8px 20px;border-radius:8px;font-size:13px;font-weight:900;text-align:center;letter-spacing:.5px;border:2px solid rgba(255,255,255,.3)}
.rpt-status-ok{background:rgba(16,124,65,.4);color:#6effa0;border-color:rgba(100,220,140,.4)}
.rpt-status-warn{background:rgba(212,160,0,.3);color:#ffd966;border-color:rgba(220,180,0,.4)}
.rpt-status-crit{background:rgba(192,57,43,.4);color:#ff9090;border-color:rgba(220,80,60,.4)}
.rpt-status-na{background:rgba(255,255,255,.1);color:rgba(255,255,255,.6);border-color:rgba(255,255,255,.2)}
/* SCORE */
.score-row{background:#fff;border-radius:10px;border:1px solid #dde2ec;padding:20px 28px;margin-bottom:18px;display:flex;align-items:center;gap:22px;flex-wrap:wrap;box-shadow:0 2px 10px rgba(0,0,0,.06)}
.score-ring{position:relative;width:88px;height:88px;flex-shrink:0}
.score-ring svg{transform:rotate(-90deg)}
.score-ring-text{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center}
.score-ring-num{font-size:20px;font-weight:800;color:$scoreColor;line-height:1}
.score-ring-lbl{font-size:9px;color:#888;text-transform:uppercase;letter-spacing:.5px;margin-top:1px}
.vsep{width:1px;height:52px;background:#dde2ec;flex-shrink:0}
.stat{display:flex;flex-direction:column;align-items:center;min-width:80px}
.stat .n{font-size:28px;font-weight:800;line-height:1}
.stat .l{font-size:10px;color:#888;margin-top:3px;text-transform:uppercase;letter-spacing:.5px}
.overall{margin-left:auto;font-size:13px;font-weight:800;padding:10px 20px;border-radius:8px;border:2px solid $scoreColor;color:$scoreColor;white-space:nowrap;flex-shrink:0}
/* ACTION BOX */
.action-box{background:#fffaf0;border:1px solid #f0c060;border-radius:10px;padding:18px 22px;margin-bottom:18px}
.action-hdr{font-size:13px;font-weight:800;color:#8a5500;margin-bottom:12px}
.action-item{background:#fff;border-left:3px solid #c0392b;border-radius:0 6px 6px 0;padding:9px 14px;margin-bottom:7px}
.action-title{font-size:12px;font-weight:700;color:#1e1e2e;margin-bottom:3px}
.action-body{font-size:11px}
/* CATEGORY BLOCKS */
.cat-block{background:#fff;border-radius:10px;border:1px solid #dde2ec;margin-bottom:14px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.05)}
.cat-hdr{display:flex;align-items:center;gap:12px;padding:13px 20px}
.cat-icon{font-size:18px}
.cat-name{font-size:14px;font-weight:800;flex:1;letter-spacing:.2px}
.cat-pills{display:flex;gap:6px}
.pill{padding:3px 9px;border-radius:12px;font-size:10px;font-weight:700}
.pill-ok{background:#e8f5e9;color:#107c41;border:1px solid #a8d5b5}
.pill-warn{background:#fff8e1;color:#d4a000;border:1px solid #f0c060}
.pill-crit{background:#fce8e8;color:#c0392b;border:1px solid #f0a0a0}
/* CHECK ROWS */
.check-row{border-top:1px solid #f0f2f7}
.check-main{display:grid;grid-template-columns:38px minmax(180px,2fr) 120px minmax(100px,1.2fr) minmax(140px,2fr) 30px;align-items:center;gap:10px;padding:12px 18px 12px 20px;cursor:pointer;transition:background .1s}
.check-main:hover{background:rgba(0,99,177,.04)}
.check-num{font-size:11px;color:#888;font-weight:700;text-align:center;background:#f0f2f7;border-radius:50%;width:26px;height:26px;display:flex;align-items:center;justify-content:center}
.check-lbl{font-size:12px;font-weight:700;color:#1e1e2e}
.check-badge{padding:3px 10px;border-radius:20px;font-size:10px;font-weight:800;color:#fff;white-space:nowrap;text-align:center}
.check-srv{font-size:11px;color:#607080;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.check-sum{font-size:11px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.check-toggle{font-size:12px;color:#888;text-align:center;transition:transform .2s}
.check-toggle.open{transform:rotate(180deg)}
/* DETAIL */
.check-detail{padding:0 18px 16px 20px;border-top:1px dashed #dde2ec;max-height:600px;overflow-y:auto}
.det-info{font-size:11px;color:#888;font-style:italic;padding:6px 0}
.det-stitle{font-size:11px;font-weight:800;color:#1e1e2e;background:#f0f4f8;padding:6px 10px;border-radius:4px;border-left:3px solid #0078d4;margin:10px 0 4px;text-transform:uppercase;letter-spacing:.6px}
.dpre{font-family:Consolas,monospace;font-size:11px;color:#444;background:#f8f9fb;border:1px solid #dde2ec;border-radius:5px;padding:10px 14px;white-space:pre;overflow-x:auto;line-height:1.65;margin:6px 0;max-height:400px;overflow:auto}
.tw{overflow-x:auto;margin:4px 0;border-radius:6px;border:1px solid #dde2ec}
.dt{width:100%;border-collapse:collapse;font-size:11px;color:#1e1e2e}
.dt thead tr{background:#f0f4f8}
.dt th{padding:7px 10px;text-align:left;font-weight:700;color:#607080;font-size:10px;text-transform:uppercase;letter-spacing:.5px;white-space:nowrap;border-bottom:1px solid #dde2ec}
.dt td{padding:7px 10px;border-top:1px solid #f0f2f7}
.dt tr:hover td{background:#fafbff}
/* SERVER CARDS */
.scard{background:#f8f9fb;border:1px solid #dde2ec;border-radius:7px;margin:8px 0;overflow:hidden}
.shdr{background:#f0f4f8;padding:8px 14px;font-size:12px;font-weight:700;color:#1e1e2e;display:flex;align-items:center;gap:8px;border-bottom:1px solid #dde2ec}
.smeta{margin-left:auto;font-size:10px;font-weight:400;color:#888}
/* BADGES */
.bok  {background:#107c41;color:#fff;padding:2px 7px;border-radius:4px;font-size:10px;font-weight:700}
.bnear{background:#d4a000;color:#fff;padding:2px 7px;border-radius:4px;font-size:10px;font-weight:700}
.bexp {background:#c0392b;color:#fff;padding:2px 7px;border-radius:4px;font-size:10px;font-weight:700}
.b-adfs{background:#8a3b00;color:#fff;padding:1px 6px;border-radius:3px;font-size:9px;font-weight:700}
.b-exch{background:#107c41;color:#fff;padding:1px 6px;border-radius:3px;font-size:9px;font-weight:700}
.b-dfs{background:#5c0099;color:#fff;padding:1px 6px;border-radius:3px;font-size:9px;font-weight:700}
/* FOOTER */
.rpt-footer{text-align:center;color:#888;font-size:11px;padding:22px;border-top:1px solid #dde2ec;margin-top:8px}
@media(max-width:800px){.check-main{grid-template-columns:1fr;gap:6px}.score-row{flex-direction:column;align-items:flex-start}.overall{margin-left:0}.rpt-hdr{flex-direction:column}}
</style>
</head>
<body>
<div class="wrap">

<div class="rpt-hdr">
  <div class="rpt-hdr-left">
    $logoHtml
    <div class="rpt-hdr-text">
      <div class="rpt-badge">INFRASTRUCTURE HEALTH CHECK REPORT</div>
      <div class="rpt-title">$customer</div>
      <div class="rpt-sub">Active Directory &nbsp;&bull;&nbsp; Exchange Server &nbsp;&bull;&nbsp; DFS &nbsp;&bull;&nbsp; SSL / ADFS &nbsp;&bull;&nbsp; Read-Only</div>
    </div>
  </div>
  <div class="rpt-hdr-right">
    <div class="rpt-meta-grid">
      <div class="rpt-meta-item"><span class="rpt-meta-cap">Generated</span><span class="rpt-meta-val">$ts</span></div>
      <div class="rpt-meta-item"><span class="rpt-meta-cap">Operator</span><span class="rpt-meta-val">$user</span></div>
      <div class="rpt-meta-item"><span class="rpt-meta-cap">Servers Checked</span><span class="rpt-meta-val">$srvCount</span></div>
      <div class="rpt-meta-item"><span class="rpt-meta-cap">Tool Version</span><span class="rpt-meta-val">v$appVersion</span></div>
    </div>
    <div class="rpt-status-badge rpt-status-$scoreClass">$scoreLabel</div>
  </div>
</div>

<div class="score-row">
  <div class="score-ring">
    <svg width="88" height="88" viewBox="0 0 88 88">
      <circle cx="44" cy="44" r="36" fill="none" stroke="#e8ecf2" stroke-width="8"/>
      <circle cx="44" cy="44" r="36" fill="none" stroke="$scoreColor" stroke-width="8"
              stroke-dasharray="$ringDash 226.19" stroke-linecap="round"/>
    </svg>
    <div class="score-ring-text">
      <div class="score-ring-num">$scorePct%</div>
      <div class="score-ring-lbl">Score</div>
    </div>
  </div>
  <div class="vsep"></div>
  <div class="stat"><div class="n" style="color:#888">$totalChecks</div><div class="l">Total</div></div>
  <div class="stat"><div class="n" style="color:#107c41">$cH</div><div class="l">Healthy</div></div>
  <div class="stat"><div class="n" style="color:#d4a000">$cW</div><div class="l">Warning</div></div>
  <div class="stat"><div class="n" style="color:#c0392b">$cC</div><div class="l">Critical</div></div>
  <div class="stat"><div class="n" style="color:#aaa">$cN</div><div class="l">N/A</div></div>
  <div class="overall">$scoreLabel</div>
</div>

$actionBlockHtml

$catBlockHtml

<div class="rpt-footer">
  NourNet Infrastructure Health Check Tool &nbsp;v$appVersion &nbsp;&bull;&nbsp; $ts &nbsp;&bull;&nbsp; $user &nbsp;&bull;&nbsp; Customer: $customer
  <br><small>This report is READ-ONLY. Zero modifications were made to any infrastructure component.</small>
</div>
</div>

<script>
function toggle(id){
  var el=document.getElementById(id);
  var arrowId='arr'+id.substring(1);
  var arr=document.getElementById(arrowId);
  var open=el.style.display==='none';
  el.style.display=open?'block':'none';
  if(arr){arr.className=open?'check-toggle open':'check-toggle';}
}
document.addEventListener('keydown',function(e){
  if(e.target.tagName==='INPUT'||e.target.tagName==='TEXTAREA')return;
  var all=document.querySelectorAll('.check-detail');
  if(e.key==='e'||e.key==='E'){all.forEach(function(d){d.style.display='block';});}
  if(e.key==='c'||e.key==='C'){all.forEach(function(d){d.style.display='none';});}
});
</script>
</body>
</html>
"@

    $htmlPath = Join-Path $Script:ReportPath "HealthCheck_$(if($Script:CustomerName){($Script:CustomerName -replace '[^A-Za-z0-9_-]','_') + '_'}else{''})$Timestamp.html"
    # Use StreamWriter with explicit Close() to guarantee file handle is fully released
    # before any external process tries to open the file (prevents msedge.exe crash)
    $sw = New-Object System.IO.StreamWriter($htmlPath, $false, [System.Text.Encoding]::UTF8)
    try { $sw.Write($htmlReport) } finally { $sw.Flush(); $sw.Close(); $sw.Dispose() }
    # Release large string objects to reduce memory pressure
    $htmlReport = $null; $catBlockHtml = $null; $actionBlockHtml = $null
    [System.GC]::Collect()
    # Verify file was written successfully
    if (-not (Test-Path $htmlPath) -or (Get-Item $htmlPath).Length -eq 0) {
        throw "HTML file write failed or produced empty file: $htmlPath"
    }
    Write-Log "HTML: $htmlPath ($([math]::Round((Get-Item $htmlPath).Length/1KB,1)) KB)" -Level SUCCESS
    return @{ HTML=$htmlPath; CSV=$csvPath }
}

# ============================================================
# MAIN GUI  -  v1.1 Professional  |  Microsoft Fluent Design
# [F01] FIX: Controls added in correct order for proper layout
# [F03] FIX: Live progress panel added
# [F04] FIX: Disconnect button added
# [F05] FIX: Full Microsoft-inspired Fluent redesign
# ============================================================


# ==============================================================================
#  MAIN GUI  -  v5.2 Professional
#  FIXES:
#  [G01] $C hashtable out of scope in Add_Paint - replaced with hardcoded FromArgb()
#  [G02] Info bar labels clipped - widened all label sizes, used TableLayoutPanel rows
#  [G03] Export crash - detHtml embedding fixed in backend (concatenation not interpolation)
#  [G04] New "TEST CONNECTIVITY" button - WinRM port 5985/5986 test to all servers
#  [G05] Disconnect button properly disables/enables based on state
#  [G06] Progress bar shows actual per-check step names
# ==============================================================================


# ==============================================================================
#  MAIN GUI  -  v5.2 Professional  |  Redesigned Layout
#  Design principles:
#  - Compact header: logo + title + customer field in one clean bar
#  - Merged info+score into a single dashboard ribbon (no wasted whitespace)
#  - Seven action buttons with icons, equal width, flat with hover glow
#  - Results grid with alternating row colors, sortable, double-click detail
#  - Dark terminal Activity Log tab
#  - All colors hardcoded in variables (no $C hashtable - scope-safe for Paint events)
# ==============================================================================
# ==============================================================================
#  CUSTOMER PROFILE MANAGER DIALOG
# ==============================================================================
function Show-CustomerManager {
    # Colors - hardcoded for Paint closure scope safety
    $MC_BLUE  = [System.Drawing.Color]::FromArgb(0,  84, 166)
    $MC_BLUE2 = [System.Drawing.Color]::FromArgb(0,  38, 106)
    $MC_BLUE3 = [System.Drawing.Color]::FromArgb(0, 120, 212)
    $MC_GREEN = [System.Drawing.Color]::FromArgb(16, 124,  16)
    $MC_RED   = [System.Drawing.Color]::FromArgb(196,  43,  28)
    $MC_DARK  = [System.Drawing.Color]::FromArgb( 10,  16,  30)
    $MC_NAVY  = [System.Drawing.Color]::FromArgb( 18,  26,  48)
    $MC_WHITE = [System.Drawing.Color]::White
    $MC_BDR   = [System.Drawing.Color]::FromArgb(210, 218, 232)
    $MC_INBG  = [System.Drawing.Color]::FromArgb(248, 249, 253)
    $MC_SUB   = [System.Drawing.Color]::FromArgb( 90, 100, 120)
    $MC_SEL   = [System.Drawing.Color]::FromArgb(210, 228, 252)
    $MC_SECBG = [System.Drawing.Color]::FromArgb(228, 238, 252)

    $script:editingID = $null

    # ---- FORM ----
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "Customer Profile Manager"
    $dlg.Size = New-Object System.Drawing.Size(1060, 700)
    $dlg.MinimumSize = New-Object System.Drawing.Size(900, 600)
    $dlg.StartPosition = 'CenterScreen'
    $dlg.BackColor = [System.Drawing.Color]::FromArgb(240, 242, 248)
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $dlg.FormBorderStyle = 'Sizable'

    # ---- TITLE BAR  Dock=Top ----
    $tp = New-Object System.Windows.Forms.Panel
    $tp.Dock = 'Top'; $tp.Height = 50; $tp.BackColor = $MC_BLUE
    $tp.Add_Paint({
        param($s,$e)
        $r2 = $s.ClientRectangle
        $b2 = New-Object System.Drawing.Drawing2D.LinearGradientBrush($r2,
            [System.Drawing.Color]::FromArgb(0,84,166),
            [System.Drawing.Color]::FromArgb(0,38,106),
            [System.Drawing.Drawing2D.LinearGradientMode]::Horizontal)
        $e.Graphics.FillRectangle($b2,$r2); $b2.Dispose()
        $p2 = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(0,148,255),2)
        $e.Graphics.DrawLine($p2,0,$s.Height-1,$s.Width,$s.Height-1); $p2.Dispose()
    })
    $tl = New-Object System.Windows.Forms.Label
    $tl.Text = "   Customer Profile Manager"; $tl.Dock = 'Fill'
    $tl.Font = New-Object System.Drawing.Font('Segoe UI',13,[System.Drawing.FontStyle]::Bold)
    $tl.ForeColor = $MC_WHITE; $tl.BackColor = [System.Drawing.Color]::Transparent
    $tl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $tp.Controls.Add($tl)

    # ---- ROOT  Dock=Fill ----
    $root2 = New-Object System.Windows.Forms.Panel
    $root2.Dock = 'Fill'; $root2.BackColor = $MC_WHITE; $root2.Padding = New-Object System.Windows.Forms.Padding(0)
    # CORRECT DOCK ORDER: Add Fill (root2) first -> processed last -> fills space below Top
    # Then add Top (tp) -> processed first -> claims 50px from top
    $dlg.Controls.Add($root2)   # index 0 -> Fill -> processed last
    $dlg.Controls.Add($tp)      # index 1 -> Top  -> processed first -> claims top 50px

    # ================================================================
    # ADD ORDER for correct WinForms Dock layout:
    # Fill panel must be added to parent BEFORE Left panels,
    # because WinForms processes controls in add-index order:
    # index 0 processed first, so Fill takes all remaining space
    # after Left panels have been processed.
    # Correct: add Left panels first (they consume from left),
    # then Fill (consumes remainder).
    # ================================================================

    # ---- LEFT PANEL  Dock=Left  290px ----
    $lp = New-Object System.Windows.Forms.Panel
    $lp.Dock = 'Left'; $lp.Width = 290; $lp.BackColor = $MC_DARK
    $lp.Padding = New-Object System.Windows.Forms.Padding(0)

    $lhp = New-Object System.Windows.Forms.Panel
    $lhp.Dock = 'Top'; $lhp.Height = 42; $lhp.BackColor = [System.Drawing.Color]::FromArgb(6,10,22)
    $lhl = New-Object System.Windows.Forms.Label
    $lhl.Text = "  SAVED CUSTOMERS"; $lhl.Dock = 'Fill'
    $lhl.Font = New-Object System.Drawing.Font('Segoe UI',8,[System.Drawing.FontStyle]::Bold)
    $lhl.ForeColor = [System.Drawing.Color]::FromArgb(120,158,210); $lhl.BackColor = [System.Drawing.Color]::Transparent
    $lhl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft; $lhp.Controls.Add($lhl); $lp.Controls.Add($lhp)

    $lb = New-Object System.Windows.Forms.ListBox
    $lb.Dock = 'Fill'; $lb.BackColor = $MC_NAVY; $lb.ForeColor = [System.Drawing.Color]::FromArgb(200,215,240)
    $lb.BorderStyle = 'None'; $lb.DrawMode = 'OwnerDrawFixed'; $lb.ItemHeight = 62; $lb.SelectionMode = 'One'
    $lb.Font = New-Object System.Drawing.Font('Segoe UI',9)
    $lb.Add_DrawItem({
        param($s,$e)
        if ($e.Index -lt 0 -or $e.Index -ge $s.Items.Count) { return }
        $g = $e.Graphics; $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $sel = ($e.State -band [System.Windows.Forms.DrawItemState]::Selected)
        $bgC = if ($sel) { [System.Drawing.Color]::FromArgb(0,65,145) } `
               elseif ($e.Index%2) { [System.Drawing.Color]::FromArgb(22,32,56) } `
               else { [System.Drawing.Color]::FromArgb(18,26,48) }
        $bgB = New-Object System.Drawing.SolidBrush($bgC); $g.FillRectangle($bgB,$e.Bounds); $bgB.Dispose()
        $db3 = Get-CustomersDB
        $srt = [array]@($db3.Customers | Sort-Object Name)
        if ($srt -and $e.Index -lt $srt.Count) {
            $c3 = $srt[$e.Index]
            $ac = switch ($c3.LastStatus) {
                'Healthy'  {[System.Drawing.Color]::FromArgb(20,190,20)}
                'Warning'  {[System.Drawing.Color]::FromArgb(220,148,0)}
                'Critical' {[System.Drawing.Color]::FromArgb(228,40,40)}
                default    {[System.Drawing.Color]::FromArgb(72,98,145)}
            }
            $acB = New-Object System.Drawing.SolidBrush($ac)
            $g.FillRectangle($acB,$e.Bounds.X,$e.Bounds.Y,5,$e.Bounds.Height); $acB.Dispose()
            $fN = New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
            $cN = if ($sel){[System.Drawing.Color]::White}else{[System.Drawing.Color]::FromArgb(222,234,255)}
            $bN = New-Object System.Drawing.SolidBrush($cN)
            $g.DrawString($c3.Name,$fN,$bN,[float]($e.Bounds.X+12),[float]($e.Bounds.Y+7)); $fN.Dispose(); $bN.Dispose()
            $st3 = if($c3.Site -and $c3.Site -ne ''){$c3.Site}else{'No site'}
            $fS = New-Object System.Drawing.Font('Segoe UI',8); $bS = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(125,152,205))
            $g.DrawString($st3,$fS,$bS,[float]($e.Bounds.X+12),[float]($e.Bounds.Y+30)); $fS.Dispose(); $bS.Dispose()
            $sc3 = if($c3.Servers){"$($c3.Servers.Count) srv"}else{"0 srv"}
            $lk3 = if($c3.LastCheck){"$(Get-Date $c3.LastCheck -Format 'dd MMM HH:mm')"}else{"Never"}
            $fI = New-Object System.Drawing.Font('Segoe UI',7); $bI = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(85,112,162))
            $iT = "$sc3 | $lk3"; $iSz=$g.MeasureString($iT,$fI)
            $g.DrawString($iT,$fI,$bI,[float]($e.Bounds.Right-$iSz.Width-6),[float]($e.Bounds.Y+44)); $fI.Dispose(); $bI.Dispose()
            if ($c3.LastStatus -and $c3.LastStatus -ne '') {
                $fB=New-Object System.Drawing.Font('Segoe UI',7,[System.Drawing.FontStyle]::Bold)
                $bSz=$g.MeasureString($c3.LastStatus,$fB); $bX=[float]($e.Bounds.Right-$bSz.Width-14); $bY=[float]($e.Bounds.Y+9)
                $bdB=New-Object System.Drawing.SolidBrush($ac); $g.FillRectangle($bdB,$bX-3,$bY-2,$bSz.Width+6,$bSz.Height+3); $bdB.Dispose()
                $wB=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White); $g.DrawString($c3.LastStatus,$fB,$wB,$bX,$bY); $wB.Dispose(); $fB.Dispose()
            }
        }
        $spn=New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(30,42,70))
        $g.DrawLine($spn,$e.Bounds.X,$e.Bounds.Bottom-1,$e.Bounds.Right,$e.Bounds.Bottom-1); $spn.Dispose()
    })
    $lp.Controls.Add($lb)

    # ---- SEPARATOR 1px ----
    $sep2 = New-Object System.Windows.Forms.Panel
    $sep2.Dock = 'Left'; $sep2.Width = 1; $sep2.BackColor = $MC_BDR

    # Add LEFT panels first, then RIGHT (Fill) - CORRECT dock order
    # ---- RIGHT SCROLL PANEL  Dock=Fill ----
    $rs = New-Object System.Windows.Forms.Panel
    $rs.Dock = 'Fill'; $rs.BackColor = $MC_WHITE; $rs.AutoScroll = $false; $rs.Padding = New-Object System.Windows.Forms.Padding(0)

    # CRITICAL: In WinForms, Dock layout processes controls in REVERSE add-index order.
    # To get Left+Fill correct: add Fill FIRST (processed last = fills remainder),
    # then add Left panels AFTER (processed first = claim their fixed widths).
    $root2.Controls.Add($rs)    # index 0 -> processed LAST -> fills remainder after Left panels
    $root2.Controls.Add($sep2)  # index 1 -> processed 2nd  -> claims 1px from left
    $root2.Controls.Add($lp)    # index 2 -> processed FIRST -> claims 290px from left

    # ---- INNER FORM PANEL (inside $rs, padding 24px) ----
    # Use a Panel with Padding so all child controls have natural margins
    $script:fp = New-Object System.Windows.Forms.Panel
    $script:fp.Dock = 'Fill'
    $script:fp.BackColor = $MC_WHITE
    $script:fp.Padding = New-Object System.Windows.Forms.Padding(24, 16, 24, 16)

    # ================================================================
    # FORM CONTROLS - all added directly to $script:fp using TableLayoutPanel
    # for clean alignment
    # ================================================================
    $tlp = New-Object System.Windows.Forms.TableLayoutPanel
    $tlp.Dock = 'Fill'
    $tlp.BackColor = $MC_WHITE
    $tlp.ColumnCount = 2
    $tlp.RowCount = 12
    [void]$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 50)))
    [void]$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 50)))
    # Row heights
    # Rows: title | sec-info | name+site | contact+notes | sec-folder | rptpath | sec-servers | hint | grid(fills)
    $tlpRowH2 = @(30, 22, 52, 52, 22, 46, 22, 36)
    $tlp.RowCount = $tlpRowH2.Count + 1
    foreach ($rh2 in $tlpRowH2) {
        [void]$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, $rh2)))
    }
    # Last row = server grid, fills ALL remaining height
    [void]$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    $script:fp.Controls.Add($tlp)

    # Helper: create a label+textbox stack in a panel for the grid
    function New-FieldPanel {
        param([string]$Cap, [string]$Default='')
        $pnl = New-Object System.Windows.Forms.Panel; $pnl.Dock='Fill'; $pnl.BackColor=$MC_WHITE; $pnl.Padding=New-Object System.Windows.Forms.Padding(4,0,8,4)
        $lbl = New-Object System.Windows.Forms.Label; $lbl.Text=$Cap; $lbl.Dock='Top'; $lbl.Height=16
        $lbl.Font=New-Object System.Drawing.Font('Segoe UI',7,[System.Drawing.FontStyle]::Bold)
        $lbl.ForeColor=[System.Drawing.Color]::FromArgb(88,100,120)
        $tb = New-Object System.Windows.Forms.TextBox; $tb.Dock='Fill'; $tb.Text=$Default
        $tb.Font=New-Object System.Drawing.Font('Segoe UI',10); $tb.BackColor=[System.Drawing.Color]::FromArgb(248,249,253); $tb.BorderStyle='FixedSingle'
        $pnl.Controls.Add($tb); $pnl.Controls.Add($lbl)
        return @{Panel=$pnl; TextBox=$tb}
    }

    function New-SecHdr {
        param([string]$Text)
        $pnl = New-Object System.Windows.Forms.Panel; $pnl.Dock='Fill'; $pnl.BackColor=$MC_SECBG
        $lbl = New-Object System.Windows.Forms.Label; $lbl.Text="  $Text"; $lbl.Dock='Fill'
        $lbl.Font=New-Object System.Drawing.Font('Segoe UI',8,[System.Drawing.FontStyle]::Bold)
        $lbl.ForeColor=$MC_BLUE; $lbl.BackColor=[System.Drawing.Color]::Transparent; $lbl.TextAlign=[System.Drawing.ContentAlignment]::MiddleLeft
        $pnl.Controls.Add($lbl); return $pnl
    }

    # Row 0: Form title (span 2 cols)
    $frmHdr = New-Object System.Windows.Forms.Label; $frmHdr.Text = "New Customer"; $frmHdr.Dock='Fill'
    $frmHdr.Font=New-Object System.Drawing.Font('Segoe UI',13,[System.Drawing.FontStyle]::Bold)
    $frmHdr.ForeColor=$MC_BLUE; $frmHdr.TextAlign=[System.Drawing.ContentAlignment]::MiddleLeft; $frmHdr.Padding=New-Object System.Windows.Forms.Padding(4,0,0,0)
    $tlp.Controls.Add($frmHdr,0,0); $tlp.SetColumnSpan($frmHdr,2)

    # Row 1: Section header
    $sec1 = New-SecHdr "CUSTOMER INFORMATION"
    $tlp.Controls.Add($sec1,0,1); $tlp.SetColumnSpan($sec1,2)

    # Row 2: Name + Site
    $fName = New-FieldPanel 'CUSTOMER NAME *'
    $fSite = New-FieldPanel 'SITE / LOCATION'
    $tlp.Controls.Add($fName.Panel,0,2); $tlp.Controls.Add($fSite.Panel,1,2)
    $tbName = $fName.TextBox; $tbSite = $fSite.TextBox

    # Row 3: Contact + Notes
    $fCont = New-FieldPanel 'CONTACT EMAIL'
    $fNote = New-FieldPanel 'NOTES'
    $tlp.Controls.Add($fCont.Panel,0,3); $tlp.Controls.Add($fNote.Panel,1,3)
    $tbContact = $fCont.TextBox; $tbNotes = $fNote.TextBox

    # Row 4: Report folder section header
    $sec2 = New-SecHdr "REPORT OUTPUT FOLDER"
    $tlp.Controls.Add($sec2,0,4); $tlp.SetColumnSpan($sec2,2)

    # Row 5: Report path + Browse button
    $rptPnl = New-Object System.Windows.Forms.Panel; $rptPnl.Dock='Fill'; $rptPnl.BackColor=$MC_WHITE; $rptPnl.Padding=New-Object System.Windows.Forms.Padding(4,4,4,4)
    $tbRpt = New-Object System.Windows.Forms.TextBox; $tbRpt.Font=New-Object System.Drawing.Font('Segoe UI',10)
    $tbRpt.BackColor=[System.Drawing.Color]::FromArgb(248,249,253); $tbRpt.BorderStyle='FixedSingle'
    $tbRpt.Anchor=[System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right -bor [System.Windows.Forms.AnchorStyles]::Top
    $tbRpt.Location=New-Object System.Drawing.Point(0,5); $tbRpt.Size=New-Object System.Drawing.Size(400,28)
    $btnBr = New-Object System.Windows.Forms.Button; $btnBr.Text='Browse...'
    $btnBr.Location=New-Object System.Drawing.Point(408,4); $btnBr.Size=New-Object System.Drawing.Size(88,30)
    $btnBr.FlatStyle='Flat'; $btnBr.FlatAppearance.BorderSize=1; $btnBr.FlatAppearance.BorderColor=$MC_BDR
    $btnBr.BackColor=[System.Drawing.Color]::FromArgb(236,242,252); $btnBr.Font=New-Object System.Drawing.Font('Segoe UI',8)
    $btnBr.Cursor=[System.Windows.Forms.Cursors]::Hand
    $btnBr.Add_Click({
        $fb3=New-Object System.Windows.Forms.FolderBrowserDialog; $fb3.Description="Select report output folder"
        if($tbRpt.Text -ne ''){try{$fb3.SelectedPath=$tbRpt.Text}catch{}}
        if($fb3.ShowDialog() -eq 'OK'){$tbRpt.Text=$fb3.SelectedPath}
    })
    $rptPnl.Controls.Add($tbRpt); $rptPnl.Controls.Add($btnBr)
    $tlp.Controls.Add($rptPnl,0,5); $tlp.SetColumnSpan($rptPnl,2)
    $rptPnl.Add_Resize({ $tbRpt.Width = $rptPnl.Width - 108; $btnBr.Left = $rptPnl.Width - 96 })

    # Row 6: Server section header
    $sec3 = New-SecHdr "SERVER LIST  |  Add all servers for this customer"
    $tlp.Controls.Add($sec3,0,6); $tlp.SetColumnSpan($sec3,2)

    # Row 7: Hint label
    $hint = New-Object System.Windows.Forms.Label; $hint.Dock='Fill'
    $hint.Text="  Enter server hostname or FQDN and select its role. Use Delete key or right-click to remove a row."
    $hint.Font=New-Object System.Drawing.Font('Segoe UI',8); $hint.ForeColor=[System.Drawing.Color]::FromArgb(108,122,148)
    $hint.TextAlign=[System.Drawing.ContentAlignment]::MiddleLeft
    $tlp.Controls.Add($hint,0,7); $tlp.SetColumnSpan($hint,2)

    # Row 8: Section header spacer (use for grid label)
    # Row 9: Server grid + side buttons
    $gridOuter = New-Object System.Windows.Forms.Panel; $gridOuter.Dock='Fill'; $gridOuter.BackColor=$MC_WHITE; $gridOuter.Padding=New-Object System.Windows.Forms.Padding(4,0,4,4)
    $tlp.Controls.Add($gridOuter,0,8); $tlp.SetColumnSpan($gridOuter,2)

    # Grid
    $grid = New-Object System.Windows.Forms.DataGridView
    $grid.Location=New-Object System.Drawing.Point(0,0); $grid.Anchor=[System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right
    $grid.BackgroundColor=$MC_WHITE; $grid.BorderStyle='FixedSingle'; $grid.GridColor=$MC_BDR
    $grid.AllowUserToAddRows=$true; $grid.AllowUserToDeleteRows=$true; $grid.RowHeadersVisible=$false
    $grid.AutoSizeColumnsMode='Fill'; $grid.RowTemplate.Height=30; $grid.ColumnHeadersHeight=32
    $grid.EnableHeadersVisualStyles=$false; $grid.Font=New-Object System.Drawing.Font('Segoe UI',9)
    $grid.CellBorderStyle=[System.Windows.Forms.DataGridViewCellBorderStyle]::SingleHorizontal
    $grid.DefaultCellStyle.SelectionBackColor=$MC_SEL; $grid.DefaultCellStyle.SelectionForeColor=[System.Drawing.Color]::FromArgb(18,22,36)
    $ghs=$grid.ColumnHeadersDefaultCellStyle
    $ghs.BackColor=[System.Drawing.Color]::FromArgb(20,26,46); $ghs.ForeColor=[System.Drawing.Color]::FromArgb(162,190,228)
    $ghs.Font=New-Object System.Drawing.Font('Segoe UI',8,[System.Drawing.FontStyle]::Bold)
    # ServerName column
    [void]$grid.Columns.Add('ServerName','Server Name / FQDN')
    $grid.Columns['ServerName'].FillWeight = 65

    # Role column - plain TextBox with autocomplete (no ComboBox validation errors)
    $roleCol2 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $roleCol2.Name = 'Role'; $roleCol2.HeaderText = 'Role  (DC / Exchange / DFS / ADFS)'
    $roleCol2.FillWeight = 35
    [void]$grid.Columns.Add($roleCol2)

    # Provide autocomplete on the Role cell using EditingControlShowing
    $grid.Add_EditingControlShowing({
        param($s,$e)
        if ($s.CurrentCell.ColumnIndex -eq 1) {
            $tb3 = $e.Control -as [System.Windows.Forms.TextBox]
            if ($tb3) {
                $tb3.AutoCompleteMode   = [System.Windows.Forms.AutoCompleteMode]::SuggestAppend
                $tb3.AutoCompleteSource = [System.Windows.Forms.AutoCompleteSource]::CustomSource
                $ac3 = New-Object System.Windows.Forms.AutoCompleteStringCollection
                [void]$ac3.Add('DC'); [void]$ac3.Add('Exchange'); [void]$ac3.Add('DFS')
                [void]$ac3.Add('ADFS'); [void]$ac3.Add('Unknown')
                $tb3.AutoCompleteCustomSource = $ac3
            }
        }
    })

    # Suppress any DataGridView default error dialogs
    $grid.Add_DataError({ param($s,$e); $e.ThrowException=$false; $e.Cancel=$true })

    # Side buttons
    $btnAddR = New-Object System.Windows.Forms.Button; $btnAddR.Text='+ Add Row'
    $btnAddR.Size=New-Object System.Drawing.Size(130,34); $btnAddR.FlatStyle='Flat'; $btnAddR.FlatAppearance.BorderSize=0
    $btnAddR.BackColor=$MC_GREEN; $btnAddR.ForeColor=$MC_WHITE
    $btnAddR.Font=New-Object System.Drawing.Font('Segoe UI',8,[System.Drawing.FontStyle]::Bold); $btnAddR.Cursor=[System.Windows.Forms.Cursors]::Hand
    $btnAddR.Add_Click({ [void]$grid.Rows.Add('', 'DC') })

    $btnImp = New-Object System.Windows.Forms.Button; $btnImp.Text="Import servers.txt"
    $btnImp.Size=New-Object System.Drawing.Size(130,34); $btnImp.FlatStyle='Flat'; $btnImp.FlatAppearance.BorderSize=0
    $btnImp.BackColor=$MC_BLUE; $btnImp.ForeColor=$MC_WHITE
    $btnImp.Font=New-Object System.Drawing.Font('Segoe UI',8,[System.Drawing.FontStyle]::Bold); $btnImp.Cursor=[System.Windows.Forms.Cursors]::Hand
    $btnImp.Add_Click({
        $od=New-Object System.Windows.Forms.OpenFileDialog; $od.Filter="Text files (*.txt)|*.txt|All (*.*)|*.*"
        $od.Title="Select servers.txt to import"; $od.InitialDirectory=$PSScriptRoot
        if($od.ShowDialog()-ne'OK'){return}
        $grid.Rows.Clear()
        $imported = 0
        Get-Content $od.FileName | Where-Object { $_.Trim() -and -not $_.TrimStart().StartsWith('#') } | ForEach-Object {
            $pts    = $_ -split ',',2
            $sn     = $pts[0].Trim()
            if ($sn -eq '') { return }
            $rawRole = if ($pts.Count -ge 2) { $pts[1].Trim() } else { 'DC' }
            # Normalize to canonical role name
            $sr = switch -Regex ($rawRole.ToUpper()) {
                '^DC$|^DOMAIN'    { 'DC' }
                '^EX|^EXCH'       { 'Exchange' }
                '^DFS$'           { 'DFS' }
                '^ADFS$|^AD.FS'   { 'ADFS' }
                default           { $rawRole }
            }
            # Add new row and set values directly (plain TextBox column - no validation error)
            [void]$grid.Rows.Add($sn, $sr)
            $imported++
        }
        [System.Windows.Forms.MessageBox]::Show("Imported $imported server(s) from $([System.IO.Path]::GetFileName($od.FileName)).`n`nClick 'Save Customer' to save these servers.", "Import Complete", 'OK', 'Information') | Out-Null
    })

    $btnClr = New-Object System.Windows.Forms.Button; $btnClr.Text="Clear All"
    $btnClr.Size=New-Object System.Drawing.Size(130,34); $btnClr.FlatStyle='Flat'; $btnClr.FlatAppearance.BorderSize=0
    $btnClr.BackColor=$MC_RED; $btnClr.ForeColor=$MC_WHITE
    $btnClr.Font=New-Object System.Drawing.Font('Segoe UI',8,[System.Drawing.FontStyle]::Bold); $btnClr.Cursor=[System.Windows.Forms.Cursors]::Hand
    $btnClr.Add_Click({ $grid.Rows.Clear() })

    $btnFl = New-Object System.Windows.Forms.FlowLayoutPanel
    $btnFl.FlowDirection='TopDown'; $btnFl.WrapContents=$false
    $btnFl.Dock='Right'; $btnFl.Width=138; $btnFl.BackColor=$MC_WHITE; $btnFl.Padding=New-Object System.Windows.Forms.Padding(8,0,0,0)
    [void]$btnFl.Controls.Add($btnAddR); [void]$btnFl.Controls.Add($btnImp); [void]$btnFl.Controls.Add($btnClr)

    $grid.Dock='Fill'
    $gridOuter.Controls.Add($btnFl); $gridOuter.Controls.Add($grid)

    # Row 10: Spacer
    # ACTION BAR: Dock=Bottom on $rs so it is ALWAYS visible regardless of window size
    $actPnl = New-Object System.Windows.Forms.Panel
    $actPnl.Dock = 'Bottom'; $actPnl.Height = 68
    $actPnl.BackColor = [System.Drawing.Color]::FromArgb(238, 241, 248)
    $actPnl.Padding = New-Object System.Windows.Forms.Padding(16, 14, 16, 14)
    $actPnl.Add_Paint({
        param($s,$e)
        $pn2 = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(0, 120, 212), 2)
        $e.Graphics.DrawLine($pn2, 0, 0, $s.Width, 0); $pn2.Dispose()
    })

    # Add actPnl to $rs AFTER it is fully defined (Dock=Bottom - always visible)

    $rs.Controls.Add($actPnl)
    $rs.Controls.Add($script:fp)



    $actFlow = New-Object System.Windows.Forms.FlowLayoutPanel
    $actFlow.Dock='Fill'; $actFlow.BackColor=[System.Drawing.Color]::Transparent; $actFlow.Padding=New-Object System.Windows.Forms.Padding(0,0,0,0)

    function New-ActBtn3 {
        param([string]$T,[System.Drawing.Color]$BG,[System.Drawing.Color]$FG,[int]$W=140)
        $b=New-Object System.Windows.Forms.Button; $b.Text=$T; $b.Size=New-Object System.Drawing.Size($W,36)
        $b.BackColor=$BG; $b.ForeColor=$FG; $b.FlatStyle='Flat'; $b.FlatAppearance.BorderSize=0
        $b.Margin=New-Object System.Windows.Forms.Padding(0,0,8,0)
        $b.Font=New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold); $b.Cursor=[System.Windows.Forms.Cursors]::Hand
        return $b
    }
    $btnSv = New-ActBtn3 'SAVE CUSTOMER'   ([System.Drawing.Color]::FromArgb(0,140,0))  $MC_WHITE 160
    $btnNw = New-ActBtn3 '+ New Customer'  ([System.Drawing.Color]::FromArgb(228,241,255)) $MC_BLUE  148
    $btnDl = New-ActBtn3 'Delete'          $MC_RED   $MC_WHITE 100
    $btnCl = New-ActBtn3 'Close'           ([System.Drawing.Color]::FromArgb(236,238,245)) ([System.Drawing.Color]::FromArgb(55,65,85)) 100
    $btnDl.Enabled=$false
    # Make Save button stand out with a tooltip
    $tt = New-Object System.Windows.Forms.ToolTip
    $tt.SetToolTip($btnSv, "Save all customer details and server list to customers.json"  )
    $tt.SetToolTip($btnNw, "Clear the form to add a new customer")
    $tt.SetToolTip($btnDl, "Delete this customer permanently")
    [void]$actFlow.Controls.Add($btnSv); [void]$actFlow.Controls.Add($btnNw)
    [void]$actFlow.Controls.Add($btnDl); [void]$actFlow.Controls.Add($btnCl)
    $actPnl.Controls.Add($actFlow)

    # ================================================================
    # HELPERS: Load / Clear form, Refresh listbox
    # ================================================================
    function Load-CustForm {
        param([object]$C)
        $script:editingID=$C.ID; $frmHdr.Text="Editing:  $($C.Name)"
        $tbName.Text   = if($C.Name){$C.Name}else{''}
        $tbSite.Text   = if($C.Site){$C.Site}else{''}
        $tbContact.Text= if($C.Contact){$C.Contact}else{''}
        $tbNotes.Text  = if($C.Notes){$C.Notes}else{''}
        $tbRpt.Text    = if($C.ReportPath){$C.ReportPath}else{''}
        $grid.Rows.Clear()
        if ($C.Servers) {
            foreach ($sv in $C.Servers) {
                $ri=$grid.Rows.Add()
                $grid.Rows[$ri].Cells['ServerName'].Value=[string]$sv.Name
                $grid.Rows[$ri].Cells['Role'].Value=[string]$sv.Role
            }
        }
        $btnDl.Enabled=$true
    }

    function Clear-CustForm {
        $script:editingID=$null; $frmHdr.Text="New Customer"
        $tbName.Text=''; $tbSite.Text=''; $tbContact.Text=''; $tbNotes.Text=''; $tbRpt.Text=''
        $grid.Rows.Clear(); $btnDl.Enabled=$false; $lb.ClearSelected()
    }

    function Refresh-LB {
        $lb.Items.Clear()
        $dbR=Get-CustomersDB
        $custSorted = [array]@($dbR.Customers | Sort-Object Name)
        if ($custSorted) { foreach ($cR in $custSorted) { [void]$lb.Items.Add($cR.Name) } }
        $lb.Invalidate()
    }

    # ================================================================
    # EVENT HANDLERS
    # ================================================================
    # Double-click also loads customer (redundant but expected UX)
    $lb.Add_DoubleClick({
        $ix2=$lb.SelectedIndex; if($ix2 -lt 0){return}
        $dbX2=Get-CustomersDB
        $srtX2=[array]@($dbX2.Customers | Sort-Object Name)
        if($srtX2 -and $ix2 -lt $srtX2.Count){Load-CustForm $srtX2[$ix2]}
    })

    $lb.Add_SelectedIndexChanged({
        $ix=$lb.SelectedIndex; if($ix -lt 0){return}
        $dbX=Get-CustomersDB
        $srtX=[array]@($dbX.Customers | Sort-Object Name)
        if($srtX -and $ix -lt $srtX.Count){Load-CustForm $srtX[$ix]}
    })

    $btnSv.Add_Click({
        if($tbName.Text.Trim() -eq ''){
            [System.Windows.Forms.MessageBox]::Show("Customer Name is required.","Validation",'OK','Warning')|Out-Null; return
        }
        $srvs=[System.Collections.ArrayList]@()
        foreach($rw in $grid.Rows){
            if($rw.IsNewRow){continue}
            $sn=[string]$rw.Cells['ServerName'].Value; $sr=[string]$rw.Cells['Role'].Value
            if($sn.Trim()-ne ''){[void]$srvs.Add([PSCustomObject]@{Name=$sn.Trim();Role=if($sr){$sr}else{'Unknown'}})}
        }
        $dbS=Get-CustomersDB
        if($script:editingID){
            $ex=@($dbS.Customers)|Where-Object{$_.ID -eq $script:editingID}|Select-Object -First 1
            if($ex){$ex.Name=$tbName.Text.Trim();$ex.Site=$tbSite.Text.Trim();$ex.Contact=$tbContact.Text.Trim();$ex.Notes=$tbNotes.Text.Trim();$ex.ReportPath=$tbRpt.Text.Trim();$ex.Servers=$srvs}
        } else {
            $nc=[PSCustomObject]@{ID=New-CustomerID;Name=$tbName.Text.Trim();Site=$tbSite.Text.Trim();Contact=$tbContact.Text.Trim();Notes=$tbNotes.Text.Trim();ReportPath=$tbRpt.Text.Trim();Servers=$srvs;LastCheck='';LastStatus=''}
            $cl=[System.Collections.ArrayList]@($dbS.Customers);[void]$cl.Add($nc);$dbS.Customers=$cl;$script:editingID=$nc.ID
        }
        if (Save-CustomersDB $dbS) {
            Refresh-LB
            # After refresh, re-select the saved customer so list highlights it correctly
            $dbAfter = Get-CustomersDB
            $srtAfter = [array]@($dbAfter.Customers | Sort-Object Name)
            $selIdx2 = -1
            for ($ii = 0; $ii -lt $srtAfter.Count; $ii++) {
                if ($srtAfter[$ii].ID -eq $script:editingID) { $selIdx2 = $ii; break }
            }
            if ($selIdx2 -ge 0) {
                $lb.SelectedIndex = $selIdx2
                # Load the freshly saved data into the form
                Load-CustForm $srtAfter[$selIdx2]
            }
            $frmHdr.Text = "Editing:  $($tbName.Text.Trim())"
            $btnDl.Enabled = $true
            [System.Windows.Forms.MessageBox]::Show("Customer '$($tbName.Text.Trim())' saved successfully.", "Saved", 'OK', 'Information') | Out-Null
        } else {
            [System.Windows.Forms.MessageBox]::Show("Save failed.", "Error", 'OK', 'Error') | Out-Null
        }
    })

    $btnNw.Add_Click({ Clear-CustForm })
    $btnDl.Add_Click({
        if(-not $script:editingID){return}
        $r2=[System.Windows.Forms.MessageBox]::Show("Delete '$($tbName.Text.Trim())'? Cannot be undone.","Confirm Delete",'YesNo','Warning')
        if($r2 -ne 'Yes'){return}
        $dbD=Get-CustomersDB
        $dbD.Customers=[System.Collections.ArrayList]@($dbD.Customers|Where-Object{$_.ID -ne $script:editingID})
        if(Save-CustomersDB $dbD){Clear-CustForm;Refresh-LB}
    })
    $btnCl.Add_Click({ $dlg.Close() })

    Refresh-LB
    [void]$dlg.ShowDialog()
}

# ==============================================================================
#  EMAIL REPORT DIALOG
#  Sends the HTML report as an HTML email body using System.Net.Mail
# ==============================================================================


function Show-MainGUI {

    # --------------------------------------------------------------------------
    # COLOR PALETTE  (hardcoded - safe in Add_Paint closures)
    # --------------------------------------------------------------------------
    $CB  = [System.Drawing.Color]::FromArgb(0,   84,  166)   # Primary blue
    $CB2 = [System.Drawing.Color]::FromArgb(0,   55,  120)   # Dark blue
    $CB3 = [System.Drawing.Color]::FromArgb(0,  120,  212)   # Accent blue
    $CG  = [System.Drawing.Color]::FromArgb(16,  124,  16)   # Green
    $CO  = [System.Drawing.Color]::FromArgb(190,  90,   0)   # Orange
    $CP  = [System.Drawing.Color]::FromArgb( 88,  18, 136)   # Purple
    $CGR = [System.Drawing.Color]::FromArgb( 60,  64,  74)   # Dark gray
    $CR  = [System.Drawing.Color]::FromArgb(188,  28,  28)   # Red
    $CT  = [System.Drawing.Color]::FromArgb(  0, 116, 128)   # Teal
    $CW  = [System.Drawing.Color]::White
    $CBG = [System.Drawing.Color]::FromArgb(240, 242, 248)   # Window bg
    $CSF = [System.Drawing.Color]::FromArgb(248, 249, 252)   # Surface
    $CBR = [System.Drawing.Color]::FromArgb(218, 222, 232)   # Border
    $CT1 = [System.Drawing.Color]::FromArgb( 18,  22,  36)   # Text primary
    $CT2 = [System.Drawing.Color]::FromArgb( 96, 102, 120)   # Text secondary
    $CT3 = [System.Drawing.Color]::FromArgb(148, 154, 168)   # Text hint

    # Score stat colors
    $CSC_H = [System.Drawing.Color]::FromArgb( 16, 124,  16)  # Healthy green
    $CSC_W = [System.Drawing.Color]::FromArgb(180, 108,   0)  # Warning amber
    $CSC_C = [System.Drawing.Color]::FromArgb(188,  28,  28)  # Critical red
    $CSC_N = [System.Drawing.Color]::FromArgb(110, 118, 138)  # N/A gray

    # --------------------------------------------------------------------------
    # FORM
    # --------------------------------------------------------------------------
    $form = New-Object System.Windows.Forms.Form
    $form.Text            = "NourNet Infrastructure Health Check  |  v5.2 Professional"
    $form.Size            = New-Object System.Drawing.Size(1600, 960)
    $form.MinimumSize     = New-Object System.Drawing.Size(1280, 800)
    $form.StartPosition   = 'CenterScreen'
    $form.BackColor       = $CBG
    $form.Font            = New-Object System.Drawing.Font('Segoe UI', 9)
    $form.FormBorderStyle = 'Sizable'

    # --------------------------------------------------------------------------
    # ROOT LAYOUT  (TableLayoutPanel - 5 rows, guaranteed top-to-bottom order)
    # Row 0: Header bar          68px
    # Row 1: Dashboard ribbon    82px
    # Row 2: Action button bar   68px
    # Row 3: Progress strip      24px  (hidden when idle)
    # Row 4: Tab control         fills remaining height
    # --------------------------------------------------------------------------
    $root = New-Object System.Windows.Forms.TableLayoutPanel
    $root.Dock        = 'Fill'
    $root.ColumnCount = 1
    $root.RowCount    = 5
    $root.Padding     = New-Object System.Windows.Forms.Padding(0)
    $root.Margin      = New-Object System.Windows.Forms.Padding(0)
    [void]$root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,  68)))
    [void]$root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,  82)))
    [void]$root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,  84)))
    [void]$root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,  24)))
    [void]$root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    $form.Controls.Add($root)

    # ==========================================================================
    # ROW 0  -  HEADER BAR
    # Left:  N logo circle  +  Title  +  Subtitle
    # Right: Customer/Site label + TextBox
    # ==========================================================================
    $hdr = New-Object System.Windows.Forms.Panel
    $hdr.Dock      = 'Fill'
    $hdr.BackColor = $CB
    $hdr.Margin    = New-Object System.Windows.Forms.Padding(0)

    # Gradient paint on header
    $hdr.Add_Paint({
        param($s,$e)
        $r  = $s.ClientRectangle
        $g  = $e.Graphics
        $b1 = [System.Drawing.Color]::FromArgb(0, 84, 166)
        $b2 = [System.Drawing.Color]::FromArgb(0, 44, 110)
        $br = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
            $r, $b1, $b2,
            [System.Drawing.Drawing2D.LinearGradientMode]::Horizontal)
        $g.FillRectangle($br, $r)
        $br.Dispose()
        # Bottom accent line
        $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(0, 140, 255), 2)
        $g.DrawLine($pen, 0, $r.Height - 1, $r.Width, $r.Height - 1)
        $pen.Dispose()
    })

    # N logo circle (owner-drawn)
    $logo = New-Object System.Windows.Forms.Panel
    $logo.Location  = New-Object System.Drawing.Point(14, 10)
    $logo.Size      = New-Object System.Drawing.Size(48, 48)
    $logo.BackColor = [System.Drawing.Color]::Transparent
    $logo.Add_Paint({
        param($s,$e)
        $g = $e.Graphics
        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        # Circle fill
        $bg = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255,255,255,255))
        $g.FillEllipse($bg, 1, 1, 45, 45)
        $bg.Dispose()
        # Circle border
        $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(0, 120, 212), 2)
        $g.DrawEllipse($pen, 1, 1, 45, 45)
        $pen.Dispose()
        # Letter N
        $fnt = New-Object System.Drawing.Font('Segoe UI', 20, [System.Drawing.FontStyle]::Bold)
        $sf  = New-Object System.Drawing.StringFormat
        $sf.Alignment     = [System.Drawing.StringAlignment]::Center
        $sf.LineAlignment = [System.Drawing.StringAlignment]::Center
        $br2 = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(0, 84, 166))
        $g.DrawString('N', $fnt, $br2, [System.Drawing.RectangleF]::new(0,0,48,48), $sf)
        $br2.Dispose(); $fnt.Dispose(); $sf.Dispose()
    })
    $hdr.Controls.Add($logo)

    # Title
    $lblTitle = New-Object System.Windows.Forms.Label
    $lblTitle.Text      = "NOURNET  INFRASTRUCTURE HEALTH CHECK"
    $lblTitle.Location  = New-Object System.Drawing.Point(72, 10)
    $lblTitle.Size      = New-Object System.Drawing.Size(740, 30)
    $lblTitle.Font      = New-Object System.Drawing.Font('Segoe UI', 16, [System.Drawing.FontStyle]::Bold)
    $lblTitle.ForeColor = [System.Drawing.Color]::White
    $lblTitle.BackColor = [System.Drawing.Color]::Transparent
    $hdr.Controls.Add($lblTitle)

    $lblSub = New-Object System.Windows.Forms.Label
    $lblSub.Text      = "Professional MSP Tool  v5.2  |  Read-Only, Production-Safe  |  14 Health Checks  +  WinRM Connectivity Test"
    $lblSub.Location  = New-Object System.Drawing.Point(74, 43)
    $lblSub.Size      = New-Object System.Drawing.Size(820, 18)
    $lblSub.Font      = New-Object System.Drawing.Font('Segoe UI', 8, [System.Drawing.FontStyle]::Italic)
    $lblSub.ForeColor = [System.Drawing.Color]::FromArgb(160, 200, 255)
    $lblSub.BackColor = [System.Drawing.Color]::Transparent
    $hdr.Controls.Add($lblSub)

    # Right-side panel: anchored to the right edge, holds label + ComboBox + buttons
    $rightPnl = New-Object System.Windows.Forms.Panel
    $rightPnl.Anchor   = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
    $rightPnl.Size     = New-Object System.Drawing.Size(646, 68)
    $rightPnl.Location = New-Object System.Drawing.Point(($hdr.Width - 646), 0)
    $rightPnl.BackColor = [System.Drawing.Color]::Transparent
    $hdr.Controls.Add($rightPnl)
    # Keep panel aligned when header resizes
    $hdr.Add_Resize({ $rightPnl.Left = $hdr.Width - $rightPnl.Width })

    # CUSTOMER / SITE label
    $lblCustCap = New-Object System.Windows.Forms.Label
    $lblCustCap.Text      = "CUSTOMER / SITE:"
    $lblCustCap.Location  = New-Object System.Drawing.Point(0, 10)
    $lblCustCap.Size      = New-Object System.Drawing.Size(380, 14)
    $lblCustCap.Font      = New-Object System.Drawing.Font('Segoe UI', 7, [System.Drawing.FontStyle]::Bold)
    $lblCustCap.ForeColor = [System.Drawing.Color]::FromArgb(160, 200, 255)
    $lblCustCap.BackColor = [System.Drawing.Color]::Transparent
    $rightPnl.Controls.Add($lblCustCap)

    # Customer ComboBox
    $Script:CustomerCombo              = New-Object System.Windows.Forms.ComboBox
    $Script:CustomerCombo.Location     = New-Object System.Drawing.Point(0, 28)
    $Script:CustomerCombo.Size         = New-Object System.Drawing.Size(370, 30)
    $Script:CustomerCombo.Font         = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $Script:CustomerCombo.BackColor    = [System.Drawing.Color]::FromArgb(0, 55, 120)
    $Script:CustomerCombo.ForeColor    = [System.Drawing.Color]::White
    $Script:CustomerCombo.FlatStyle    = 'Flat'
    $Script:CustomerCombo.DropDownStyle = 'DropDownList'
    $rightPnl.Controls.Add($Script:CustomerCombo)

    # Manage Customers button (inside rightPnl, relative position)
    $btnManageCust = New-Object System.Windows.Forms.Button
    $btnManageCust.Location  = New-Object System.Drawing.Point(378, 22)
    $btnManageCust.Size      = New-Object System.Drawing.Size(130, 38)
    $btnManageCust.Text      = ""
    $btnManageCust.Font      = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)
    $btnManageCust.BackColor = [System.Drawing.Color]::FromArgb(0, 100, 200)
    $btnManageCust.ForeColor = [System.Drawing.Color]::White
    $btnManageCust.FlatStyle = 'Flat'
    $btnManageCust.FlatAppearance.BorderSize  = 0
    $btnManageCust.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(0,130,230)
    $btnManageCust.Cursor    = [System.Windows.Forms.Cursors]::Hand
    $btnManageCust.UseVisualStyleBackColor = $false
    $btnManageCust.Add_Paint({
        param($s,$e)
        $g = $e.Graphics
        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::ClearTypeGridFit
        $isHov = $s.ClientRectangle.Contains($s.PointToClient([System.Windows.Forms.Control]::MousePosition))
        $bgT = if($isHov){[System.Drawing.Color]::FromArgb(0,140,240)}else{[System.Drawing.Color]::FromArgb(0,110,215)}
        $bgB = if($isHov){[System.Drawing.Color]::FromArgb(0,100,190)}else{[System.Drawing.Color]::FromArgb(0,75,165)}
        $gr2 = New-Object System.Drawing.Drawing2D.LinearGradientBrush($s.ClientRectangle,$bgT,$bgB,
            [System.Drawing.Drawing2D.LinearGradientMode]::Vertical)
        $g.FillRectangle($gr2, $s.ClientRectangle); $gr2.Dispose()
        # Border
        $bPen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(80,180,255),1)
        $g.DrawRectangle($bPen, 0,0,$s.Width-1,$s.Height-1); $bPen.Dispose()
        # Text
        $sf2 = New-Object System.Drawing.StringFormat
        $sf2.Alignment = [System.Drawing.StringAlignment]::Center
        $sf2.LineAlignment = [System.Drawing.StringAlignment]::Center
        $fnt2 = New-Object System.Drawing.Font('Segoe UI',8,[System.Drawing.FontStyle]::Bold)
        $br3  = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
        $g.DrawString("Manage Customers",$fnt2,$br3,[System.Drawing.RectangleF]::new(0,0,$s.Width,$s.Height),$sf2)
        $fnt2.Dispose(); $br3.Dispose(); $sf2.Dispose()
    })
    $btnManageCust.Add_MouseEnter({ $this.Invalidate() })
    $btnManageCust.Add_MouseLeave({ $this.Invalidate() })
    $rightPnl.Controls.Add($btnManageCust)

    # Populate customer ComboBox from DB
    function Refresh-CustomerCombo {
        $Script:CustomerCombo.Items.Clear()
        $db = Get-CustomersDB
        [void]$Script:CustomerCombo.Items.Add('-- Select Customer --')
        $sortedC = [array]@($db.Customers | Sort-Object Name)
        foreach ($c in $sortedC) {
            $status = if ($c.LastStatus) { "  [$($c.LastStatus)]" } else { '' }
            [void]$Script:CustomerCombo.Items.Add("$($c.Name)$status")
        }
        # Restore last selected customer from settings.json
        $restoredIdx = 0
        try {
            if (Test-Path $Script:SettingsFile) {
                $settings = Get-Content $Script:SettingsFile -Raw | ConvertFrom-Json
                if ($settings.LastCustomerID) {
                    $lastID = $settings.LastCustomerID
                    for ($ri = 0; $ri -lt $sortedC.Count; $ri++) {
                        if ($sortedC[$ri].ID -eq $lastID) {
                            $restoredIdx = $ri + 1   # +1 because index 0 = '-- Select Customer --'
                            break
                        }
                    }
                }
            }
        } catch {}
        $Script:CustomerCombo.SelectedIndex = $restoredIdx
    }

    # When a customer is selected from dropdown
    $Script:CustomerCombo.Add_SelectedIndexChanged({
        $idx = $Script:CustomerCombo.SelectedIndex
        if ($idx -le 0) {
            $Script:ActiveCustomer  = $null
            $Script:CustomerName    = ''
            $Script:ServerInventory = [System.Collections.ArrayList]@()
            # Guard: ServersLabel may not exist yet during initial combo population
            if ($Script:ServersLabel) {
                $Script:ServersLabel.Text      = '0 loaded'
                $Script:ServersLabel.ForeColor = $CT1
            }
            return
        }
        $db   = Get-CustomersDB
        $sorted = @($db.Customers) | Sort-Object Name
        $cust = $sorted[$idx - 1]
        if (-not $cust) { return }
        $Script:ActiveCustomer     = $cust
        $Script:CustomerName       = $cust.Name
        $Script:ServerInventory    = Import-ServerInventory -CustomerProfile $cust
        # Set report path to customer's own folder if configured
        if ($cust.ReportPath -and $cust.ReportPath -ne '') {
            if (-not (Test-Path $cust.ReportPath)) {
                try { [void](New-Item -ItemType Directory -Path $cust.ReportPath -Force) } catch {}
            }
            $Script:ReportPath = $cust.ReportPath
        }
        $cnt = $Script:ServerInventory.Count
        # Guard: ServersLabel may not exist yet during initial combo population
        if ($Script:ServersLabel) {
            $Script:ServersLabel.Text      = "$cnt loaded"
            $Script:ServersLabel.ForeColor = $CB3
        }
        # Guard: LogTextBox may not exist yet during initial combo population
        if ($Script:LogTextBox) {
            Write-LogMessage "Customer selected: $($cust.Name)  |  $cnt server(s) loaded" -Color Cyan
            foreach ($s in $Script:ServerInventory) { Write-LogMessage "  + $($s.Name)  [$($s.Role)]" -Color Gray }
        }
        # Persist the selected customer ID so it's restored on next launch
        try {
            @{ LastCustomerID = $cust.ID } | ConvertTo-Json | Set-Content $Script:SettingsFile -Encoding UTF8 -Force
        } catch {}
    })

    # Manage Customers button opens the full Customer Profile Manager dialog
    $btnManageCust.Add_Click({ Show-CustomerManager; Refresh-CustomerCombo })

    # Upload Logo button - small, next to Manage Customers
    $btnLogo = New-Object System.Windows.Forms.Button
    $btnLogo.Location = New-Object System.Drawing.Point(516, 22)
    $btnLogo.Size     = New-Object System.Drawing.Size(130, 38)
    $btnLogo.Text     = ""
    $btnLogo.FlatStyle = 'Flat'
    $btnLogo.FlatAppearance.BorderSize = 0
    $btnLogo.BackColor = [System.Drawing.Color]::FromArgb(0,58,100)
    $btnLogo.ForeColor = [System.Drawing.Color]::White
    $btnLogo.Cursor    = [System.Windows.Forms.Cursors]::Hand
    $btnLogo.UseVisualStyleBackColor = $false
    $btnLogo.Add_Paint({
        param($s,$e)
        $g = $e.Graphics
        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::ClearTypeGridFit
        $isHov = $s.ClientRectangle.Contains($s.PointToClient([System.Windows.Forms.Control]::MousePosition))
        $bgC = if($isHov){[System.Drawing.Color]::FromArgb(0,80,140)}else{[System.Drawing.Color]::FromArgb(0,58,100)}
        $bgB = New-Object System.Drawing.SolidBrush($bgC); $g.FillRectangle($bgB,$s.ClientRectangle); $bgB.Dispose()
        $bP = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(60,140,220)); $g.DrawRectangle($bP,0,0,$s.Width-1,$s.Height-1); $bP.Dispose()
        $sf2 = New-Object System.Drawing.StringFormat; $sf2.Alignment=[System.Drawing.StringAlignment]::Center; $sf2.LineAlignment=[System.Drawing.StringAlignment]::Center
        $fLogo = New-Object System.Drawing.Font('Segoe UI',7,[System.Drawing.FontStyle]::Bold)
        $bLogo = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(140,200,255))
        $g.DrawString("Upload Logo",$fLogo,$bLogo,[System.Drawing.RectangleF]::new(2,0,$s.Width-2,$s.Height),$sf2)
        $fLogo.Dispose(); $bLogo.Dispose(); $sf2.Dispose()
    })
    $btnLogo.Add_MouseEnter({ $this.Invalidate() })
    $btnLogo.Add_MouseLeave({ $this.Invalidate() })
    $btnLogo.Add_Click({ Set-CompanyLogo })
    $rightPnl.Controls.Add($btnLogo)

    $root.Controls.Add($hdr, 0, 0)

    # ==========================================================================
    # ROW 1  -  DASHBOARD RIBBON
    # Left:  Health Score % (large)
    # Center: 4 stat tiles - Healthy / Warning / Critical / N/A
    # Right:  5 info fields - Date / Time / Technician / Servers / Connection
    # ==========================================================================
    $dash = New-Object System.Windows.Forms.Panel
    $dash.Dock      = 'Fill'
    $dash.BackColor = $CW
    $dash.Margin    = New-Object System.Windows.Forms.Padding(0)
    $dash.Add_Paint({
        param($s,$e)
        $p = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(218, 222, 232))
        $e.Graphics.DrawLine($p, 0, $s.Height-1, $s.Width, $s.Height-1)
        $p.Dispose()
    })

    # Score block
    $lblScoreCap = New-Object System.Windows.Forms.Label
    $lblScoreCap.Text      = "HEALTH SCORE"
    $lblScoreCap.Location  = New-Object System.Drawing.Point(16, 8)
    $lblScoreCap.Size      = New-Object System.Drawing.Size(130, 14)
    $lblScoreCap.Font      = New-Object System.Drawing.Font('Segoe UI', 7, [System.Drawing.FontStyle]::Bold)
    $lblScoreCap.ForeColor = $CT2
    $dash.Controls.Add($lblScoreCap)

    $Script:ScoreValue          = New-Object System.Windows.Forms.Label
    $Script:ScoreValue.Text     = "--"
    $Script:ScoreValue.Location = New-Object System.Drawing.Point(10, 22)
    $Script:ScoreValue.Size     = New-Object System.Drawing.Size(148, 52)
    $Script:ScoreValue.Font     = New-Object System.Drawing.Font('Segoe UI', 32, [System.Drawing.FontStyle]::Bold)
    $Script:ScoreValue.ForeColor = $CT2
    $dash.Controls.Add($Script:ScoreValue)

    # Vertical divider after score
    $div0 = New-Object System.Windows.Forms.Label
    $div0.Location  = New-Object System.Drawing.Point(164, 8)
    $div0.Size      = New-Object System.Drawing.Size(1, 64)
    $div0.BackColor = $CBR
    $dash.Controls.Add($div0)

    # Stat tiles: Healthy / Warning / Critical / N/A
    $statDefs = @(
        @{ Cap='HEALTHY';  Clr=$CSC_H; VN='HealthyCount';  X=178 }
        @{ Cap='WARNING';  Clr=$CSC_W; VN='WarningCount';  X=370 }
        @{ Cap='CRITICAL'; Clr=$CSC_C; VN='CriticalCount'; X=562 }
        @{ Cap='N/A';      Clr=$CSC_N; VN='InfoCount';     X=754 }
    )
    foreach ($sd in $statDefs) {
        $c = New-Object System.Windows.Forms.Label
        $c.Text = $sd.Cap; $c.Location = New-Object System.Drawing.Point($sd.X, 8)
        $c.Size = New-Object System.Drawing.Size(185, 14)
        $c.Font = New-Object System.Drawing.Font('Segoe UI', 7, [System.Drawing.FontStyle]::Bold)
        $c.ForeColor = $sd.Clr; $dash.Controls.Add($c)

        $n = New-Object System.Windows.Forms.Label
        $n.Text = "0"; $n.Location = New-Object System.Drawing.Point(($sd.X + 4), 22)
        $n.Size = New-Object System.Drawing.Size(120, 52)
        $n.Font = New-Object System.Drawing.Font('Segoe UI', 30, [System.Drawing.FontStyle]::Bold)
        $n.ForeColor = $sd.Clr
        switch ($sd.VN) {
            'HealthyCount'  { $Script:HealthyCount  = $n }
            'WarningCount'  { $Script:WarningCount  = $n }
            'CriticalCount' { $Script:CriticalCount = $n }
            'InfoCount'     { $Script:InfoCount      = $n }
        }
        $dash.Controls.Add($n)

        # Divider after each stat
        $dv = New-Object System.Windows.Forms.Label
        $dv.Location  = New-Object System.Drawing.Point(($sd.X + 185), 8)
        $dv.Size      = New-Object System.Drawing.Size(1, 64)
        $dv.BackColor = $CBR
        $dash.Controls.Add($dv)
    }

    # Overall status label
    $Script:OverallLabel          = New-Object System.Windows.Forms.Label
    $Script:OverallLabel.Text     = "NO DATA"
    $Script:OverallLabel.Location = New-Object System.Drawing.Point(940, 8)
    $Script:OverallLabel.Size     = New-Object System.Drawing.Size(180, 40)
    $Script:OverallLabel.Font     = New-Object System.Drawing.Font('Segoe UI', 14, [System.Drawing.FontStyle]::Bold)
    $Script:OverallLabel.ForeColor = $CT2
    $Script:OverallLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $Script:OverallLabel.BackColor = [System.Drawing.Color]::Transparent
    $dash.Controls.Add($Script:OverallLabel)

    # Divider before info fields
    $divInfo = New-Object System.Windows.Forms.Label
    $divInfo.Location  = New-Object System.Drawing.Point(1116, 8)
    $divInfo.Size      = New-Object System.Drawing.Size(1, 64)
    $divInfo.BackColor = $CBR
    $dash.Controls.Add($divInfo)

    # 5 info fields (compact, right side of dash)
    $infoFields = @(
        @{ Cap='DATE';        Val=(Get-Date -Format 'ddd, dd MMM yyyy'); X=1126; VN='' }
        @{ Cap='TIME';        Val=(Get-Date -Format 'HH:mm:ss');         X=1262; VN='' }
        @{ Cap='TECHNICIAN';  Val='';                                     X=1380; VN='TechLabel' }
        @{ Cap='SERVERS';     Val='0 loaded';                             X=1490; VN='ServersLabel' }
    )
    foreach ($fi in $infoFields) {
        $cl = New-Object System.Windows.Forms.Label
        $cl.Text = $fi.Cap; $cl.Location = New-Object System.Drawing.Point($fi.X, 8)
        $cl.Size = New-Object System.Drawing.Size(140, 14)
        $cl.Font = New-Object System.Drawing.Font('Segoe UI', 7, [System.Drawing.FontStyle]::Bold)
        $cl.ForeColor = $CT2; $dash.Controls.Add($cl)

        $vl = New-Object System.Windows.Forms.Label
        $vl.Text = $fi.Val; $vl.Location = New-Object System.Drawing.Point($fi.X, 24)
        $vl.Size = New-Object System.Drawing.Size(140, 32)
        $vl.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
        $vl.ForeColor = $CT1
        switch ($fi.VN) {
            'TechLabel'    { $Script:TechLabel    = $vl }
            'ServersLabel' { $Script:ServersLabel = $vl }
        }
        $dash.Controls.Add($vl)
    }

    # Connection status (uses special color)
    $lblConnCap = New-Object System.Windows.Forms.Label
    $lblConnCap.Text = "CONNECTION"; $lblConnCap.Location = New-Object System.Drawing.Point(1490, 58)
    $lblConnCap.Size = New-Object System.Drawing.Size(140, 14)
    $lblConnCap.Font = New-Object System.Drawing.Font('Segoe UI', 7, [System.Drawing.FontStyle]::Bold)
    $lblConnCap.ForeColor = $CT2; $dash.Controls.Add($lblConnCap)
    # (We'll reuse ServersLabel slot at X=1490 for Connection, shift Servers to X=1356)
    # Actually let's reorganize: use 5 fields more compactly
    # DATE(1126) TIME(1224) TECH(1322) SERVERS(1420) CONN(1510)
    # Remove what we added and redo with better spacing
    foreach ($ctrl in @($dash.Controls | Where-Object {
        $_.Location.X -ge 1126 -and $_.GetType().Name -eq 'Label'
    })) { $dash.Controls.Remove($ctrl) }

    $infoFields2 = @(
        @{ Cap='DATE';       Val=(Get-Date -Format 'ddd, dd MMM yyyy'); X=1126; W=96;  VN='' }
        @{ Cap='TIME';       Val=(Get-Date -Format 'HH:mm:ss');         X=1228; W=90;  VN='' }
        @{ Cap='TECHNICIAN'; Val='';                                     X=1324; W=170; VN='TechLabel' }
        @{ Cap='SERVERS';    Val='0 loaded';                             X=1500; W=96;  VN='ServersLabel' }
    )
    foreach ($fi in $infoFields2) {
        $cl = New-Object System.Windows.Forms.Label
        $cl.Text = $fi.Cap; $cl.Location = New-Object System.Drawing.Point($fi.X, 8)
        $cl.Size = New-Object System.Drawing.Size($fi.W, 14)
        $cl.Font = New-Object System.Drawing.Font('Segoe UI', 7, [System.Drawing.FontStyle]::Bold)
        $cl.ForeColor = $CT2; $dash.Controls.Add($cl)

        $vl = New-Object System.Windows.Forms.Label
        $vl.Text = $fi.Val; $vl.Location = New-Object System.Drawing.Point($fi.X, 24)
        $vl.Size = New-Object System.Drawing.Size($fi.W, 52)
        $vl.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
        $vl.ForeColor = $CT1
        switch ($fi.VN) {
            'TechLabel'    { $Script:TechLabel    = $vl }
            'ServersLabel' { $Script:ServersLabel = $vl }
        }
        $dash.Controls.Add($vl)

        if ($fi.X -lt 1500) {
            $dvi = New-Object System.Windows.Forms.Label
            $dvi.Location = New-Object System.Drawing.Point(($fi.X + $fi.W + 2), 8)
            $dvi.Size = New-Object System.Drawing.Size(1, 64); $dvi.BackColor = $CBR
            $dash.Controls.Add($dvi)
        }
    }

    # Connection label (special - colored dynamically)
    $lblConnCap2 = New-Object System.Windows.Forms.Label
    $lblConnCap2.Text = "CONNECTION"; $lblConnCap2.Location = New-Object System.Drawing.Point(1126, 8)
    # We'll position Connection differently - use a right-side placement
    # Actually let's put it at X=1600 area OR overlay the overall label area
    # The cleanest: put CONNECTION under the Overall label
    $Script:StatusLabel = New-Object System.Windows.Forms.Label
    $Script:StatusLabel.Text      = "Not Connected"
    $Script:StatusLabel.Location  = New-Object System.Drawing.Point(940, 50)
    $Script:StatusLabel.Size      = New-Object System.Drawing.Size(180, 22)
    $Script:StatusLabel.Font      = New-Object System.Drawing.Font('Segoe UI', 8, [System.Drawing.FontStyle]::Bold)
    $Script:StatusLabel.ForeColor = $CT2
    $Script:StatusLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $Script:StatusLabel.BackColor = [System.Drawing.Color]::Transparent
    $dash.Controls.Add($Script:StatusLabel)

    $root.Controls.Add($dash, 0, 1)
    # Populate customer dropdown NOW - after all dashboard labels are created
    Refresh-CustomerCombo

    # ==========================================================================
    # ROW 2  -  ACTION BUTTON BAR
    # 7 equal buttons: CONNECT | RUN CHECK | TEST WinRM | EXPORT | VIEW SERVERS | ACTIVITY LOG | DISCONNECT
    # Clean flat style with icon text, subtle hover, colored per action type
    # ==========================================================================
    $btnBar = New-Object System.Windows.Forms.Panel
    $btnBar.Dock      = 'Fill'
    $btnBar.BackColor = [System.Drawing.Color]::FromArgb(14, 18, 30)   # Dark navy bar
    $btnBar.Margin    = New-Object System.Windows.Forms.Padding(0)

    function New-ActionBtn {
        param(
            [string]$Line1,
            [string]$Line2,
            [System.Drawing.Color]$AccentColor,
            [int]$X,
            [int]$Width = 212
        )
        $b = New-Object System.Windows.Forms.Button
        $b.Location                          = New-Object System.Drawing.Point($X, 4)
        $b.Size                              = New-Object System.Drawing.Size($Width, 76)
        $b.BackColor                         = [System.Drawing.Color]::FromArgb(22, 28, 44)
        $b.ForeColor                         = [System.Drawing.Color]::White
        $b.FlatStyle                         = 'Flat'
        $b.FlatAppearance.BorderSize         = 0
        $b.FlatAppearance.BorderColor        = [System.Drawing.Color]::FromArgb(22, 28, 44)
        $b.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(22, 28, 44)
        $b.Cursor                            = [System.Windows.Forms.Cursors]::Hand
        $b.UseVisualStyleBackColor           = $false
        # Tag: "Line1|Line2|aR|aG|aB"
        $b.Tag = "$Line1|$Line2|$($AccentColor.R)|$($AccentColor.G)|$($AccentColor.B)"

        $b.Add_Paint({
            param($s,$e)
            $g = $e.Graphics
            $g.SmoothingMode     = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
            $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::ClearTypeGridFit

            $parts = $s.Tag -split '\|'
            $l1 = $parts[0]; $l2 = $parts[1]
            $aR = [int]$parts[2]; $aG = [int]$parts[3]; $aB = [int]$parts[4]
            $isEnabled = $s.Enabled
            $isHover   = $s.ClientRectangle.Contains($s.PointToClient([System.Windows.Forms.Control]::MousePosition))

            $aCol = if ($isEnabled) { [System.Drawing.Color]::FromArgb($aR,$aG,$aB) } `
                    else            { [System.Drawing.Color]::FromArgb(45,52,68) }

            # --- Gradient background ---
            $bgTop = if (-not $isEnabled) { [System.Drawing.Color]::FromArgb(22,26,38) }
                     elseif ($isHover)    { [System.Drawing.Color]::FromArgb(42,52,78) }
                     else                 { [System.Drawing.Color]::FromArgb(28,36,56) }
            $bgBot = if (-not $isEnabled) { [System.Drawing.Color]::FromArgb(18,22,32) }
                     elseif ($isHover)    { [System.Drawing.Color]::FromArgb(32,42,64) }
                     else                 { [System.Drawing.Color]::FromArgb(20,28,46) }
            $grad = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
                $s.ClientRectangle, $bgTop, $bgBot,
                [System.Drawing.Drawing2D.LinearGradientMode]::Vertical)
            $g.FillRectangle($grad, $s.ClientRectangle)
            $grad.Dispose()

            # --- Accent left bar (10px, with inner glow) ---
            $acBr = New-Object System.Drawing.SolidBrush($aCol)
            $g.FillRectangle($acBr, 0, 0, 10, $s.Height)
            $acBr.Dispose()
            # Glow: semi-transparent wide bar behind accent
            if ($isEnabled) {
                $glowCol = [System.Drawing.Color]::FromArgb(40,$aR,$aG,$aB)
                $glowBr  = New-Object System.Drawing.SolidBrush($glowCol)
                $g.FillRectangle($glowBr, 10, 0, 18, $s.Height)
                $glowBr.Dispose()
            }

            # --- Top accent line (full width, 2px) ---
            $topPen = New-Object System.Drawing.Pen($aCol, 2)
            $g.DrawLine($topPen, 0, 0, $s.Width, 0)
            $topPen.Dispose()

            # --- Bottom separator line (subtle) ---
            $sepA   = if($isHover){80}else{40}

            $sepCol = [System.Drawing.Color]::FromArgb($sepA, 255,255,255)
            $sepPen = New-Object System.Drawing.Pen($sepCol, 1)
            $g.DrawLine($sepPen, 10, $s.Height-1, $s.Width-1, $s.Height-1)
            $sepPen.Dispose()

            # --- Main label ---
            $f1c = if ($isEnabled) { [System.Drawing.Color]::White } `
                   else            { [System.Drawing.Color]::FromArgb(55,62,82) }
            $f1  = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
            $br1 = New-Object System.Drawing.SolidBrush($f1c)
            $sf  = New-Object System.Drawing.StringFormat
            $sf.Alignment     = [System.Drawing.StringAlignment]::Center
            $sf.LineAlignment = [System.Drawing.StringAlignment]::Center
            $sf.FormatFlags   = [System.Drawing.StringFormatFlags]::NoWrap
            $g.DrawString($l1, $f1, $br1, [System.Drawing.RectangleF]::new(14, 6, $s.Width-16, 36), $sf)
            $f1.Dispose(); $br1.Dispose()

            $bR = [Math]::Min(255,$aR+60); $bG = [Math]::Min(255,$aG+60); $bB = [Math]::Min(255,$aB+60)
            $f2c = if ($isEnabled) { [System.Drawing.Color]::FromArgb($bR,$bG,$bB) } else { [System.Drawing.Color]::FromArgb(42,50,68) }
            $f2  = New-Object System.Drawing.Font('Segoe UI', 8, [System.Drawing.FontStyle]::Regular)
            $br2 = New-Object System.Drawing.SolidBrush($f2c)
            $g.DrawString($l2, $f2, $br2, [System.Drawing.RectangleF]::new(14, 42, $s.Width-16, 26), $sf)
            $f2.Dispose(); $br2.Dispose(); $sf.Dispose()
        })
        $b.Add_MouseEnter({ $this.Invalidate() })
        $b.Add_MouseLeave({ $this.Invalidate() })
        $b.Add_EnabledChanged({ $this.Invalidate() })
        return $b
    }

    # 7 buttons - calculated to fill the 1600px wide bar with equal spacing
    # Total width = 1600 - 2*margin(12) = 1576
    # 7 buttons + 6 gaps: buttonW = (1576 - 6*6) / 7 = (1576-36)/7 = 1540/7 = 220
    $btnX = 12; $btnW = 220; $btnG = 6
    # 6 buttons now (CONNECT is also DISCONNECT toggle - no separate Disconnect button)
    # Recalculate width: 6 buttons + 5 gaps in 1576px = (1576-30)/6 = 257px each
    $btnX = 12; $btnW = 257; $btnG = 6
    # Workflow sequence: CONNECT -> TEST WinRM -> RUN CHECK -> EXPORT -> VIEW SERVERS -> ACTIVITY LOG
    $Script:btnConnect    = New-ActionBtn 'CONNECT'       'to Servers'         $CB3  $btnX $btnW; $btnX += $btnW + $btnG
    $Script:btnWinRMTest  = New-ActionBtn 'TEST WinRM'    'Check Connectivity' $CT   $btnX $btnW; $btnX += $btnW + $btnG
    $Script:btnRunCheck   = New-ActionBtn 'RUN CHECK'     'Full Health Scan'   $CG   $btnX $btnW; $btnX += $btnW + $btnG
    $Script:btnExport     = New-ActionBtn 'EXPORT'        'HTML + CSV Report'  $CO   $btnX $btnW; $btnX += $btnW + $btnG
    $Script:btnServers    = New-ActionBtn 'VIEW SERVERS'  'Inventory'          $CP   $btnX $btnW; $btnX += $btnW + $btnG
    $Script:btnLog        = New-ActionBtn 'ACTIVITY LOG'  'View Log'           $CGR  $btnX $btnW
    $Script:btnDisconnect = $Script:btnConnect   # Same button - toggle mode

    foreach ($b in @($Script:btnConnect,$Script:btnWinRMTest,$Script:btnRunCheck,
                     $Script:btnExport,$Script:btnServers,$Script:btnLog)) {
        $btnBar.Controls.Add($b)
    }
    $root.Controls.Add($btnBar, 0, 2)

    # ==========================================================================
    # ROW 3  -  PROGRESS STRIP  (thin, hidden when idle)
    # ==========================================================================
    $progPnl = New-Object System.Windows.Forms.Panel
    $progPnl.Dock      = 'Fill'
    $progPnl.BackColor = [System.Drawing.Color]::FromArgb(18, 22, 34)
    $progPnl.Margin    = New-Object System.Windows.Forms.Padding(0)
    $progPnl.Visible   = $false

    $Script:ProgressBar = New-Object System.Windows.Forms.ProgressBar
    $Script:ProgressBar.Location = New-Object System.Drawing.Point(0, 0)
    $Script:ProgressBar.Size     = New-Object System.Drawing.Size(1200, 6)
    $Script:ProgressBar.Minimum  = 0
    $Script:ProgressBar.Maximum  = 100
    $Script:ProgressBar.Value    = 0
    $Script:ProgressBar.Style    = 'Continuous'
    $progPnl.Controls.Add($Script:ProgressBar)

    $Script:ProgressLabel = New-Object System.Windows.Forms.Label
    $Script:ProgressLabel.Text      = ""
    $Script:ProgressLabel.Location  = New-Object System.Drawing.Point(8, 7)
    $Script:ProgressLabel.Size      = New-Object System.Drawing.Size(1400, 16)
    $Script:ProgressLabel.Font      = New-Object System.Drawing.Font('Segoe UI', 7)
    $Script:ProgressLabel.ForeColor = [System.Drawing.Color]::FromArgb(120, 160, 220)
    $progPnl.Controls.Add($Script:ProgressLabel)
    $root.Controls.Add($progPnl, 0, 3)

    # ==========================================================================
    # ROW 4  -  TAB CONTROL
    # Tab 1: Health Check Results  (DataGridView)
    # Tab 2: WinRM Connectivity    (DataGridView)
    # Tab 3: Activity Log          (RichTextBox dark terminal)
    # ==========================================================================
    $tabs = New-Object System.Windows.Forms.TabControl
    $tabs.Dock    = 'Fill'
    $tabs.Font    = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $tabs.Padding = New-Object System.Drawing.Point(16, 6)
    $tabs.Margin  = New-Object System.Windows.Forms.Padding(0)

    # Helper: build a styled DataGridView
    function New-StyledGrid {
        $g2 = New-Object System.Windows.Forms.DataGridView
        $g2.Dock          = 'Fill'
        $g2.ReadOnly      = $true
        $g2.AllowUserToAddRows    = $false
        $g2.AllowUserToDeleteRows = $false
        $g2.BackgroundColor       = $CW
        $g2.BorderStyle           = 'None'
        $g2.GridColor             = [System.Drawing.Color]::FromArgb(230, 234, 242)
        $g2.RowHeadersVisible     = $false
        $g2.SelectionMode         = 'FullRowSelect'
        $g2.MultiSelect           = $false
        $g2.AutoSizeColumnsMode   = 'None'   # Columns sized manually per grid
        $g2.RowTemplate.Height    = 34
        $g2.ColumnHeadersHeight   = 38
        $g2.EnableHeadersVisualStyles = $false
        $g2.CellBorderStyle       = [System.Windows.Forms.DataGridViewCellBorderStyle]::SingleHorizontal
        $g2.DefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(210, 228, 252)
        $g2.DefaultCellStyle.SelectionForeColor = $CT1
        $hs = $g2.ColumnHeadersDefaultCellStyle
        $hs.BackColor  = [System.Drawing.Color]::FromArgb(22, 28, 48)
        $hs.ForeColor  = [System.Drawing.Color]::FromArgb(168, 192, 228)
        $hs.Font       = New-Object System.Drawing.Font('Segoe UI', 8, [System.Drawing.FontStyle]::Bold)
        $hs.SelectionBackColor = [System.Drawing.Color]::FromArgb(22, 28, 48)
        $g2.DefaultCellStyle.Font = New-Object System.Drawing.Font('Segoe UI', 9)
        return $g2
    }

    # --- Results tab ---
    $tabResults          = New-Object System.Windows.Forms.TabPage
    $tabResults.Text     = "   Health Check Results   "
    $tabResults.BackColor = $CW
    $Script:ResultsGrid = New-StyledGrid
    $Script:ResultsGrid.Add_CellDoubleClick({
        param($s,$e)
        if ($e.RowIndex -lt 0) { return }
        $row  = $s.Rows[$e.RowIndex]
        $chk  = [string]$row.Cells['Check'].Value
        $st   = [string]$row.Cells['Status'].Value
        $srv  = [string]$row.Cells['Servers'].Value
        $sum  = [string]$row.Cells['Summary'].Value
        [System.Windows.Forms.MessageBox]::Show(
            "CHECK:`n  $chk`n`nSTATUS:`n  $st`n`nSERVERS:`n  $srv`n`nSUMMARY:`n  $sum`n`nExport HTML for full detail tables.",
            "Check Details  -  $chk", 'OK', 'Information') | Out-Null
    })
    # Alternating row colors via RowPrePaint
    $Script:ResultsGrid.Add_RowPrePaint({
        param($s,$e)
        if ($e.RowIndex -lt 0) { return }
        $row = $s.Rows[$e.RowIndex]
        $sv  = [string]$row.Cells['Status'].Value
        switch ($sv) {
            'Healthy'  { $row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(238,252,238); $row.DefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(10,100,10) }
            'Warning'  { $row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,251,220); $row.DefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(128,96,0) }
            'Critical' { $row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,232,232); $row.DefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(166,10,10) }
            default    { $row.DefaultCellStyle.BackColor = if ($e.RowIndex % 2) { [System.Drawing.Color]::FromArgb(248,249,252) } else { $CW }
                         $row.DefaultCellStyle.ForeColor = $CT2 }
        }
    })
    $tabResults.Controls.Add($Script:ResultsGrid)
    $tabs.Controls.Add($tabResults)

    # --- WinRM tab ---
    $tabWinRM          = New-Object System.Windows.Forms.TabPage
    $tabWinRM.Text     = "   WinRM Connectivity   "
    $tabWinRM.BackColor = $CW
    $Script:WinRMGrid = New-StyledGrid
    $Script:WinRMGrid.Add_RowPrePaint({
        param($s,$e)
        if ($e.RowIndex -lt 0) { return }
        $row = $s.Rows[$e.RowIndex]
        $res = [string]$row.Cells['Result'].Value
        switch ($res) {
            'READY'         { $row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(238,252,238); $row.DefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(10,100,10) }
            'WinRM BLOCKED' { $row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,251,220); $row.DefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(128,96,0) }
            'AUTH FAIL'     { $row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,251,220); $row.DefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(128,96,0) }
            default         { $row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,232,232); $row.DefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(166,10,10) }
        }
    })
    $tabWinRM.Controls.Add($Script:WinRMGrid)
    $tabs.Controls.Add($tabWinRM)

    # --- Activity Log tab ---
    $tabLog           = New-Object System.Windows.Forms.TabPage
    $tabLog.Text      = "   Activity Log   "
    $tabLog.BackColor = [System.Drawing.Color]::FromArgb(14, 18, 26)

    $Script:LogTextBox = New-Object System.Windows.Forms.RichTextBox
    $Script:LogTextBox.Dock        = 'Fill'
    $Script:LogTextBox.ReadOnly    = $true
    $Script:LogTextBox.BackColor   = [System.Drawing.Color]::FromArgb(14, 18, 26)
    $Script:LogTextBox.ForeColor   = [System.Drawing.Color]::FromArgb(180, 198, 220)
    $Script:LogTextBox.Font        = New-Object System.Drawing.Font('Consolas', 9)
    $Script:LogTextBox.BorderStyle = 'None'
    $Script:LogTextBox.ScrollBars  = 'Vertical'
    $tabLog.Controls.Add($Script:LogTextBox)
    $tabs.Controls.Add($tabLog)

    $root.Controls.Add($tabs, 0, 4)

    # ==========================================================================
    # STATUS STRIP
    # ==========================================================================
    $strip = New-Object System.Windows.Forms.StatusStrip
    $strip.BackColor  = [System.Drawing.Color]::FromArgb(22, 28, 48)
    $strip.ForeColor  = [System.Drawing.Color]::FromArgb(160, 176, 210)
    $strip.SizingGrip = $true
    $strip.Add_Paint({
        param($s,$e)
        $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(0, 120, 212), 1)
        $e.Graphics.DrawLine($pen, 0, 0, $s.Width, 0)
        $pen.Dispose()
    })

    $Script:StatusBarLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
    $Script:StatusBarLabel.Text      = "Ready  -  Click CONNECT to begin"
    $Script:StatusBarLabel.Font      = New-Object System.Drawing.Font('Segoe UI', 8)
    $Script:StatusBarLabel.ForeColor = [System.Drawing.Color]::FromArgb(160, 176, 210)
    $strip.Items.Add($Script:StatusBarLabel) | Out-Null

    $srRight = New-Object System.Windows.Forms.ToolStripStatusLabel
    $srRight.Text      = "NourNet MSP  |  v5.2 Professional  |  Read-Only"
    $srRight.Spring    = $true
    $srRight.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $srRight.Font      = New-Object System.Drawing.Font('Segoe UI', 8)
    $srRight.ForeColor = [System.Drawing.Color]::FromArgb(100, 120, 160)
    $strip.Items.Add($srRight) | Out-Null
    $form.Controls.Add($strip)

    # ==========================================================================
    # HELPER FUNCTIONS
    # ==========================================================================
    function Write-LogMessage {
        param([string]$Message, [string]$Color = 'Gray')
        if (-not $Script:LogTextBox) { return }
        $ts  = Get-Date -Format 'HH:mm:ss'
        $cm  = @{
            Gray   = [System.Drawing.Color]::FromArgb(148, 162, 182)
            Green  = [System.Drawing.Color]::FromArgb( 92, 200, 110)
            Red    = [System.Drawing.Color]::FromArgb(248, 100,  90)
            Yellow = [System.Drawing.Color]::FromArgb(248, 210,  60)
            Cyan   = [System.Drawing.Color]::FromArgb( 72, 196, 255)
            White  = [System.Drawing.Color]::FromArgb(220, 228, 245)
            Orange = [System.Drawing.Color]::FromArgb(255, 168,  60)
        }
        $col = if ($cm.ContainsKey($Color)) { $cm[$Color] } else { $cm.Gray }
        $Script:LogTextBox.SelectionStart = $Script:LogTextBox.TextLength
        $Script:LogTextBox.SelectionColor = $col
        $Script:LogTextBox.AppendText("[$ts]  $Message`n")
        $Script:LogTextBox.ScrollToCaret()
    }

    function Set-Progress {
        param([int]$Pct, [string]$Text)
        if ($Script:ProgressBar)  { $Script:ProgressBar.Value  = [math]::Min(100,[math]::Max(0,$Pct)) }
        if ($Script:ProgressLabel){ $Script:ProgressLabel.Text = $Text }
        $form.Refresh()
    }

    function Update-Dashboard {
        $cH=0; $cW=0; $cC=0; $cN=0
        $dt = New-Object System.Data.DataTable
        [void]$dt.Columns.Add('#',        [string])
        [void]$dt.Columns.Add('Category', [string])
        [void]$dt.Columns.Add('Check',    [string])
        [void]$dt.Columns.Add('Status',   [string])
        [void]$dt.Columns.Add('Servers',  [string])
        [void]$dt.Columns.Add('Summary',  [string])

        $labelMap = @{
            AD_Replication='AD Replication Status'; AD_TimeSync='AD Time Sync Status'
            AD_DiskStatus='DC Disk Space (>=75%)'; Admin_Groups='Domain and Enterprise Admins'
            Exch_Replication='Exchange DAG / Replication'; Exch_Health='Exchange Health Checkup'
            Exch_DiskStatus='Exchange Disk Space (>=75%)'; Exch_DBSizeLimit='Exchange DB Size Limits (Std 1TB)'
            Exch_Edition='Exchange Edition and Version'; Exch_TimeSync='Exchange Time Sync'
            DFS_Certificate='DFS Certificate Validation'; DFS_Replication='DFS Replication Status'
            SSL_ADFS='ADFS SSL Certificates'; SSL_Exchange='Exchange SSL Certificates'
        }
        $catMap = @{
            AD_Replication='Active Directory'; AD_TimeSync='Active Directory'
            AD_DiskStatus='Active Directory'; Admin_Groups='Active Directory'
            Exch_Replication='Exchange Server'; Exch_Health='Exchange Server'
            Exch_DiskStatus='Exchange Server'; Exch_DBSizeLimit='Exchange Server'
            Exch_Edition='Exchange Server'; Exch_TimeSync='Exchange Server'
            DFS_Certificate='DFS'; DFS_Replication='DFS'
            SSL_ADFS='Security'; SSL_Exchange='Security'
        }
        $orderedKeys = @('AD_Replication','AD_TimeSync','AD_DiskStatus','Admin_Groups',
            'Exch_Replication','Exch_Health','Exch_DiskStatus','Exch_DBSizeLimit',
            'Exch_Edition','Exch_TimeSync','DFS_Certificate','DFS_Replication',
            'SSL_ADFS','SSL_Exchange')

        $rn = 1
        foreach ($key in $orderedKeys) {
            if (-not $Script:LastResults -or -not $Script:LastResults.Contains($key)) { continue }
            $r   = $Script:LastResults[$key]
            $cat = if ($catMap.ContainsKey($key))  { $catMap[$key] }  else { 'Other' }
            $lbl = if ($labelMap.ContainsKey($key)) { $labelMap[$key] } else { $key -replace '_',' ' }
            $st  = if ($r.Status)  { $r.Status }  else { 'Unknown' }
            $sv  = if ($r.Server)  { $r.Server }  else { 'N/A' }
            $sm  = if ($r.Comment) { $r.Comment } else { '' }
            [void]$dt.Rows.Add($rn.ToString(), $cat, $lbl, $st, $sv, $sm)
            switch ($st) { 'Healthy'{$cH++} 'Warning'{$cW++} 'Critical'{$cC++} default{$cN++} }
            $rn++
        }

        $Script:ResultsGrid.AutoGenerateColumns = $false
        # Define columns with precise widths before binding
        if ($Script:ResultsGrid.Columns.Count -eq 0) {
            $rc0 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
            $rc0.DataPropertyName = '#';        $rc0.HeaderText = '#';        $rc0.Width = 44
            $rc0.DefaultCellStyle.Alignment = 'MiddleCenter'
            $rc0.HeaderCell.Style.Alignment = 'MiddleCenter'
            [void]$Script:ResultsGrid.Columns.Add($rc0)

            $rc1 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
            $rc1.DataPropertyName = 'Category'; $rc1.HeaderText = 'Category'; $rc1.Width = 148
            [void]$Script:ResultsGrid.Columns.Add($rc1)

            $rc2 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
            $rc2.Name = 'Check'; $rc2.DataPropertyName = 'Check';    $rc2.HeaderText = 'Check';    $rc2.Width = 210
            [void]$Script:ResultsGrid.Columns.Add($rc2)

            $rc3 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
            $rc3.Name = 'Status'; $rc3.DataPropertyName = 'Status';   $rc3.HeaderText = 'Status';   $rc3.Width = 88
            $rc3.DefaultCellStyle.Alignment = 'MiddleCenter'
            $rc3.HeaderCell.Style.Alignment = 'MiddleCenter'
            [void]$Script:ResultsGrid.Columns.Add($rc3)

            $rc4 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
            $rc4.Name = 'Servers'; $rc4.DataPropertyName = 'Servers';  $rc4.HeaderText = 'Servers';  $rc4.Width = 220
            [void]$Script:ResultsGrid.Columns.Add($rc4)

            $rc5 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
            $rc5.Name = 'Summary'; $rc5.DataPropertyName = 'Summary';  $rc5.HeaderText = 'Summary'
            $rc5.AutoSizeMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill
            [void]$Script:ResultsGrid.Columns.Add($rc5)
        }
        $Script:ResultsGrid.DataSource = $dt
        $Script:ResultsGrid.AutoSizeColumnsMode = 'None'
        $total = $cH + $cW + $cC + $cN
        if ($total -gt 0) {
            # Health Score = (Healthy checks / Total checks run) * 100
            # Example: 8 healthy out of 12 total = 67%
            # >= 80% = Green (Healthy), 60-79% = Orange (Warning), < 60% = Red (Critical)
            # Health Score = ROUND(Healthy / Total x 100). >=80 Green, 60-79 Orange, <60 Red
            $pct = [math]::Round(($cH / $total) * 100)
            $Script:ScoreValue.Text     = "$pct%"
            $Script:ScoreValue.ForeColor = if($pct -ge 80){$CSC_H}elseif($pct -ge 60){$CSC_W}else{$CSC_C}
        }
        $Script:HealthyCount.Text  = $cH.ToString()
        $Script:WarningCount.Text  = $cW.ToString()
        $Script:CriticalCount.Text = $cC.ToString()
        $Script:InfoCount.Text     = $cN.ToString()

        $Script:OverallLabel.Text      = if($cC-gt 0){'CRITICAL'}elseif($cW-gt 0){'WARNINGS'}elseif($cH-gt 0){'ALL OK'}else{'NO DATA'}
        $Script:OverallLabel.ForeColor = if($cC-gt 0){$CSC_C}elseif($cW-gt 0){$CSC_W}elseif($cH-gt 0){$CSC_H}else{$CT2}
        $Script:StatusLabel.Text       = if($cC-gt 0){"$cC Critical Issue(s)"}elseif($cW-gt 0){"$cW Warning(s)"}elseif($cH-gt 0){"All $cH checks healthy"}else{"No data"}
    }

    function Reset-UIState {
        $Script:CustomerCombo.SelectedIndex = 0

        $Script:ActiveCustomer  = $null
        $Script:TechLabel.Text         = ''
        $Script:TechLabel.ForeColor    = $CT1
        $Script:ServersLabel.Text      = '0 loaded'
        $Script:ServersLabel.ForeColor = $CT1
        $Script:StatusLabel.Text       = 'Not Connected'
        $Script:StatusLabel.ForeColor  = $CT2
        $Script:ScoreValue.Text        = '--'
        $Script:ScoreValue.ForeColor   = $CT2
        $Script:HealthyCount.Text      = '0'
        $Script:WarningCount.Text      = '0'
        $Script:CriticalCount.Text     = '0'
        $Script:InfoCount.Text         = '0'
        $Script:OverallLabel.Text      = 'NO DATA'
        $Script:OverallLabel.ForeColor = $CT2
        # btnDisconnect is same as btnConnect (toggle)
        $Script:ResultsGrid.DataSource = $null
        $Script:WinRMGrid.DataSource   = $null
    }

    # ==========================================================================
    # BUTTON HANDLERS
    # ==========================================================================
    $Script:btnConnect.Add_Click({
        # TOGGLE: if already connected, act as DISCONNECT
        if ($Script:Credential) {
            if ($Script:IsRunning) {
                [System.Windows.Forms.MessageBox]::Show("Cannot disconnect while a health check is running.","Busy",'OK','Warning') | Out-Null; return
            }
            $r5 = [System.Windows.Forms.MessageBox]::Show(
                "This will clear all credentials, sessions, and results.`n`nAre you sure?",
                "Confirm Disconnect",'YesNo','Question')
            if ($r5 -ne 'Yes') { return }
            try { Get-PSSession | Remove-PSSession -EA SilentlyContinue } catch {}
            $Script:Credential      = $null; $Script:ConnectedUser = ''
            $Script:CustomerName    = ''; $Script:ActiveCustomer = $null
            try { if (Test-Path $Script:SettingsFile) { Remove-Item $Script:SettingsFile -Force -EA SilentlyContinue } } catch {}
            $Script:ServerInventory = [System.Collections.ArrayList]@()
            $Script:LastResults     = $null; $Script:LastHTMLPath = ''; $Script:LastCSVPath = ''
            # Reset button back to CONNECT mode
            $Script:btnConnect.Tag = "CONNECT|to Servers|$($CB3.R)|$($CB3.G)|$($CB3.B)"
            $Script:btnConnect.Invalidate()
            Reset-UIState
            $Script:StatusBarLabel.Text = "Disconnected  -  Select a customer and click CONNECT"
            Write-LogMessage "" -Color Gray
            Write-LogMessage "=== DISCONNECTED - All credentials and sessions cleared ===" -Color Yellow
            Write-LogMessage "Click CONNECT to start a new session." -Color Gray
            return
        }
        # Guard: customer must be selected before connecting
        if (-not $Script:ActiveCustomer) {
            [System.Windows.Forms.MessageBox]::Show(
                "Please select a customer first from the CUSTOMER / SITE dropdown.`n`n" +
                "If you don't have any customers yet, click 'Manage Customers' to add one.",
                "No Customer Selected", 'OK', 'Warning') | Out-Null
            return
        }
                # Already-connected handled above by TOGGLE block
        Write-LogMessage "Requesting credentials..." -Color Cyan
        $cred = Get-Credential -Message "Enter Domain Administrator credentials for $($Script:ActiveCustomer.Name)`n`nAccount must have Domain Admin or Enterprise Admin rights."
        if (-not $cred) { Write-LogMessage "Cancelled." -Color Yellow; return }

        # ============================================================
        # CREDENTIAL VALIDATION - verify account before accepting
        # ============================================================
        Write-LogMessage "Validating credentials and checking account privileges..." -Color Cyan
        $Script:StatusBarLabel.Text = "Validating credentials..."
        $progPnl.Visible = $true
        Set-Progress -Pct 20 -Text "Testing connectivity..."

        # Step 1: Find a DC to test against
        $valDCs = @($Script:ServerInventory | Where-Object { $_.Role -match 'DC|Domain' } | ForEach-Object { $_.Name })
        if ($valDCs.Count -eq 0) {
            # No DCs defined - just accept credentials without full validation
            Write-LogMessage "WARNING: No DC servers in customer profile. Skipping privilege check." -Color Yellow
            Write-LogMessage "Add DC servers to the customer profile for full credential validation." -Color Yellow
        } else {
            $valSB = {
                $out = @{ WinRM=$false; IsDomainAdmin=$false; IsEnterpriseAdmin=$false; UserName=''; Domain=''; Err=''; Groups=@() }
                try {
                    $out.WinRM = $true
                    Import-Module ActiveDirectory -EA Stop
                    $me = [System.Security.Principal.WindowsIdentity]::GetCurrent()
                    $out.UserName = $me.Name
                    # Get current user's group memberships
                    $myUser = Get-ADUser $me.Name.Split('')[-1] -EA Stop
                    $out.Domain = $myUser.DistinguishedName -replace '.*DC=','' -replace ',DC=','.'
                    # Fast group check using WindowsIdentity token (faster than Get-ADPrincipalGroupMembership)
                    $principal = [System.Security.Principal.WindowsPrincipal]$me
                    $isDomAdmin = $principal.IsInRole('Domain Admins')
                    $isEntAdmin = $principal.IsInRole('Enterprise Admins')
                    # Fallback: AD query if token check fails (cross-domain or trust scenarios)
                    if (-not $isDomAdmin -and -not $isEntAdmin) {
                        try {
                            $groups2 = @(Get-ADPrincipalGroupMembership $myUser -EA Stop | Select-Object -ExpandProperty Name)
                            $isDomAdmin = $groups2 -contains 'Domain Admins'
                            $isEntAdmin = $groups2 -contains 'Enterprise Admins'
                            $out.Groups = $groups2
                        } catch { $out.Groups = @() }
                    } else {
                        $out.Groups = @('Domain Admins')
                    }
                    $out.IsDomainAdmin     = $isDomAdmin
                    $out.IsEnterpriseAdmin = $isEntAdmin
                    $out.IsSchemaAdmin     = $principal.IsInRole('Schema Admins')
                } catch { $out.Err = $_.Exception.Message }
                return $out
            }

            $valResult = $null
            $valOK = $false
            foreach ($valDC in $valDCs) {
                Write-LogMessage "  Validating against $valDC..." -Color Gray
                Set-Progress -Pct 40 -Text "Testing $valDC..."
                $valRes = Invoke-SafeRemoteCommand -ServerName $valDC -ScriptBlock $valSB -Credential $cred -TimeoutSeconds 30
                if ($valRes.Success) {
                    $valResult = $valRes.Data
                    $valOK = $true
                    break
                } else {
                    Write-LogMessage "  Cannot reach $valDC - $($valRes.Error)" -Color Yellow
                }
            }

            Set-Progress -Pct 80 -Text "Checking privileges..."

            if (-not $valOK) {
                $progPnl.Visible = $false
                $errMsg = "Cannot connect to any Domain Controller with the provided credentials.`n`n"
                $errMsg += "Errors indicate:`n"
                $errMsg += "  - Wrong username or password, OR`n"
                $errMsg += "  - WinRM not enabled on the target DCs, OR`n"
                $errMsg += "  - Firewall blocking WinRM (port 5985/5986)`n`n"
                $errMsg += "Tried DCs: $($valDCs -join ', ')`n`n"
                $errMsg += "Run TEST WinRM first to check connectivity before connecting."
                [System.Windows.Forms.MessageBox]::Show($errMsg, "Credential Validation Failed", 'OK', 'Error') | Out-Null
                Write-LogMessage "=== CREDENTIAL VALIDATION FAILED ===" -Color Red
                Write-LogMessage "Cannot connect to any DC. Check credentials and WinRM." -Color Red
                $Script:StatusBarLabel.Text = "Connection failed - invalid credentials or WinRM not available"
                return
            }

            if ($valResult.Err -and -not $valResult.IsDomainAdmin -and -not $valResult.IsEnterpriseAdmin) {
                # AD query failed but WinRM worked - partial validation
                Write-LogMessage "WARNING: Connected to DC but could not verify group membership: $($valResult.Err)" -Color Yellow
                Write-LogMessage "Proceeding with caution - some checks may fail if insufficient privileges." -Color Yellow
            } elseif (-not $valResult.IsDomainAdmin -and -not $valResult.IsEnterpriseAdmin) {
                $progPnl.Visible = $false
                $groupList = if (@($valResult.Groups).Count -gt 0) { "`n`nCurrent groups:`n  " + ($valResult.Groups -join "`n  ") } else { '' }
                $errMsg = "Account '$($cred.UserName)' does NOT have Domain Admin or Enterprise Admin rights.`n`n"
                $errMsg += "The health check tool requires at minimum Domain Admin rights to:`n"
                $errMsg += "  - Run repadmin for AD replication checks`n"
                $errMsg += "  - Query AD group memberships`n"
                $errMsg += "  - Connect to Exchange PowerShell`n"
                $errMsg += "  - Read disk space and service status remotely`n"
                $errMsg += $groupList
                $errMsg += "`n`nPlease use a Domain Admin account and try again."
                [System.Windows.Forms.MessageBox]::Show($errMsg, "Insufficient Privileges", 'OK', 'Warning') | Out-Null
                Write-LogMessage "=== INSUFFICIENT PRIVILEGES ===" -Color Red
                Write-LogMessage "Account '$($cred.UserName)' is not Domain Admin or Enterprise Admin." -Color Red
                Write-LogMessage "Groups: $($valResult.Groups -join ', ')" -Color Yellow
                $Script:StatusBarLabel.Text = "Connection rejected - account requires Domain Admin rights"
                return
            } else {
                $adminType = if ($valResult.IsEnterpriseAdmin) { 'Enterprise Admin' } elseif ($valResult.IsSchemaAdmin) { 'Domain Admin + Schema Admin' } else { 'Domain Admin' }
                Write-LogMessage "Credential validation PASSED - Account: $($cred.UserName) [$adminType]" -Color Green
                Write-LogMessage "Domain: $($valResult.Domain)  |  Groups verified: $(@($valResult.Groups).Count)" -Color Green
            }
        }

        Set-Progress -Pct 100 -Text "Validated!"
        Start-Sleep -Milliseconds 300
        $progPnl.Visible = $false

        # Credentials validated - complete the connection
        $Script:Credential    = $cred
        $Script:ConnectedUser = $cred.UserName
        $Script:TechLabel.Text      = $cred.UserName
        $Script:TechLabel.ForeColor = $CB3
        $Script:StatusLabel.Text    = "Connected"
        $Script:StatusLabel.ForeColor = $CG
        $Script:StatusBarLabel.Text = "Connected as:  $($cred.UserName)"
        # Toggle button to DISCONNECT mode
        $Script:btnConnect.Tag = "DISCONNECT|Clear Session|$($CR.R)|$($CR.G)|$($CR.B)"
        $Script:btnConnect.Invalidate()
        try {
            if ($Script:ActiveCustomer) {
                $Script:ServerInventory = Import-ServerInventory -CustomerProfile $Script:ActiveCustomer
            } else {
                $Script:ServerInventory = Import-ServerInventory
            }
            $cnt = $Script:ServerInventory.Count
            $Script:ServersLabel.Text      = "$cnt loaded"
            $Script:ServersLabel.ForeColor = $CB3
            Write-LogMessage "Connected as: $($cred.UserName)" -Color Green
            Write-LogMessage "Servers loaded: $cnt" -Color Green
            if ($cnt -eq 0) {
                Write-LogMessage "WARNING: No servers loaded." -Color Yellow
                Write-LogMessage "  Select a Customer Profile or create servers.txt" -Color Yellow
            } else {
                foreach ($s in $Script:ServerInventory) { Write-LogMessage "  + $($s.Name)  [$($s.Role)]" -Color Gray }
            }
        } catch { Write-LogMessage "ERROR: $($_.Exception.Message)" -Color Red }
    })

    $Script:btnWinRMTest.Add_Click({
        if (-not $Script:Credential) {
            [System.Windows.Forms.MessageBox]::Show("Please CONNECT first.","Not Connected",'OK','Warning') | Out-Null; return
        }
        if ($Script:ServerInventory.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show("No servers loaded from servers.txt.","No Servers",'OK','Warning') | Out-Null; return
        }
        $Script:btnWinRMTest.Enabled  = $false
        $Script:btnRunCheck.Enabled   = $false
        $progPnl.Visible              = $true
        $tabs.SelectedTab             = $tabWinRM
        $Script:StatusBarLabel.Text   = "Testing WinRM connectivity..."
        Write-LogMessage "" -Color Gray
        Write-LogMessage "=== WINRM CONNECTIVITY TEST ===" -Color Cyan
        try {
            $dtW = New-Object System.Data.DataTable
            [void]$dtW.Columns.Add('#',       [string])
            [void]$dtW.Columns.Add('Server',  [string])
            [void]$dtW.Columns.Add('Role',    [string])
            [void]$dtW.Columns.Add('DNS',     [string])
            [void]$dtW.Columns.Add('Ping',    [string])
            [void]$dtW.Columns.Add('WinRM HTTP (5985)',  [string])
            [void]$dtW.Columns.Add('WinRM HTTPS (5986)', [string])
            [void]$dtW.Columns.Add('PS Session',         [string])
            [void]$dtW.Columns.Add('Result',  [string])
            $total2 = $Script:ServerInventory.Count; $idx = 0
            foreach ($srv in $Script:ServerInventory) {
                $idx++
                Set-Progress -Pct ([math]::Round($idx/$total2*100)) -Text "[$idx/$total2] Testing: $($srv.Name)..."
                Write-LogMessage "Testing $($srv.Name) [$($srv.Role)]..." -Color Gray
                $dnsOK='FAIL'; $ip='N/A'
                try { $r2=[System.Net.Dns]::GetHostAddresses($srv.Name); if($r2.Count-gt 0){$dnsOK='OK';$ip=$r2[0].IPAddressToString} } catch {}
                $pingOK='FAIL'
                try { $pg=New-Object System.Net.NetworkInformation.Ping; $rp=$pg.Send($srv.Name,2000); $pingOK=if($rp.Status -eq 'Success'){'OK'}else{'FAIL'}; $pg.Dispose() } catch {}
                $w5985='FAIL'
                try { $tc=New-Object System.Net.Sockets.TcpClient; $ar=$tc.BeginConnect($srv.Name,5985,$null,$null); if($ar.AsyncWaitHandle.WaitOne(3000,$false)-and $tc.Connected){$w5985='OK'}; $tc.Close() } catch {}
                $w5986='FAIL'
                try { $tc2=New-Object System.Net.Sockets.TcpClient; $ar2=$tc2.BeginConnect($srv.Name,5986,$null,$null); if($ar2.AsyncWaitHandle.WaitOne(3000,$false)-and $tc2.Connected){$w5986='OK'}; $tc2.Close() } catch {}
                $psOK='FAIL'
                try { $so2=New-PSSessionOption -OpenTimeout 8000 -OperationTimeout 8000 -IdleTimeout 60000; $ss=New-PSSession -ComputerName $srv.Name -Credential $Script:Credential -SessionOption $so2 -EA Stop; Remove-PSSession $ss -EA SilentlyContinue; $psOK='OK' } catch {}
                $result2 = if($dnsOK-eq'OK'-and $pingOK-eq'OK'-and $w5985-eq'OK'-and $psOK-eq'OK'){'READY'}elseif($dnsOK-eq'FAIL'){'DNS FAIL'}elseif($pingOK-eq'FAIL'){'UNREACHABLE'}elseif($w5985-eq'FAIL'){'WinRM BLOCKED'}else{'AUTH FAIL'}
                [void]$dtW.Rows.Add($idx.ToString(),$srv.Name,$srv.Role,"$dnsOK ($ip)",$pingOK,$w5985,$w5986,$psOK,$result2)
                $lc=if($result2-eq'READY'){'Green'}elseif($result2-in@('WinRM BLOCKED','AUTH FAIL')){'Yellow'}else{'Red'}
                Write-LogMessage "  $($srv.Name): $result2  DNS:$dnsOK  Ping:$pingOK  WinRM:$w5985  PS:$psOK" -Color $lc
            }
            $Script:WinRMGrid.AutoGenerateColumns = $false
        if ($Script:WinRMGrid.Columns.Count -eq 0) {
            $wc0 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
            $wc0.Name='#'; $wc0.DataPropertyName='#'; $wc0.HeaderText='#'; $wc0.Width=44
            $wc0.DefaultCellStyle.Alignment='MiddleCenter'; $wc0.HeaderCell.Style.Alignment='MiddleCenter'
            [void]$Script:WinRMGrid.Columns.Add($wc0)
            $wc1 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
            $wc1.Name='Server'; $wc1.DataPropertyName='Server'; $wc1.HeaderText='Server Name'; $wc1.Width=220
            [void]$Script:WinRMGrid.Columns.Add($wc1)
            $wc2 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
            $wc2.Name='Role'; $wc2.DataPropertyName='Role'; $wc2.HeaderText='Role'; $wc2.Width=120
            [void]$Script:WinRMGrid.Columns.Add($wc2)
            $wc3 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
            $wc3.Name='Result'; $wc3.DataPropertyName='Result'; $wc3.HeaderText='WinRM Status'; $wc3.Width=130
            $wc3.DefaultCellStyle.Alignment='MiddleCenter'; $wc3.HeaderCell.Style.Alignment='MiddleCenter'
            [void]$Script:WinRMGrid.Columns.Add($wc3)
            $wc4 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
            $wc4.Name='Detail'; $wc4.DataPropertyName='Detail'; $wc4.HeaderText='Detail'
            $wc4.AutoSizeMode=[System.Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill
            [void]$Script:WinRMGrid.Columns.Add($wc4)
        }
        $Script:WinRMGrid.DataSource = $dtW
        $Script:WinRMGrid.AutoSizeColumnsMode = 'None'
            $ready2=@($dtW.Rows|Where-Object{$_['Result']-eq'READY'}).Count
            Write-LogMessage "=== TEST COMPLETE: $ready2/$total2 READY ===" -Color Green
            $Script:StatusBarLabel.Text = "WinRM test complete: $ready2/$total2 servers reachable"
            $blocked2=@($dtW.Rows|Where-Object{$_['Result']-ne'READY'})
            if($blocked2.Count-gt 0){
                $msg2="WinRM Test Complete`n`nREADY: $ready2/$total2`nISSUES: $($blocked2.Count) server(s)`n`n"
                foreach($br2 in $blocked2){$msg2+="  * $($br2['Server']): $($br2['Result'])`n"}
                $msg2+="`nRemediation:`n  - Enable WinRM:  winrm quickconfig`n  - Firewall: allow TCP 5985`n  - Verify credentials have remote rights"
                [System.Windows.Forms.MessageBox]::Show($msg2,"WinRM Results",'OK','Warning') | Out-Null
            } else {
                [System.Windows.Forms.MessageBox]::Show("All $total2 servers are reachable and ready.","All Servers Ready",'OK','Information') | Out-Null
            }
        } catch {
            Write-LogMessage "WinRM TEST ERROR: $($_.Exception.Message)" -Color Red
            $Script:StatusBarLabel.Text = "WinRM test failed"
        } finally {
            $Script:btnWinRMTest.Enabled = $true
            $Script:btnRunCheck.Enabled  = $true
            $progPnl.Visible             = $false
        }
    })

    $Script:btnRunCheck.Add_Click({
        if (-not $Script:Credential) {
            [System.Windows.Forms.MessageBox]::Show("Please CONNECT first.","Not Connected",'OK','Warning') | Out-Null; return
        }
        if ($Script:ServerInventory.Count -eq 0) {
            $r3=[System.Windows.Forms.MessageBox]::Show("No servers loaded. Continue in test mode?","No Servers",'YesNo','Warning')
            if ($r3 -ne 'Yes') { return }
        }
        $Script:IsRunning             = $true
        $Script:btnRunCheck.Enabled   = $false
        $Script:btnConnect.Enabled    = $false
        $Script:btnWinRMTest.Enabled  = $false
                $Script:btnExport.Enabled     = $false
        foreach ($b in @($Script:btnRunCheck,$Script:btnConnect,$Script:btnWinRMTest,$Script:btnExport)) { $b.Invalidate() }
        $progPnl.Visible              = $true
        $tabs.SelectedTab             = $tabResults
        $Script:StatusBarLabel.Text   = "Running health checks - please wait..."
        Write-LogMessage "" -Color Gray
        Write-LogMessage "=== HEALTH CHECK STARTED ===" -Color Cyan
        Write-LogMessage "Customer: $(if($Script:CustomerName){$Script:CustomerName}else{'(not set)'})" -Color Gray
        try {
            Start-LogSession
            Set-Progress -Pct 5 -Text "[1/14] Starting all health checks - this may take several minutes..."
            $Script:LastResults = Invoke-HealthCheckAll -Credential $Script:Credential
            Set-Progress -Pct 96 -Text "Updating dashboard..."
            Update-Dashboard
            Set-Progress -Pct 100 -Text "Complete"
            $hC=@($Script:LastResults.Values|Where-Object{$_.Status -eq 'Healthy'}).Count
            $wC=@($Script:LastResults.Values|Where-Object{$_.Status -eq 'Warning'}).Count
            $cC2=@($Script:LastResults.Values|Where-Object{$_.Status -eq 'Critical'}).Count
            Write-LogMessage "=== COMPLETE  Healthy:$hC  Warning:$wC  Critical:$cC2 ===" -Color Green
            # Update customer profile with last check result
            if ($Script:ActiveCustomer -and $Script:ActiveCustomer.ID) {
                $lastStatus2 = if ($cC2 -gt 0) {'Critical'} elseif ($wC -gt 0) {'Warning'} else {'Healthy'}
                Update-CustomerLastCheck -CustomerID $Script:ActiveCustomer.ID -Status $lastStatus2
                Refresh-CustomerCombo
            }
            $Script:StatusBarLabel.Text = "Complete  -  Healthy:$hC   Warning:$wC   Critical:$cC2   |   Click EXPORT for HTML report"
            Start-Sleep -Milliseconds 500
        } catch {
            Write-LogMessage "FATAL ERROR: $($_.Exception.Message)" -Color Red
            [System.Windows.Forms.MessageBox]::Show("Health check failed:`n`n$($_.Exception.Message)","Error",'OK','Error') | Out-Null
            $Script:StatusBarLabel.Text = "Health check failed - see Activity Log"
        } finally {
            $Script:IsRunning             = $false
            $progPnl.Visible              = $false
            $Script:btnRunCheck.Enabled   = $true
            $Script:btnConnect.Enabled    = $true
            $Script:btnWinRMTest.Enabled  = $true
                        $Script:btnExport.Enabled     = $true
            foreach ($b in @($Script:btnRunCheck,$Script:btnConnect,$Script:btnWinRMTest,$Script:btnExport)) { $b.Invalidate() }
        }
    })

    # Logo upload - accessible from Manage Customers area (adds to report header)
    function Set-CompanyLogo {
        $od = New-Object System.Windows.Forms.OpenFileDialog
        $od.Title = "Select Company Logo for Reports"
        $od.Filter = "Image files (*.png;*.jpg;*.jpeg;*.gif)|*.png;*.jpg;*.jpeg;*.gif|All files (*.*)|*.*"
        $od.InitialDirectory = [System.Environment]::GetFolderPath('MyPictures')
        if ($od.ShowDialog() -ne 'OK') { return }
        try {
            $bytes = [System.IO.File]::ReadAllBytes($od.FileName)
            $Script:CompanyLogo = [Convert]::ToBase64String($bytes)
            # Save logo path to settings.json
            try {
                $settings = if (Test-Path $Script:SettingsFile) { Get-Content $Script:SettingsFile -Raw | ConvertFrom-Json } else { [PSCustomObject]@{} }
                if (-not ($settings | Get-Member -Name 'LogoPath' -ErrorAction SilentlyContinue)) {
                    $settings | Add-Member -MemberType NoteProperty -Name 'LogoPath' -Value ''
                }
                $settings.LogoPath = $od.FileName
                $settings | ConvertTo-Json | Set-Content $Script:SettingsFile -Encoding UTF8 -Force
            } catch {}
            $logoName = [System.IO.Path]::GetFileName($od.FileName)
            [System.Windows.Forms.MessageBox]::Show(
                "Logo '$logoName' loaded successfully.`n`nIt will appear in all exported HTML reports.",
                "Logo Set", 'OK', 'Information') | Out-Null
            Write-LogMessage "Company logo set: $logoName" -Color Cyan
        } catch {
            [System.Windows.Forms.MessageBox]::Show("Failed to load logo:`n$($_.Exception.Message)","Error",'OK','Error') | Out-Null
        }
    }

    # Restore logo from settings on startup
    try {
        if (Test-Path $Script:SettingsFile) {
            $s2 = Get-Content $Script:SettingsFile -Raw | ConvertFrom-Json
            if ($s2.LogoPath -and (Test-Path $s2.LogoPath)) {
                $bytes2 = [System.IO.File]::ReadAllBytes($s2.LogoPath)
                $Script:CompanyLogo = [Convert]::ToBase64String($bytes2)
                Write-LogMessage "Company logo restored from settings." -Color Gray
            }
        }
    } catch {}

    $Script:btnExport.Add_Click({
        if (-not $Script:LastResults) {
            [System.Windows.Forms.MessageBox]::Show("No results. Run a health check first.","No Data",'OK','Warning') | Out-Null; return
        }
        $fb = New-Object System.Windows.Forms.FolderBrowserDialog
        $fb.Description  = "Select folder for HTML and CSV reports"
        $fb.SelectedPath = $Script:ReportPath
        if ($fb.ShowDialog() -ne 'OK') { return }
        $Script:ReportPath      = $fb.SelectedPath
        $Script:StatusBarLabel.Text = "Generating reports..."
        $progPnl.Visible        = $true
        Set-Progress -Pct 40 -Text "Building HTML report..."
        try {
            $ts4   = Get-Date -Format 'yyyyMMdd_HHmmss'
            Set-Progress -Pct 70 -Text "Writing files..."
            $paths = Build-Reports -Results $Script:LastResults -Timestamp $ts4
            Set-Progress -Pct 100 -Text "Saved!"
            $Script:LastHTMLPath = $paths.HTML
            $Script:LastCSVPath  = $paths.CSV
            Write-LogMessage "HTML: $($paths.HTML)" -Color Green
            Write-LogMessage "CSV:  $($paths.CSV)"  -Color Green
            $r4 = [System.Windows.Forms.MessageBox]::Show(
                "Reports saved successfully!`n`nHTML: $($paths.HTML)`nCSV:  $($paths.CSV)`n`nOpen HTML report in browser now?",
                "Export Complete", 'YesNo', 'Information')
            if ($r4 -eq 'Yes') {
                Start-Sleep -Milliseconds 500
                Start-Process 'explorer.exe' -ArgumentList $paths.HTML
            }
            $Script:StatusBarLabel.Text = "Saved: $([System.IO.Path]::GetFileName($paths.HTML))"
        } catch {
            Write-LogMessage "EXPORT ERROR: $($_.Exception.Message)" -Color Red
            [System.Windows.Forms.MessageBox]::Show("Export failed:`n`n$($_.Exception.Message)","Export Error",'OK','Error') | Out-Null
            $Script:StatusBarLabel.Text = "Export failed - see Activity Log"
        } finally { $progPnl.Visible = $false }
    })

    $Script:btnServers.Add_Click({
        if ($Script:ServerInventory.Count -eq 0 -and -not $Script:ActiveCustomer) {
            $r7 = [System.Windows.Forms.MessageBox]::Show(
                "No servers loaded.`n`nOpen Customer Profile Manager to add customers and servers?",
                "No Servers",'YesNo','Warning')
            if ($r7 -eq 'Yes') { Show-CustomerManager; Refresh-CustomerCombo }
            return
        }

        $sf2 = New-Object System.Windows.Forms.Form
        $custTitle = if ($Script:ActiveCustomer) { "  -  $($Script:ActiveCustomer.Name)" } else { '' }
        $sf2.Text          = "Server Inventory - $($Script:ActiveCustomer.Name)  ($($Script:ServerInventory.Count) server(s))"
        $sf2.Size          = New-Object System.Drawing.Size(820, 520)
        $sf2.MinimumSize   = New-Object System.Drawing.Size(640, 400)
        $sf2.StartPosition = 'CenterParent'
        $sf2.BackColor     = [System.Drawing.Color]::FromArgb(240,242,248)
        $sf2.Font          = New-Object System.Drawing.Font('Segoe UI', 9)
        $sf2.FormBorderStyle = 'Sizable'

        # -- Title bar (Dock=Top, added LAST so processed FIRST = top of form) --
        $stp = New-Object System.Windows.Forms.Panel
        $stp.Dock = 'Top'; $stp.Height = 46
        $stp.BackColor = [System.Drawing.Color]::FromArgb(0,60,130)
        $stl = New-Object System.Windows.Forms.Label
        $stl.Text = "   Server Inventory  -  $($Script:ServerInventory.Count) server(s)$custTitle"
        $stl.Dock = 'Fill'
        $stl.Font = New-Object System.Drawing.Font('Segoe UI',12,[System.Drawing.FontStyle]::Bold)
        $stl.ForeColor = [System.Drawing.Color]::White
        $stl.BackColor = [System.Drawing.Color]::Transparent
        $stl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
        $stp.Controls.Add($stl)

        # -- Customer info (Dock=Top, added SECOND so appears below title) --
        $sip = New-Object System.Windows.Forms.Panel
        $sip.Dock = 'Top'; $sip.Height = 34
        $sip.BackColor = [System.Drawing.Color]::FromArgb(226,238,255)
        $sil = New-Object System.Windows.Forms.Label; $sil.Dock = 'Fill'
        $sil.Padding = New-Object System.Windows.Forms.Padding(12,0,0,0)
        $site4  = if ($Script:ActiveCustomer -and $Script:ActiveCustomer.Site)    { "   |   $($Script:ActiveCustomer.Site)" }    else { '' }
        $cont4  = if ($Script:ActiveCustomer -and $Script:ActiveCustomer.Contact) { "   |   $($Script:ActiveCustomer.Contact)" } else { '' }
        $sil.Text = "$($Script:ActiveCustomer.Name)$site4$cont4"
        $sil.Font = New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold)
        $sil.ForeColor = [System.Drawing.Color]::FromArgb(0,50,120)
        $sil.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
        $sip.Controls.Add($sil)

        # -- Role summary bar (Dock=Top, added THIRD = appears third) --
        $roleCounts = @{}
        foreach ($sv in $Script:ServerInventory) {
            $rk = if($sv.Role -and $sv.Role -ne ''){$sv.Role}else{'Unknown'}
            $roleCounts[$rk] = ([int]$roleCounts[$rk]) + 1
        }
        $summaryText = "  Roles:   " + (($roleCounts.GetEnumerator() | Sort-Object Name | ForEach-Object { "$($_.Value) $($_.Key)" }) -join "   |   ")
        $rsp = New-Object System.Windows.Forms.Panel
        $rsp.Dock = 'Top'; $rsp.Height = 26; $rsp.BackColor = [System.Drawing.Color]::FromArgb(22,28,48)
        $rsl = New-Object System.Windows.Forms.Label; $rsl.Dock = 'Fill'; $rsl.Text = $summaryText
        $rsl.Font = New-Object System.Drawing.Font('Segoe UI',8,[System.Drawing.FontStyle]::Bold)
        $rsl.ForeColor = [System.Drawing.Color]::FromArgb(140,180,230)
        $rsl.BackColor = [System.Drawing.Color]::Transparent
        $rsl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
        $rsp.Controls.Add($rsl)

        # -- Close bar (Dock=Bottom) --
        $cbp = New-Object System.Windows.Forms.Panel
        $cbp.Dock = 'Bottom'; $cbp.Height = 44
        $cbp.BackColor = [System.Drawing.Color]::FromArgb(238,241,248)
        $cbtn = New-Object System.Windows.Forms.Button
        $cbtn.Text = 'Close'; $cbtn.Location = New-Object System.Drawing.Point(12,8)
        $cbtn.Size = New-Object System.Drawing.Size(100,28); $cbtn.FlatStyle = 'Flat'
        $cbtn.FlatAppearance.BorderSize = 0
        $cbtn.BackColor = [System.Drawing.Color]::FromArgb(0,84,166); $cbtn.ForeColor = [System.Drawing.Color]::White
        $cbtn.Font = New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold)
        $cbtn.Cursor = [System.Windows.Forms.Cursors]::Hand
        $cbtn.Add_Click({ $sf2.Close() })
        $cbp.Controls.Add($cbtn)

        # -- DataGridView using DataTable DataSource (no scroll side-effects) --
        $sg2 = New-Object System.Windows.Forms.DataGridView
        $sg2.Dock = 'Fill'
        $sg2.ReadOnly = $true
        $sg2.AllowUserToAddRows = $false; $sg2.AllowUserToDeleteRows = $false
        $sg2.BackgroundColor = [System.Drawing.Color]::White
        $sg2.BorderStyle = 'None'
        $sg2.GridColor = [System.Drawing.Color]::FromArgb(220,226,240)
        $sg2.RowHeadersVisible = $false
        $sg2.SelectionMode = 'FullRowSelect'; $sg2.MultiSelect = $false
        $sg2.AutoSizeColumnsMode = 'None'
        $sg2.AutoGenerateColumns = $false
        $sg2.RowTemplate.Height = 30
        $sg2.ColumnHeadersHeight = 34
        $sg2.EnableHeadersVisualStyles = $false
        $sg2.CellBorderStyle = [System.Windows.Forms.DataGridViewCellBorderStyle]::SingleHorizontal
        $sg2.ScrollBars = 'Vertical'
        $sg2.DefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(210,228,252)
        $sg2.DefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::FromArgb(10,20,40)
        $sg2.DefaultCellStyle.Font = New-Object System.Drawing.Font('Segoe UI',9)
        $sg2.DefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(4,0,0,0)
        $ghs2 = $sg2.ColumnHeadersDefaultCellStyle
        $ghs2.BackColor = [System.Drawing.Color]::FromArgb(22,28,48)
        $ghs2.ForeColor = [System.Drawing.Color]::FromArgb(162,192,228)
        $ghs2.Font = New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold)
        $ghs2.SelectionBackColor = [System.Drawing.Color]::FromArgb(22,28,48)

        # Define columns explicitly (AutoGenerateColumns=false)
        $c1 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
        $c1.HeaderText = '#'; $c1.DataPropertyName = 'No'; $c1.Width = 44
        $c1.DefaultCellStyle.Alignment = 'MiddleCenter'
        $c1.HeaderCell.Style.Alignment = 'MiddleCenter'
        [void]$sg2.Columns.Add($c1)

        $c2 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
        $c2.HeaderText = 'Server Name / FQDN'; $c2.DataPropertyName = 'Server'
        $c2.AutoSizeMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill
        [void]$sg2.Columns.Add($c2)

        $c3 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
        $c3.HeaderText = 'Role'; $c3.DataPropertyName = 'Role'; $c3.Width = 130
        [void]$sg2.Columns.Add($c3)

        $c4 = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
        $c4.HeaderText = 'Type'; $c4.DataPropertyName = 'Type'; $c4.Width = 150
        [void]$sg2.Columns.Add($c4)

        # Build DataTable and bind - this approach never causes scroll issues
        $dt = New-Object System.Data.DataTable
        [void]$dt.Columns.Add('No',   [int])
        [void]$dt.Columns.Add('Server',[string])
        [void]$dt.Columns.Add('Role',  [string])
        [void]$dt.Columns.Add('Type',  [string])

        $rowNum2 = 0
        foreach ($sv2 in $Script:ServerInventory) {
            $rowNum2++
            $roleName  = if($sv2.Role -and $sv2.Role -ne ''){[string]$sv2.Role}else{'Unknown'}
            $typeLabel = switch -Regex ($roleName.ToUpper()) {
                '^DC$|DOMAIN'   { 'Domain Controller' }
                'EXCHANGE|^EX$' { 'Exchange Server'   }
                '^DFS$'         { 'DFS Server'         }
                'ADFS'          { 'ADFS / Federation'  }
                default         { $roleName             }
            }
            [void]$dt.Rows.Add($rowNum2, [string]$sv2.Name, $roleName, $typeLabel)
        }

        $sg2.DataSource = $dt    # Bind entire table at once - no row-by-row Add()

        # Color rows via CellFormatting - use column INDEX (not name) for data-bound grids
        $sg2.Add_CellFormatting({
            param($sender,$e)
            if ($e.RowIndex -lt 0 -or $e.RowIndex -ge $dt.Rows.Count) { return }
            # Get role directly from the DataTable row (safe, no column-name lookup on grid)
            $roleVal = [string]$dt.Rows[$e.RowIndex]['Role']
            # Alternating row background on all cells
            if (-not $sender.Rows[$e.RowIndex].Selected) {
                $e.CellStyle.BackColor = if ($e.RowIndex % 2 -eq 0) {
                    [System.Drawing.Color]::White
                } else {
                    [System.Drawing.Color]::FromArgb(245,248,252)
                }
            }
            # Role column (index 2) and Type column (index 3) - colored text
            if ($e.ColumnIndex -eq 2 -or $e.ColumnIndex -eq 3) {
                $roleColor = switch -Regex ($roleVal.ToUpper()) {
                    '^DC$|DOMAIN' { [System.Drawing.Color]::FromArgb(0,70,140)  }
                    'EXCHANGE'    { [System.Drawing.Color]::FromArgb(0,110,0)   }
                    'ADFS'        { [System.Drawing.Color]::FromArgb(150,75,0)  }
                    '^DFS$'       { [System.Drawing.Color]::FromArgb(80,0,140)  }
                    default       { [System.Drawing.Color]::FromArgb(60,70,90)  }
                }
                $e.CellStyle.ForeColor = $roleColor
                if ($e.ColumnIndex -eq 2) {
                    $e.CellStyle.Font = New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold)
                }
                $e.FormattingApplied = $true
            }
        })

        # CORRECT Dock=Top add order: last added = processed first = appears at top
        # Desired visual: Title | CustomerInfo | RoleSummary | Grid | CloseBar
        # Add order: cbp(Bottom), sg2(Fill), rsp(Top-first), sip(Top-second), stp(Top-last=TOP)
        $sf2.Controls.Add($cbp)   # Bottom - processed first, claims bottom
        $sf2.Controls.Add($sg2)   # Fill   - processed after Bottom panels
        $sf2.Controls.Add($rsp)   # Top    - processed 3rd from top
        if ($Script:ActiveCustomer) { $sf2.Controls.Add($sip) }  # Top - 2nd from top
        $sf2.Controls.Add($stp)   # Top    - processed first = very top

        [void]$sf2.ShowDialog()
    })

    $Script:btnLog.Add_Click({ $tabs.SelectedTab = $tabLog })

        # Disconnect is handled inside btnConnect.Add_Click (toggle mode)

    # ==========================================================================
    # STARTUP LOG MESSAGES
    # ==========================================================================
    Write-LogMessage "NourNet Infrastructure Health Check  -  v5.2 Professional" -Color White
    Write-LogMessage "Zero modifications to any infrastructure component." -Color Gray
    Write-LogMessage "" -Color Gray
    Write-LogMessage "  STEP 1   CONNECT     Enter Domain Admin credentials" -Color Cyan
    Write-LogMessage "  STEP 2   TEST WinRM  Verify server connectivity (optional)" -Color Cyan
    Write-LogMessage "  STEP 3   RUN CHECK   Execute all 14 health checks" -Color Cyan
    Write-LogMessage "  STEP 4   EXPORT      Save HTML + CSV report" -Color Cyan
    Write-LogMessage "  STEP 5   DISCONNECT  Clear credentials and sessions" -Color Cyan
    Write-LogMessage "" -Color Gray
    Write-LogMessage "  servers.txt format:  ServerName,Role" -Color Gray
    Write-LogMessage "  Roles:  DC   Exchange   DFS   ADFS" -Color Gray

    $form.Add_Shown({ $form.Activate() })
    [void]$form.ShowDialog()
}

# ==============================================================================
#  ENTRY POINT
# ==============================================================================
Show-MainGUI